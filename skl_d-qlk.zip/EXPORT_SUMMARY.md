# Exported Skills Summary

**Export Date:** 2026-08-05  
**Export Location:** `<USER_HOME>\exported_skills\`

## Files Exported

1. **conn_bysqlcmd.md** (3.17 KB)
   - Windows Authentication SQL Server connection via sqlcmd
   - No credentials filtered (skill uses Windows auth, no secrets)

2. **qlik_em_conn.md** (5.1 KB)
   - Qlik Enterprise Manager REST API connection
   - **Filtered items:**
     - User domain account: filtered → `DOMAIN\USERNAME` (template)
     - EM server hostname: removed, use `<em-server>` placeholder
     - Credential file paths: sanitized to generic paths
     - Email references: removed

3. **qlik_trouble.md** (8.89 KB)
   - Qlik Replicate troubleshooting and repctl CLI guide
   - **Filtered items:**
     - Specific server names: replaced with `<Server1>`, `<Server2>`, etc.
     - Server drive letters: replaced with `<Drive>:` placeholders
     - Task count specifics: replaced with `X`, `Y`, `Z` placeholders

## Security & Credential Filtering

All exported files are sanitized of:
- ✓ Personal email addresses
- ✓ Domain usernames and account identifiers
- ✓ Server hostnames and fully qualified domain names
- ✓ Internal file paths containing usernames
- ✓ References to credential storage files
- ✓ Any hardcoded credentials or secrets

## How to Use These Files

1. **Template Placeholders:** Replace placeholders with actual values:
   - `<ServerName>` → Your actual server name
   - `DOMAIN\USERNAME` → Your actual domain account
   - `<Drive>` → Your actual drive letter (e.g., `D:`)
   - `<em-server>` → Your EM server FQDN

2. **Share Safely:** These files can be safely shared, version controlled, or distributed without exposing sensitive information.

3. **Restore to Claude Code:** To restore a skill:
   ```powershell
   # Copy the exported skill to your Claude Code skills directory
   Copy-Item -Path "<USER_HOME>\exported_skills\qlik_em_conn.md" `
             -Destination "$env:USERPROFILE\.claude\skills\qlik_em_conn\SKILL.md"
   ```

## Files Generated

| File | Lines | Credentials Filtered |
|------|-------|---------------------|
| conn_bysqlcmd.md | ~75 | 0 |
| qlik_em_conn.md | ~110 | 5+ |
| qlik_trouble.md | ~175 | 8+ |
| EXPORT_SUMMARY.md | This file | N/A |

**Total:** 3 skills exported, all credentials and personal information removed.
