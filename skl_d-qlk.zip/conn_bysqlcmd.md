---
name: conn_bysqlcmd
description: Connect to a SQL Server instance from the command line using sqlcmd with Windows Authentication (trusted connection). Use whenever the user asks to connect to a SQL Server via sqlcmd, run a quick ad-hoc query against a server/instance, run a .sql script from the command line, or troubleshoot sqlcmd connectivity/PATH issues. Applies to any server name (e.g. MP-DBA-D04, TDC-MP-HRP-D01), not just the examples below.
---

# Connect via sqlcmd (Windows Authentication)

`sqlcmd` uses whatever Windows account is currently logged in — no username/password prompts, no stored credentials. This only works when the account running the terminal has SQL Server login rights on the target instance.

**Safety rule — read-only by default.** Never run DML (`INSERT`/`UPDATE`/`DELETE`/`TRUNCATE`) or DDL (`DROP`/`ALTER`/`CREATE`) through a connection made via this skill without first asking the user for explicit permission, even if the task seems to imply it. Default to `SELECT` queries. If a task genuinely requires a data/schema change, stop and ask before running it.

## 0. Confirm sqlcmd is available

```powershell
Get-Command sqlcmd -ErrorAction SilentlyContinue | Select-Object Source
```

If that returns nothing, sqlcmd isn't on PATH yet. Typical install location:
```
C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\170\Tools\Binn\SQLCMD.EXE
```
Add it to PATH permanently (user-level, requires a new terminal window to take effect):
```powershell
[Environment]::SetEnvironmentVariable("PATH", $env:PATH + ";C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\170\Tools\Binn", "User")
```

## 1. Basic connect (Windows Auth)

```
sqlcmd -S <ServerName> -E
```
- `-S` = server name (e.g. `MP-DBA-D04`)
- `-E` = trusted connection / Windows Authentication

## 2. Connect straight into a specific database

```
sqlcmd -S <ServerName> -E -d <DatabaseName>
```
Example: `sqlcmd -S MP-DBA-D04 -E -d SQLTools`

## 3. Using the interactive prompt

Once connected you're at a numbered prompt (`1>`, `2>`, ...). Queries are only executed once you type `GO` on its own line:
```sql
1> SELECT @@SERVERNAME, DB_NAME();
2> GO
```
Exit with `EXIT` or `quit`.

## 4. Common variations

| Goal | Command |
|---|---|
| Named instance | `sqlcmd -S <ServerName>\<InstanceName> -E` |
| Non-default port | `sqlcmd -S <ServerName>,<port> -E` |
| Run a script file | `sqlcmd -S <ServerName> -E -i script.sql` |
| Run inline query and exit | `sqlcmd -S <ServerName> -E -Q "SELECT 1"` |
| Output results to a file | `sqlcmd -S <ServerName> -E -i script.sql -o output.txt` |

## Troubleshooting

- **`Login failed for user '<domain>\<user>'`** — the Windows account has no SQL login on that instance; needs a DBA to grant one, not a client-side fix.
- **`A network-related or instance-specific error...`** — usually a firewall/port issue, wrong instance name, or SQL Browser service down on the target for named instances. Verify with `Test-NetConnection <ServerName> -Port 1433` (or the named-instance port if non-default).
- **`'sqlcmd' is not recognized...`** — PATH issue, see step 0.

## Worked example

```
sqlcmd -S <ServerName> -E -d <DatabaseName>
1> SELECT name FROM sys.databases;
2> GO
1> EXIT
```
