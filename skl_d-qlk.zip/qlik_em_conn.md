---
name: qlik_em_conn
description: Connect to Qlik/Attunity Enterprise Manager (EM) via its REST API and perform EM-level operations — list servers/nodes, list all tasks across nodes, pull live task state (RUNNING/STOPPED/ERROR) and stop_reason, etc. Use whenever the user asks to use "EM", "Enterprise Manager", "EM REST API", or "EM API" for Qlik Replicate.
---

# Qlik Enterprise Manager (EM) REST API Connection

EM is the central console that aggregates every Qlik Replicate node into one place. Use this skill instead of direct WinRM/repctl approaches whenever the user specifically asks to go through EM, or wants a cross-node view — EM's `/tasks` endpoint returns `state` and `stop_reason` for every task on every node in one call.

## Known EM-managed nodes

Update this list as you work with additional nodes:
- Node A — X tasks
- Node B — Y tasks  
- Node C — Z tasks

## 1. Credential: save once, reuse silently

Password-based auth is required for EM's login endpoint (Windows Integrated Auth does not work). Save credentials DPAPI-encrypted (tied to the Windows account + machine — unreadable elsewhere):

```powershell
# Create credential save script: qlik_em_save_cred.ps1
$CredFile = "$env:USERPROFILE\.qlik_em_cred.xml"
$Cred = Get-Credential -UserName "DOMAIN\USERNAME" -Message "EM password"
$Cred | Export-Clixml -Path $CredFile
Write-Host "Credential saved to $CredFile"
```

Every script should load it like this, falling back to a prompt only if the file is missing:
```powershell
$CredFile = "$env:USERPROFILE\.qlik_em_cred.xml"
if (Test-Path $CredFile) {
    $Cred = Import-Clixml -Path $CredFile
} else {
    $Cred = Get-Credential -UserName "DOMAIN\USERNAME" -Message "EM password (save with qlik_em_save_cred.ps1 to avoid this prompt)"
}
$Password = $Cred.GetNetworkCredential().Password
```
Once saved, running scripts requires **zero interactive input** — safe to run directly.

## 2. Gotcha: `-UseBasicParsing` is mandatory

`Invoke-WebRequest`/`Invoke-RestMethod` without `-UseBasicParsing` fail with:
```
Invoke-WebRequest : Windows PowerShell is in NonInteractive mode. Read and Prompt functionality is not available.
```
This occurs in non-interactive sessions (like tool-based PowerShell calls or scheduled execution). **Always pass `-UseBasicParsing` on every `Invoke-WebRequest`/`Invoke-RestMethod` call**, including login and logout.

## 3. Self-signed cert handling

```powershell
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
if (-not ([System.Management.Automation.PSTypeName]'TrustAllCertsPolicy').Type) {
    Add-Type @"
        using System.Net;
        using System.Security.Cryptography.X509Certificates;
        public class TrustAllCertsPolicy : ICertificatePolicy {
            public bool CheckValidationResult(ServicePoint srvPoint, X509Certificate certificate, WebRequest request, int certificateProblem) { return true; }
        }
"@
    [Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
}
```

## 4. Full connect pattern

```powershell
$EMServer = "https://<em-server>/attunityenterprisemanager"
$Username = "DOMAIN\USERNAME"
$EncodedCredential = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes("${Username}:${Password}"))
$LoginHeaders = @{ Authorization = "Basic $EncodedCredential" }
$LoginResponse = Invoke-WebRequest -Uri "$EMServer/api/v1/login" -Method Get -Headers $LoginHeaders -UseBasicParsing
$SessionId = $LoginResponse.Headers["EnterpriseManager.APISessionID"]
$SessionHeaders = @{ "EnterpriseManager.APISessionID" = $SessionId }

# ... do the requested operation (section 5) ...

Invoke-RestMethod -Uri "$EMServer/api/v1/logout" -Method Get -Headers $SessionHeaders -UseBasicParsing > $null
```

## 5. Operations

### List servers/nodes
```powershell
Invoke-RestMethod -Uri "$EMServer/api/v1/servers" -Method Get -Headers $SessionHeaders -UseBasicParsing
```
Returns `.serverList` — each entry's `.name` is the node hostname to use in the next call.

### List tasks on a node — includes live state
```powershell
Invoke-RestMethod -Uri "$EMServer/api/v1/servers/$ServerName/tasks" -Method Get -Headers $SessionHeaders -UseBasicParsing
```
Returns `.taskList`, each entry has `name`, `state` (RUNNING/STOPPED/ERROR/...), `stop_reason` (NONE/NORMAL/FULL_LOAD_ONLY_FINISHED/FATAL_ERROR/...), `message`, `assigned_tags`. State and stop_reason from the `/tasks` list is the authoritative source of truth.

### Interpreting `stop_reason` on a STOPPED task
- `FULL_LOAD_ONLY_FINISHED` — expected, one-time load task finished as designed. Not a problem.
- `NORMAL` — someone manually stopped it. Worth investigating if unexpected.
- `FATAL_ERROR` / `RECOVERABLE_ERROR` — real failure; cross-check with task logs/audit data for actual error text.

## 6. Helper scripts strategy

Create and maintain reusable scripts:
- `qlik_em_save_cred.ps1` — one-time credential save.
- `qlik_em_tasks.ps1` — lists every task name on every node.
- `qlik_em_status.ps1` — lists every task with `state` + `stop_reason` on every node.

For new asks, prefer editing existing script loops over starting from zero — login/session/loop scaffolding is already proven.
