---
name: qlik_trouble
description: Connect to a Qlik Replicate (Attunity) server, list/inspect replication tasks, check live task status, and pull real error/warning detail from task audit and error logs. Use whenever the user asks about Qlik Replicate tasks, task status, replication errors, or troubleshooting a specific server.
---

# Qlik Replicate Troubleshooting

Works against any Qlik Replicate (formerly Attunity Replicate) Windows server reachable via WinRM. Treat paths/drive letters as *discovered per server*, not hardcoded, since they differ between boxes.

## Known Qlik Replicate servers

- `<Server1>` — install root on `<Drive>:` drive, X tasks
- `<Server2>` — install root on `<Drive>:` drive, Y tasks
- `<Server3>` — install root on `<Drive>:` drive, Z tasks

(Add other servers here as you work with them — name, drive letter, task count/notes.)

## Task & endpoint naming convention

General task name shape: `<SOURCE_CODE>_<TARGET>_<SUFFIX>`

- **Source/target server codes** — `<Env><Role><Instance>`:
  - `MD` = Dev environment, `MP` = Production, `MU` = UAT, `MQ` = QA-parallel, `MS` = Staging
  - A leading `TDC` (e.g. `TDCMPHRPD01`) marks a task on/replicating through a datacenter node.
- **Snowflake target endpoints**: `SF_<ENV>_<ZONE>_<DATASET>` — `ENV`=`DEV01`/`PRD01`/`UAT01`, `ZONE`=`LZ` (Landing Zone) / `ODS` (modeled) / `LG` (alias for LZ)
- **Non-Snowflake (SQL-to-SQL) targets**: `<TargetServerCode>_<DBName>` (no env/zone)
- **Log Stream suffixes**: `_LSP` = Parent (reads source DB transaction log once), `_LSC` = Child (consumes parent's stream)
- **`TSF`** = TRANSACTION_STEP_FACT — split into separate child task for heavy tables
- **Non-conforming**: ad-hoc/personal tasks may skip convention entirely

## 1. Connect

Requires WinRM (port 5985) open to the target and domain admin credentials active in the session (no separate login needed if already elevated).

```powershell
Invoke-Command -ComputerName <server> -ScriptBlock { ... }
```

Sanity check services first:
```powershell
Invoke-Command -ComputerName <server> -ScriptBlock {
  Get-Service | Where-Object { $_.Name -like '*Attunity*' -or $_.Name -like '*Replicate*' } |
    Select-Object Name,Status,DisplayName
}
```
Expect: `AttunityEnterpriseManager`, `AttunityReplicateConsole`, `QlikReplicateServer`.

## 2. Discover install paths (don't hardcode the drive letter)

The service binary path tells you everything — drive letter varies per server:
```powershell
Invoke-Command -ComputerName <server> -ScriptBlock {
  (Get-CimInstance Win32_Service -Filter "Name='QlikReplicateServer'").PathName
}
```
Output looks like:
```
"D:\Program Files\Attunity\Replicate\bin\repctl.exe" -d "D:\Program Files\Attunity\Replicate\data" service start name=QlikReplicateServer address=127.0.0.1 port=3550
```
That gives you `$exe` (repctl.exe path) and `$dd` (data dir) directly — parse them out rather than assuming `C:\`.

### Standard directory layout under `<data>`
```
<data>\
  GlobalRepo.sqlite          <- master repo (locked while service runs)
  service.url                <- e.g. https://<host>/attunityreplicate (UI URL)
  logs\                       <- repctl CLI logs only (repcmd*.log)
  tasks\<TaskName>\           <- one folder per task
  databases\, ssl\, tmp\, minidumps\
```

### Per-task directory: `<data>\tasks\<TaskName>\`
```
task_audit.sqlite                          <- ** the key file ** — full event/status/error log
task_errors.sqlite                         <- per-record/table-level data errors
task_tables.sqlite, dynamic_metadata.sqlite, notifications.sqlite, deferred_target_apply_operations.sqlite
<TaskName>.repo                            <- task's own repo copy
StateManager\, sorter\                     <- subfolders
```

## 3. repctl — the CLI

Syntax: `repctl [-d <datadir>] <command> arg=value ... ; <command> ...`

Discover commands/schemas live rather than guessing argument names:
```powershell
& $exe help                                    # top-level syntax
& $exe help option=HELP_COMMAND_LIST           # full command list
& $exe help command=<commandname>              # exact request/response schema for one command
```

### List all tasks
```powershell
& $exe -d $dd connect ';' gettasklist search_pattern=%
```
**Gotcha:** the wildcard is SQL-style `%`, not `*`. Only `%` (or an exact task name) works.

Returns `name`, `description`, `source_name`, `target_names`, `task_type` (LOG_STREAM parent/child, REGULAR, etc.) for every task.

### Get live status of one task
```powershell
& $exe -d $dd connect ';' gettaskstatus task=<TaskName>
```
**Gotcha:** the argument is `task=`, not `name=`. Passing the wrong key fails with "Unknown argument name".

Key response fields: `state` (STOPPED/STARTING/RUNNING/PAUSED/STOPPING/ERROR/NOT_EXIST/RECOVERY), `stop_reason` (NORMAL/RECOVERABLE_ERROR/FATAL_ERROR/FULL_LOAD_ONLY_FINISHED/STOPPED_AFTER_FULL_LOAD/.../RECYCLE_TASK), `cdc_latency`, `data_error_count`.

**Important:** tasks showing `STOPPED` with `stop_reason=FULL_LOAD_ONLY_FINISHED` are usually working as designed (one-time load tasks) — not failures. Only flag `FATAL_ERROR` / `RECOVERABLE_ERROR` / unexpected `STOPPED` as real problems.

### Querying many tasks at once

Chain everything into a single `connect` session to avoid spawning one repctl process per task:
```powershell
$argl = @('-d', $dd, 'connect')
foreach ($t in $taskNames) { $argl += ';'; $argl += 'gettaskstatus'; $argl += "task=$t" }
& $exe @argl
```
Parse the output by splitting on `(?=\{\s*\r?\n\s*"task_status":)` and regex-extracting `"name"`, `"state"`, `"stop_reason"` per chunk.

### Alerts/audit via repctl: usually doesn't work remotely

`gettaskalerts` and `gettaskaudit` are valid commands, but calling them from a fresh `repctl connect` session against the main server socket returns either an error or bare output with no `events` array. They appear to need task-scoped connections. **Don't burn time on these — go straight to the sqlite files instead.**

## 4. Pulling real error text — direct SQLite read

There's no `sqlite3.exe` CLI on these boxes, but the Replicate bin folder ships `System.Data.SQLite.dll` — load it with `Add-Type` and query directly, read-only.

```powershell
Add-Type -Path (Join-Path (Split-Path $exe) 'System.Data.SQLite.dll')
$dbPath = Join-Path $dd "tasks\$TaskName\task_audit.sqlite"
$conn = New-Object System.Data.SQLite.SQLiteConnection("Data Source=$dbPath;Read Only=True;")
$conn.Open()
$cmd = $conn.CreateCommand()
$cmd.CommandText = "SELECT seq_num,event_type,event_group,time_stamp,status_code,status_text FROM task_audit ORDER BY rowid DESC LIMIT 20"
$rdr = $cmd.ExecuteReader()
while ($rdr.Read()) { "$($rdr['time_stamp']) | $($rdr['event_type']) | $($rdr['status_text'])" }
$conn.Close()
```

`task_audit` table columns: `seq_num, event_type, event_group, time_stamp, component, table_owner, table_name, counter, status_code, status_text, status_desc, payload`.

**Timestamp format:** `time_stamp` is **microseconds** since Unix epoch (UTC). Convert with:
```powershell
$epoch = [DateTime]'1970-01-01Z'
$readable = $epoch.AddMilliseconds([double]$rdr['time_stamp']/1000)
```

### Sweep every task for errors/warnings in a time window

```powershell
$cutoffMicro = [int64](((Get-Date).ToUniversalTime().AddHours(-24) - [DateTime]'1970-01-01Z').TotalMilliseconds * 1000)
Get-ChildItem (Join-Path $dd 'tasks') -Directory | ForEach-Object {
  $db = Join-Path $_.FullName 'task_audit.sqlite'
  if (Test-Path $db) {
    $conn = New-Object System.Data.SQLite.SQLiteConnection("Data Source=$db;Read Only=True;")
    $conn.Open()
    $cmd = $conn.CreateCommand()
    $cmd.CommandText = "SELECT time_stamp,event_type,status_code,status_text FROM task_audit WHERE time_stamp >= @c AND event_type IN (1002,1003,55,6) ORDER BY time_stamp DESC"
    $cmd.Parameters.AddWithValue('@c',$cutoffMicro) | Out-Null
    $rdr = $cmd.ExecuteReader()
    while ($rdr.Read()) { [pscustomobject]@{ Task=$_.Name; Time=$rdr['time_stamp']; Text=$rdr['status_text'] } }
    $conn.Close()
  }
}
```
This is the fastest way to answer "what errored recently across all tasks" — far more reliable than the live `data_error_count` counter.

### Per-record data errors: `task_errors.sqlite`

Table `task_errors` columns: `target_name, owner, name, timestamp, sql_statement, error_type, error_msg`. Query the same way. Can be empty even for tasks with a nonzero live error counter — that's a known discrepancy.

## 5. Quick playbook for "why did task X fail / what's its status"

1. Discover paths on the server (`Win32_Service` → `$exe`, `$dd`).
2. `gettasklist search_pattern=%` if you don't know the exact task name (case/spacing matters).
3. `gettaskstatus task=<name>` for current `state` + `stop_reason`.
4. If `state=ERROR` or `stop_reason` is anything other than `NORMAL`/`FULL_LOAD_ONLY_FINISHED`/`STOPPED_AFTER_FULL_LOAD`, query `task_audit.sqlite` for that task (`ORDER BY rowid DESC LIMIT 10`) to get the actual `status_text`.
5. For row-level apply failures on a target table, also check `task_errors.sqlite`.
