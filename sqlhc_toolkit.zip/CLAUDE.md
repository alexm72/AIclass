# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this is

A SQL Server health check tool. `sqlhc.sql` queries ~35 DMVs and emits a self-contained HTML report entirely via `PRINT` statements — there is no result set. Output appears in the SSMS **Messages tab**, not the Results tab.

All scripts resolve paths dynamically (`$PSScriptRoot` in PowerShell, `%~dp0` in batch) so the folder can be placed anywhere. Reports are written to a `sqlhc\` subfolder beside the scripts.

## Running a report

**From SSMS (manual):**
1. Set query timeout to 0 (Query Options → Execution → timeout = 0)
2. Execute `sqlhc.sql` against the target server
3. Go to the **Messages tab**, select all, paste into Notepad, save as `.html`

**From command line / Task Scheduler:**
```bat
sqlhc_run.bat ServerName
```

**Via the web UI:**
```bat
sqlhc_launch.bat        # prompts for username, launches sqlhc_web.ps1 via runas /savecred
```
The web server listens on `http://+:8080/`. It requires either admin rights or a one-time URL reservation:
```
netsh http add urlacl url=http://+:8080/ user=DOMAIN\username
```

**Email delivery:**
```powershell
.\sqlhc_email.ps1 -Server MP-MBC-D01
.\sqlhc_email.ps1 -Server MP-MBC-D01,MP-HRP-D03 -To "team@company.com"
```

All runners invoke `sqlcmd -S <srv> -E -i sqlhc.sql -o <file> -h -1 -W`. The `-h -1` flag suppresses column headers; `-W` strips trailing spaces — both required for clean HTML output.

## Architecture of sqlhc.sql

The script has three phases:

**1. Collect** — DECLARE scalar variables and query DMVs into them. Each risky DMV is wrapped in `BEGIN TRY/CATCH` so a permission failure on one DMV does not abort the report.

**2. Populate summary** — INSERT rows into `#R (id, sec, chk, st, det, act)` where `st` is `HEALTHY` / `WARNING` / `CRITICAL`. This drives the color-coded scorecard at the top of the report. All threshold logic lives in these INSERT statements.

**3. Generate HTML via PRINT** — Build the full HTML document into `@h NVARCHAR(MAX)`, then chunk it out via `PRINT` in 4000-character tag-safe slices. Each section reads from a dedicated temp table and appends `<tr>` rows. CSS and JS are inlined in the opening block.

**Report sections (35 total):**
- *Current/real-time:* Executive Summary, Blocking Tree, Active Sessions, Active Sessions + SQL Text, Current Waits, Memory Grants, TempDB, TempDB Consumers, Connections by DB, Open Transactions, Running Jobs, NUMA, TPS
- *Historical/config:* Top Waits, Top CPU Sessions, Users by CPU%, Top Memory Sessions, Users by Mem%, Memory Pressure, CPU Pressure, I/O Latency, DB Sizes, Drives, Failed Jobs, Config, Suspect Pages, Error Log, Trace Flags
- *New Insights:* Top Queries, Missing Indexes, Backup Status, Plan Cache, Memory Clerks, AG Health, Unused Indexes, Lock Escalations

## Coding guidelines

### 1. Think Before Coding

**Don't assume. Don't hide confusion. Surface tradeoffs.**

Before implementing:
- State your assumptions explicitly. If uncertain, ask.
- If multiple interpretations exist, present them — don't pick silently.
- If a simpler approach exists, say so. Push back when warranted.
- If something is unclear, stop. Name what's confusing. Ask.

### 2. Simplicity First

**Minimum code that solves the problem. Nothing speculative.**

- No features beyond what was asked.
- No abstractions for single-use code.
- No "flexibility" or "configurability" that wasn't requested.
- No error handling for impossible scenarios.
- If you write 200 lines and it could be 50, rewrite it.

Ask yourself: "Would a senior engineer say this is overcomplicated?" If yes, simplify.

### 3. Surgical Changes

**Touch only what you must. Clean up only your own mess.**

When editing existing code:
- Don't "improve" adjacent code, comments, or formatting.
- Don't refactor things that aren't broken.
- Match existing style, even if you'd do it differently.
- If you notice unrelated dead code, mention it — don't delete it.

When your changes create orphans:
- Remove imports/variables/functions that YOUR changes made unused.
- Don't remove pre-existing dead code unless asked.

The test: Every changed line should trace directly to the user's request.

### 4. Goal-Driven Execution

**Define success criteria. Loop until verified.**

For multi-step tasks, state a brief plan:
```
1. [Step] → verify: [check]
2. [Step] → verify: [check]
3. [Step] → verify: [check]
```

Strong success criteria let you loop independently. Weak criteria ("make it work") require constant clarification.

## Key implementation patterns

**Temp table creation** — Always use `CREATE TABLE #name(...) / BEGIN TRY INSERT INTO #name ... END TRY BEGIN CATCH END CATCH`. Never use `SELECT...INTO` inside a TRY/CATCH block — if TRY succeeds in creating the table, the CATCH also runs and hits "object already exists".

**COLLATE DATABASE_DEFAULT** — Every `VARCHAR` column in every temp table must include this collation to prevent "cannot resolve collation conflict" errors when joining across databases with different collations.

**Top Queries pattern** — Always apply `TOP N` inside a CTE *before* the `CROSS APPLY sys.dm_exec_sql_text(...)`. This limits text lookups to N rows and keeps the query under 2 seconds even on servers with large plan caches.

**Wait type filtering** — `#W` (top waits) excludes a large hardcoded `NOT IN(...)` list of benign background waits. Add new benign waits to that list — not to a separate filter.

**HTML escaping in SQL text** — Any section displaying user SQL must sanitize with `REPLACE(..., N'<', N'&lt;')` and `N'>'` → `N'&gt;'` before PRINTing into HTML.

**sqlcmd encoding** — `sqlcmd` outputs Windows-1252 but the HTML declares UTF-8. `sqlhc_email.ps1` re-encodes after generation:
```powershell
$raw = [System.IO.File]::ReadAllText($outFile, [System.Text.Encoding]::Default)
[System.IO.File]::WriteAllText($outFile, $raw, [System.Text.Encoding]::UTF8)
```
New sections with special characters need this re-encoding step to display correctly in email.
