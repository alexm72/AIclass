# sqlhc — SQL Server Health Check

Self-contained SQL Server health check tool. `sqlhc.sql` queries ~35 DMVs and
generates a single HTML report (scorecard + 35 sections covering current
activity, historical waits/CPU/memory, config, and index/backup/AG health).
No permanent objects are created on the target server — everything runs via
temp tables and read-only DMV queries.

## Dependencies

| Requirement | Notes |
|---|---|
| `sqlcmd` | Must be on `PATH`. Ships with SQL Server tools / [Microsoft Command Line Utilities](https://learn.microsoft.com/sql/tools/sqlcmd/sqlcmd-utility) or `winget install Microsoft.Sqlcmd`. |
| Windows Authentication | All runners connect with `sqlcmd -E` (trusted connection). No SQL logins/passwords are used or stored anywhere. |
| SQL Server permissions | The connecting Windows account needs `VIEW SERVER STATE` (and ideally `sysadmin` or equivalent read access) on the target instance to populate all 35 sections. Sections behind denied DMVs fail gracefully (each is wrapped in `TRY/CATCH`) rather than aborting the report. |
| PowerShell | Required only for `sqlhc_web.ps1` and `sqlhc_email.ps1`. Windows PowerShell 5.1 (built into Windows) is sufficient — no external modules needed. |
| Administrator rights | Required only for `sqlhc_web.ps1` (binds an HTTP listener) — or a one-time `netsh http add urlacl` reservation instead (see below). |
| Browser | Chrome/Edge recommended to view the generated HTML reports (uses modern CSS/JS for the interactive scorecard). |
| SMTP relay | Required only for `sqlhc_email.ps1` — an internal relay (e.g. `appmail.azblue.com:25`, unauthenticated) is the default; SMTP-auth is supported via `-SmtpAuth` if your relay requires it. |

No database changes, no installed components, no scheduled services — this is
a folder of scripts you place anywhere and run.

## Deployment

1. Copy this entire folder to the target machine (or a central admin
   workstation that has network access to your SQL Servers) — e.g.
   `C:\DBA\sqlhc\`. All scripts resolve their own paths dynamically
   (`$PSScriptRoot` / `%~dp0`), so the folder works from any location.
2. Confirm `sqlcmd` runs from that machine (`sqlcmd -?`). Install the
   [Microsoft Command Line Utilities](https://learn.microsoft.com/sql/tools/sqlcmd/sqlcmd-utility)
   if it's missing.
3. Confirm the account you'll run as has network/firewall access and
   `VIEW SERVER STATE` on each target SQL Server.
4. Reports are written to a `sqlhc\` subfolder created next to the scripts
   the first time any runner executes — no manual setup needed.
5. (Optional, for the web UI only) Reserve the HTTP URL once so it doesn't
   require admin rights on every run:
   ```bat
   netsh http add urlacl url=http://+:8080/ user=DOMAIN\username
   ```
6. (Optional, for scheduled email reports) Register `sqlhc_email.ps1` as a
   Windows Task Scheduler task — see [Scheduling](#scheduling-a-daily-email-report) below.

## Usage

### 1. Manual, from SSMS

1. Open `sqlhc.sql` in SSMS against the target server.
2. Set query timeout to 0: **Query → Query Options → Execution → Execution
   time-out = 0**.
3. Execute the script. Output appears in the **Messages tab** (not Results —
   the whole report is emitted via `PRINT`).
4. Select all in the Messages tab, paste into Notepad, save as `report.html`,
   open in a browser.

### 2. Command line / one-off — `sqlhc_run.bat`

```bat
sqlhc_run.bat ServerName
```

- Runs `sqlcmd -S <ServerName> -E -i sqlhc.sql -o <file> -h -1 -W`.
- Writes to `sqlhc\sqlhc_<ServerName>_<timestamp>.html`.
- No parameters beyond the server name; supports named instances
  (`HOST\INSTANCE`) since `sqlcmd -S` accepts them natively.

### 3. Web UI — `sqlhc_launch.bat` + `sqlhc_web.ps1`

```bat
sqlhc_launch.bat
```

- Prompts for a Windows username (defaults to the current user), then
  launches `sqlhc_web.ps1` via `runas /savecred` — the password is cached by
  Windows Credential Manager after the first run, not stored in this folder.
- Starts an HTTP listener on `http://+:8080/` (edit `$Port` at the top of
  `sqlhc_web.ps1` to change it).
- Open `http://localhost:8080` in a browser:
  - Enter a server name/instance and submit → runs the report and streams
    the HTML back directly in the browser (~10 seconds).
  - **`/history`** — lists the last 50 saved reports in the `sqlhc\` folder.
  - **`/file?name=<file>`** — serves a specific saved report.
- Requires either Administrator rights or the `netsh http add urlacl`
  reservation from step 5 above.
- Stop with **Ctrl+C** in the PowerShell window (or close it).
- You can also run `sqlhc_web.ps1` directly instead of through the batch
  file: `powershell -ExecutionPolicy Bypass -File sqlhc_web.ps1`.

### 4. Scheduled email report — `sqlhc_email.ps1`

```powershell
.\sqlhc_email.ps1 -Server MP-MBC-D01
.\sqlhc_email.ps1 -Server MP-MBC-D01 -To "team@company.com"
.\sqlhc_email.ps1 -Server MP-MBC-D01,MP-HRP-D03,MP-HRP-D06
```

Runs the health check against one or more servers, generates a report for
each, and emails a summary (pass/fail table) with the successful HTML
reports attached.

#### Parameters

| Parameter | Default | Description |
|---|---|---|
| `-Server` | *(required)* | One or more server names/instances, comma-separated. |
| `-To` | `rama.nuthalapati@azblue.com` | Recipient address(es); comma/semicolon-separated. |
| `-Cc` | *(none)* | Optional CC address(es). |
| `-From` | `AWR-Report@azblue.com` | Sender address. |
| `-SmtpServer` | `appmail.azblue.com` | SMTP relay host. |
| `-SmtpPort` | `25` | SMTP port (`25` = relay, `587` = typical auth/TLS submission port). |
| `-UseSsl` | off | Switch — enables SSL/TLS to the SMTP server. |
| `-SmtpAuth` | off | Switch — if set, prompts interactively (`Get-Credential`) for SMTP credentials instead of using default/anonymous relay credentials. Nothing is stored to disk. |
| `-ScriptPath` | `sqlhc.sql` next to the script | Override the path to the `.sql` script. |
| `-OutputDir` | `sqlhc\` next to the script | Override where generated HTML reports are saved. |

#### Scheduling a daily email report

Register in Windows Task Scheduler:

```
Program:   powershell.exe
Arguments: -ExecutionPolicy Bypass -File "C:\DBA\sqlhc\sqlhc_email.ps1" -Server MP-MBC-D01,MP-HRP-D03
Trigger:   Daily, e.g. 7:00 AM
Run as:    a Windows account with VIEW SERVER STATE on the target servers
```

Since auth is Windows-integrated (`-E`), the task's "Run as" account must
have the needed DB permissions, and "Run whether user is logged on or not"
should be checked if the account isn't interactively logged in.

## Report contents (35 sections)

- **Current/real-time:** Executive Summary, Blocking Tree, Active Sessions,
  Active Sessions + SQL Text, Current Waits, Memory Grants, TempDB, TempDB
  Consumers, Connections by DB, Open Transactions, Running Jobs, NUMA, TPS
- **Historical/config:** Top Waits, Top CPU Sessions, Users by CPU%, Top
  Memory Sessions, Users by Mem%, Memory Pressure, CPU Pressure, I/O Latency,
  DB Sizes, Drives, Failed Jobs, Config, Suspect Pages, Error Log, Trace Flags
- **New Insights:** Top Queries, Missing Indexes, Backup Status, Plan Cache,
  Memory Clerks, AG Health, Unused Indexes, Lock Escalations

The scorecard at the top of the report color-codes each check as
**HEALTHY** / **WARNING** / **CRITICAL**.

## Notes / gotchas

- The report is **read-only** — no data is modified, no permanent objects are
  created on the target server.
- A failure in any single DMV query (e.g. missing permission) is caught and
  skipped; it will not abort the rest of the report.
- `sqlcmd` outputs Windows-1252; the runners (`sqlhc_email.ps1`) re-encode
  the file to UTF-8 after generation so special characters render correctly.
- No credentials, API keys, or secrets are stored anywhere in this folder —
  see [CLAUDE.md](CLAUDE.md) for the full architecture/coding notes if you're
  modifying `sqlhc.sql`.
