-- ================================================================
-- SQL SERVER WORKLOAD REPOSITORY REPORT v3.2 (COMPLETE)
-- Current-first layout | Jobs | Wait guidance | sqlhc style
-- All 27 sections fully rendered in HTML with reading guidance
-- ================================================================
-- STEPS TO GET HTML:
--   1. Set timeout to 0: Right-click query > Query Options >
--      Execution > General > Execution time-out = 0
--   2. Execute this script (normal mode, no need for Ctrl+T)
--   3. Go to MESSAGES TAB (not Results tab)
--   4. Select ALL text in Messages tab (Ctrl+A)
--   5. Paste into Notepad, save as .html
--   6. Open .html in Chrome/Edge
-- ================================================================
SET NOCOUNT ON;
SET ANSI_WARNINGS OFF;
SET ARITHIGNORE ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
SET LOCK_TIMEOUT 5000;

-- Summary
IF OBJECT_ID('tempdb..#R') IS NOT NULL DROP TABLE #R;
CREATE TABLE #R(id INT IDENTITY,sec VARCHAR(100) COLLATE DATABASE_DEFAULT,chk VARCHAR(200) COLLATE DATABASE_DEFAULT,st VARCHAR(20) COLLATE DATABASE_DEFAULT,det VARCHAR(2000) COLLATE DATABASE_DEFAULT,act VARCHAR(2000) COLLATE DATABASE_DEFAULT);

-- ============================================================
-- COLLECT METRICS
-- ============================================================
DECLARE @srv VARCHAR(200),@ver VARCHAR(200),@ed VARCHAR(200),@up INT,@cpu INT,@ram INT,@sdt DATETIME;
SELECT @srv=@@SERVERNAME,@ver=CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(200)),@ed=CAST(SERVERPROPERTY('Edition') AS VARCHAR(200)),
  @up=DATEDIFF(DAY,sqlserver_start_time,GETDATE()),@cpu=cpu_count,@ram=physical_memory_kb/1024/1024,@sdt=sqlserver_start_time FROM sys.dm_os_sys_info;

DECLARE @maxmem BIGINT;SELECT @maxmem=ISNULL(CAST(value_in_use AS BIGINT),0) FROM sys.configurations WHERE name='max server memory (MB)';
DECLARE @osst VARCHAR(100),@osfr BIGINT,@ostot BIGINT;
SELECT @osst=CAST(system_memory_state_desc AS VARCHAR(100)),@osfr=available_physical_memory_kb/1024,@ostot=total_physical_memory_kb/1024 FROM sys.dm_os_sys_memory;
SET @osst=ISNULL(@osst,'Unknown');

DECLARE @ple BIGINT,@gp BIGINT,@tmk BIGINT,@tgtk BIGINT;
SELECT @ple=MAX(CASE WHEN RTRIM(counter_name)='Page life expectancy' THEN cntr_value END),
  @gp=MAX(CASE WHEN RTRIM(counter_name)='Memory Grants Pending' THEN cntr_value END),
  @tmk=MAX(CASE WHEN RTRIM(counter_name)='Total Server Memory (KB)' THEN cntr_value END),
  @tgtk=MAX(CASE WHEN RTRIM(counter_name)='Target Server Memory (KB)' THEN cntr_value END)
FROM(SELECT RTRIM(counter_name) AS counter_name,cntr_value,ROW_NUMBER() OVER(PARTITION BY RTRIM(counter_name) ORDER BY object_name) AS rn
  FROM sys.dm_os_performance_counters WHERE(object_name LIKE '%Buffer Manager%' AND RTRIM(counter_name)='Page life expectancy')
  OR(object_name LIKE '%Memory Manager%' AND RTRIM(counter_name) IN('Memory Grants Pending','Total Server Memory (KB)','Target Server Memory (KB)')))x WHERE rn=1;
SET @ple=ISNULL(@ple,0);SET @gp=ISNULL(@gp,0);SET @tmk=ISNULL(@tmk,0);SET @tgtk=ISNULL(@tgtk,0);

DECLARE @blk INT,@bw INT,@sblk INT;
SELECT @blk=COUNT(*),@bw=ISNULL(MAX(wait_time)/1000,0) FROM sys.dm_exec_requests WHERE blocking_session_id!=0;
SELECT @sblk=COUNT(*) FROM sys.dm_exec_sessions s WHERE s.session_id IN(SELECT blocking_session_id FROM sys.dm_exec_requests WHERE blocking_session_id!=0) AND s.session_id NOT IN(SELECT session_id FROM sys.dm_exec_requests);

DECLARE @ts INT,@rs INT,@lq INT;
SELECT @ts=COUNT(*),@rs=SUM(CASE WHEN r.session_id IS NOT NULL THEN 1 ELSE 0 END) FROM sys.dm_exec_sessions s LEFT JOIN sys.dm_exec_requests r ON s.session_id=r.session_id WHERE s.is_user_process=1;
SELECT @lq=COUNT(*) FROM sys.dm_exec_requests r JOIN sys.dm_exec_sessions s ON r.session_id=s.session_id WHERE s.is_user_process=1 AND DATEDIFF(MINUTE,r.start_time,GETDATE())>30;

DECLARE @sp DECIMAL(10,1);SELECT @sp=ISNULL(CAST(ROUND(SUM(signal_wait_time_ms)*100.0/NULLIF(SUM(wait_time_ms),0),1) AS DECIMAL(10,1)),0) FROM sys.dm_os_wait_stats WHERE wait_time_ms>0;
DECLARE @rt INT;SELECT @rt=ISNULL(SUM(runnable_tasks_count),0) FROM sys.dm_os_schedulers WHERE scheduler_id<255 AND status='VISIBLE ONLINE';
DECLARE @pio INT;SELECT @pio=ISNULL(SUM(pending_disk_io_count),0) FROM sys.dm_os_schedulers WHERE scheduler_id<255;
DECLARE @mw INT,@mg INT;SELECT @mw=ISNULL(SUM(waiter_count),0),@mg=ISNULL(SUM(grantee_count),0) FROM sys.dm_exec_query_resource_semaphores;
DECLARE @sus INT;SELECT @sus=COUNT(*) FROM msdb.dbo.suspect_pages WHERE event_type IN(1,2,3);

DECLARE @otx INT,@otxm INT;SET @otx=0;SET @otxm=0;
BEGIN TRY SELECT @otx=COUNT(*),@otxm=ISNULL(MAX(DATEDIFF(MINUTE,tat.transaction_begin_time,GETDATE())),0)
FROM sys.dm_tran_active_transactions tat JOIN sys.dm_tran_session_transactions st ON tat.transaction_id=st.transaction_id
JOIN sys.dm_exec_sessions s ON st.session_id=s.session_id WHERE DATEDIFF(MINUTE,tat.transaction_begin_time,GETDATE())>5 AND s.is_user_process=1;
END TRY BEGIN CATCH END CATCH

DECLARE @odb INT,@asdb INT,@ncdb INT;
SELECT @odb=COUNT(CASE WHEN state_desc!='ONLINE' THEN 1 END),@asdb=COUNT(CASE WHEN is_auto_shrink_on=1 THEN 1 END),
  @ncdb=COUNT(CASE WHEN page_verify_option_desc!='CHECKSUM' AND state_desc='ONLINE' AND database_id>4 THEN 1 END) FROM sys.databases;

DECLARE @fj INT;SET @fj=0;
BEGIN TRY SELECT @fj=COUNT(*) FROM msdb.dbo.sysjobhistory WHERE run_status=0 AND run_date>=CAST(CONVERT(VARCHAR(8),DATEADD(DAY,-1,GETDATE()),112) AS INT);END TRY BEGIN CATCH END CATCH

DECLARE @dl BIGINT;SET @dl=0;SELECT @dl=ISNULL(cntr_value,0) FROM sys.dm_os_performance_counters WHERE RTRIM(counter_name)='Number of Deadlocks/sec' AND RTRIM(instance_name)='_Total';
DECLARE @tdp DECIMAL(10,1);SET @tdp=0;SELECT @tdp=ISNULL(CAST(ROUND(MAX(CAST(FILEPROPERTY(f.name,'SpaceUsed') AS BIGINT)*100.0/NULLIF(CAST(f.size AS BIGINT),0)),1) AS DECIMAL(10,1)),0) FROM tempdb.sys.database_files f WHERE f.type=0;
DECLARE @tp BIGINT;SET @tp=0;SELECT @tp=ISNULL(waiting_tasks_count,0) FROM sys.dm_os_wait_stats WHERE wait_type='THREADPOOL';
DECLARE @mdop INT,@cthr INT;SELECT @mdop=ISNULL(CAST(value_in_use AS INT),0) FROM sys.configurations WHERE name='max degree of parallelism';
SELECT @cthr=ISNULL(CAST(value_in_use AS INT),5) FROM sys.configurations WHERE name='cost threshold for parallelism';

IF OBJECT_ID('tempdb..#drv') IS NOT NULL DROP TABLE #drv;
CREATE TABLE #drv(dr VARCHAR(3) COLLATE DATABASE_DEFAULT,fm INT);
BEGIN TRY INSERT INTO #drv EXEC xp_fixeddrives;END TRY BEGIN CATCH END CATCH
DECLARE @dmn INT,@dlt VARCHAR(3);SELECT TOP 1 @dmn=ISNULL(fm,99999),@dlt=ISNULL(dr,'?') FROM #drv ORDER BY fm;
SET @dmn=ISNULL(@dmn,99999);SET @dlt=ISNULL(@dlt,'?');

DECLARE @iod VARCHAR(200),@iom BIGINT;SET @iod='N/A';SET @iom=0;
SELECT TOP 1 @iod=DB_NAME(vfs.database_id)+'('+CASE mf.type WHEN 0 THEN 'D' WHEN 1 THEN 'L' END+')',
  @iom=CASE WHEN(vfs.num_of_reads+vfs.num_of_writes)>0 THEN vfs.io_stall/(vfs.num_of_reads+vfs.num_of_writes) ELSE 0 END
FROM sys.dm_io_virtual_file_stats(NULL,NULL) vfs JOIN sys.master_files mf ON vfs.database_id=mf.database_id AND vfs.file_id=mf.file_id
WHERE(vfs.num_of_reads+vfs.num_of_writes)>100 ORDER BY CASE WHEN(vfs.num_of_reads+vfs.num_of_writes)>0 THEN vfs.io_stall/(vfs.num_of_reads+vfs.num_of_writes) ELSE 0 END DESC;
SET @iod=ISNULL(@iod,'N/A');SET @iom=ISNULL(@iom,0);

DECLARE @lgp DECIMAL(10,1),@lgd VARCHAR(200);SET @lgp=0;SET @lgd='N/A';
IF OBJECT_ID('tempdb..#ls') IS NOT NULL DROP TABLE #ls;
CREATE TABLE #ls(dn VARCHAR(200) COLLATE DATABASE_DEFAULT,lm DECIMAL(18,2),lp DECIMAL(18,2),s1 INT);
BEGIN TRY INSERT INTO #ls EXEC('DBCC SQLPERF(LOGSPACE) WITH NO_INFOMSGS');END TRY BEGIN CATCH END CATCH
SELECT TOP 1 @lgp=ISNULL(lp,0),@lgd=ISNULL(dn,'N/A') FROM #ls WHERE dn!='N/A' ORDER BY lp DESC;

DECLARE @dbgb BIGINT;SELECT @dbgb=ISNULL(SUM(CAST(mf.size AS BIGINT))*8/1024/1024,0) FROM sys.master_files mf JOIN sys.databases d ON mf.database_id=d.database_id WHERE d.state=0;

DECLARE @errc INT;SET @errc=0;
BEGIN TRY IF OBJECT_ID('tempdb..#elc') IS NOT NULL DROP TABLE #elc;
CREATE TABLE #elc(ld DATETIME,pi VARCHAR(100) COLLATE DATABASE_DEFAULT,lt NVARCHAR(MAX));
DECLARE @els DATETIME;SET @els=DATEADD(DAY,-1,GETDATE());INSERT INTO #elc EXEC sp_readerrorlog 0,1,N'Error',NULL,@els;
SELECT @errc=COUNT(*) FROM #elc WHERE pi!='INFO';DROP TABLE #elc;END TRY BEGIN CATCH END CATCH

-- ============================================================
-- POPULATE SUMMARY (with full guidance in Action column)
-- ============================================================
INSERT INTO #R VALUES('Instance','Server','INFO',ISNULL(@srv,''),'Instance name. Verify this is the intended target server.');
INSERT INTO #R VALUES('Instance','Version','INFO',ISNULL(@ver,'')+' - '+ISNULL(@ed,''),'Check if latest CU/SP is applied. Older builds may have known bugs.');
INSERT INTO #R VALUES('Instance','Uptime','INFO',CAST(ISNULL(@up,0) AS VARCHAR)+' days','Days since last restart. Very high = missed patching. Very low = recent crash?');
INSERT INTO #R VALUES('Instance','Hardware','INFO',CAST(ISNULL(@cpu,0) AS VARCHAR)+' CPUs | '+CAST(ISNULL(@ram,0) AS VARCHAR)+' GB RAM','Baseline hardware. Compare with workload needs and licensing.');
INSERT INTO #R VALUES('Instance','DB Size','INFO',CAST(ISNULL(@dbgb,0) AS VARCHAR)+' GB','Total allocated size across all databases. Monitor growth trends.');
INSERT INTO #R VALUES('** Blocking','** Active Blocking',CASE WHEN @blk>10 THEN 'CRITICAL' WHEN @blk>0 THEN 'WARNING' ELSE 'HEALTHY' END,CAST(@blk AS VARCHAR)+' blocked (max wait:'+CAST(@bw AS VARCHAR)+'s)',CASE WHEN @blk>10 THEN 'CRITICAL: >10 blocked. Find head blocker in Blocking Tree, KILL if needed.' WHEN @blk>0 THEN 'Some blocking detected. Check Blocking Tree section for head blocker.' ELSE 'No active blocking. Normal operation.' END);
INSERT INTO #R VALUES('** Blocking','** Sleeping Blockers',CASE WHEN @sblk>0 THEN 'CRITICAL' ELSE 'HEALTHY' END,CAST(@sblk AS VARCHAR)+' sleeping blockers',CASE WHEN @sblk>0 THEN 'Sleeping session holding locks. Likely orphaned connection. KILL immediately.' ELSE 'No sleeping blockers. Connections are releasing locks properly.' END);
INSERT INTO #R VALUES('** Blocking','Deadlocks',CASE WHEN @dl>100 THEN 'CRITICAL' WHEN @dl>10 THEN 'WARNING' ELSE 'HEALTHY' END,CAST(@dl AS VARCHAR)+' cumulative',CASE WHEN @dl>100 THEN 'High deadlock count since restart. Enable TF 1222, review deadlock graphs.' WHEN @dl>10 THEN 'Some deadlocks occurred. Enable TF 1222 to capture XML deadlock graphs.' ELSE 'Low or zero deadlocks. Cumulative since last restart.' END);
INSERT INTO #R VALUES('Memory','OS Memory',CASE WHEN @osst LIKE '%Low%' THEN 'CRITICAL' WHEN @osfr<@ostot*0.05 THEN 'WARNING' ELSE 'HEALTHY' END,@osst+' | Free:'+CAST(@osfr AS VARCHAR)+'MB',CASE WHEN @osst LIKE '%Low%' THEN 'OS reports low memory. SQL may be paged out. Check max server memory setting.' WHEN @osfr<@ostot*0.05 THEN 'Less than 5% OS memory free. Risk of paging. Review memory consumers.' ELSE 'OS memory sufficient. State should say Available Physical Memory Is High.' END);
INSERT INTO #R VALUES('Memory','PLE',CASE WHEN @ple<300 THEN 'CRITICAL' WHEN @ple<1000 THEN 'WARNING' ELSE 'HEALTHY' END,CAST(@ple AS VARCHAR)+' sec',CASE WHEN @ple<300 THEN 'Pages evicted in <5min. Severe buffer pool pressure. Add RAM or tune queries.' WHEN @ple<1000 THEN 'Moderate pressure. Pages stay ~16min. Watch for drops during peak.' ELSE 'Good buffer retention. Higher = data pages stay cached longer.' END);
INSERT INTO #R VALUES('Memory','** Grant Waiters',CASE WHEN @mw>5 THEN 'CRITICAL' WHEN @mw>0 THEN 'WARNING' ELSE 'HEALTHY' END,CAST(@mw AS VARCHAR)+' waiting | '+CAST(@mg AS VARCHAR)+' granted',CASE WHEN @mw>5 THEN 'Many queries queued for memory. Reduce MAXDOP, kill large queries, add RAM.' WHEN @mw>0 THEN 'Some queries waiting for memory grants. Check Resource Semaphore section.' ELSE 'No memory grant waiters. All queries getting memory immediately.' END);
INSERT INTO #R VALUES('Memory','SQL vs Target',CASE WHEN @tmk<@tgtk THEN 'WARNING' ELSE 'HEALTHY' END,'Curr:'+CAST(@tmk/1024 AS VARCHAR)+'MB Tgt:'+CAST(@tgtk/1024 AS VARCHAR)+'MB',CASE WHEN @tmk<@tgtk THEN 'SQL has not reached target. External memory pressure from OS or other apps.' ELSE 'SQL at or above target memory. Buffer pool is fully warmed up.' END);
INSERT INTO #R VALUES('Memory','Max Server Mem',CASE WHEN @maxmem=2147483647 THEN 'CRITICAL' WHEN @maxmem>@ostot*0.9 THEN 'WARNING' ELSE 'HEALTHY' END,CAST(@maxmem AS VARCHAR)+' MB',CASE WHEN @maxmem=2147483647 THEN 'UNLIMITED! Set to ~80% of total RAM. OS needs memory too.' WHEN @maxmem>@ostot*0.9 THEN 'Over 90% of RAM. Leave at least 4-8GB for OS and other services.' ELSE 'Properly capped. Should leave headroom for OS and other processes.' END);
INSERT INTO #R VALUES('Memory','** TempDB',CASE WHEN @tdp>90 THEN 'CRITICAL' WHEN @tdp>75 THEN 'WARNING' ELSE 'HEALTHY' END,CAST(@tdp AS VARCHAR)+'%',CASE WHEN @tdp>90 THEN 'TempDB near full. Check TempDB Consumers section. May need to kill sessions.' WHEN @tdp>75 THEN 'TempDB filling up. Check top consumers. May need larger files or cleanup.' ELSE 'TempDB usage normal. Check TempDB section for per-file breakdown.' END);
DECLARE @cwcnt INT,@cwtop VARCHAR(100);SET @cwcnt=0;SET @cwtop='None';
SELECT @cwcnt=COUNT(*) FROM sys.dm_exec_requests r JOIN sys.dm_exec_sessions s ON r.session_id=s.session_id WHERE s.is_user_process=1 AND r.wait_type IS NOT NULL AND r.wait_type!='';
SELECT TOP 1 @cwtop=r.wait_type+'('+CAST(COUNT(*) AS VARCHAR)+')' FROM sys.dm_exec_requests r JOIN sys.dm_exec_sessions s ON r.session_id=s.session_id WHERE s.is_user_process=1 AND r.wait_type IS NOT NULL AND r.wait_type!='' GROUP BY r.wait_type ORDER BY COUNT(*) DESC;
SET @cwtop=ISNULL(@cwtop,'None');
INSERT INTO #R VALUES('** Waits','** Current Waits',CASE WHEN @cwcnt>50 THEN 'CRITICAL' WHEN @cwcnt>20 THEN 'WARNING' ELSE 'HEALTHY' END,CAST(@cwcnt AS VARCHAR)+' sessions waiting. Top: '+@cwtop,CASE WHEN @cwcnt>50 THEN 'Over 50 sessions waiting. Check Current Waits section for wait types and blockers.' WHEN @cwcnt>20 THEN 'Elevated waits. Review Current Wait Events for patterns and top wait type.' ELSE 'Few or no active waits. Check Current Wait Events for details if any.' END);
INSERT INTO #R VALUES('CPU','Signal Wait',CASE WHEN @sp>25 THEN 'CRITICAL' WHEN @sp>15 THEN 'WARNING' ELSE 'HEALTHY' END,CAST(@sp AS VARCHAR)+'%',CASE WHEN @sp>25 THEN 'Over 25% signal waits = severe CPU bottleneck. Threads waiting for CPU time.' WHEN @sp>15 THEN 'Moderate CPU pressure. Optimize top CPU queries or plan for more cores.' ELSE 'Signal waits healthy. Threads get CPU time promptly after resource is ready.' END);
INSERT INTO #R VALUES('CPU','** Runnable Tasks',CASE WHEN @rt>20 THEN 'CRITICAL' WHEN @rt>10 THEN 'WARNING' ELSE 'HEALTHY' END,CAST(@rt AS VARCHAR)+' queued',CASE WHEN @rt>20 THEN 'Heavy CPU queue. Queries ready to run but no CPU available. Add cores or tune.' WHEN @rt>10 THEN 'CPU queue building. Check NUMA section for per-node breakdown.' ELSE 'No significant CPU queue. Schedulers processing work without delay.' END);
INSERT INTO #R VALUES('CPU','Threadpool',CASE WHEN @tp>0 THEN 'CRITICAL' ELSE 'HEALTHY' END,CAST(@tp AS VARCHAR)+' waits',CASE WHEN @tp>0 THEN 'THREADPOOL waits detected. Worker threads exhausted. Kill long queries immediately.' ELSE 'No thread pool exhaustion. Worker threads available for new requests.' END);
INSERT INTO #R VALUES('CPU','MAXDOP',CASE WHEN @mdop=0 THEN 'WARNING' ELSE 'HEALTHY' END,'MAXDOP='+CAST(@mdop AS VARCHAR),CASE WHEN @mdop=0 THEN 'MAXDOP=0 means unlimited parallelism. Set to 4-8 for OLTP, or half cores per NUMA.' ELSE 'MAXDOP configured. Typical best practice: 4-8 for OLTP workloads.' END);
INSERT INTO #R VALUES('CPU','Cost Threshold',CASE WHEN @cthr=5 THEN 'WARNING' ELSE 'HEALTHY' END,'Cost='+CAST(@cthr AS VARCHAR),CASE WHEN @cthr=5 THEN 'Default value 5 is too low. Increase to 25-50 to avoid trivial queries going parallel.' ELSE 'Cost threshold tuned above default. Review if CXPACKET waits are still high.' END);
INSERT INTO #R VALUES('Disk I/O','Worst Latency',CASE WHEN @iom>30 THEN 'CRITICAL' WHEN @iom>15 THEN 'WARNING' ELSE 'HEALTHY' END,ISNULL(@iod,'N/A')+'='+CAST(@iom AS VARCHAR)+'ms',CASE WHEN @iom>30 THEN 'Over 30ms avg latency. Storage cannot keep up. Check SAN, move to SSD/NVMe.' WHEN @iom>15 THEN 'Moderate latency. Check I/O Latency section for file-level detail.' ELSE 'I/O latency acceptable. Data <15ms, Log <5ms are healthy targets.' END);
INSERT INTO #R VALUES('Disk I/O','** Pending I/O',CASE WHEN @pio>50 THEN 'CRITICAL' WHEN @pio>20 THEN 'WARNING' ELSE 'HEALTHY' END,CAST(@pio AS VARCHAR)+' pending',CASE WHEN @pio>50 THEN 'Storage overloaded. Over 50 I/O requests queued. Check SAN or disk health.' WHEN @pio>20 THEN 'I/O queue building. Monitor for sustained spikes during ETL or reporting.' ELSE 'I/O queue is clear. Storage subsystem keeping up with demand.' END);
INSERT INTO #R VALUES('Disk I/O','Drive Space',CASE WHEN @dmn<1024 THEN 'CRITICAL' WHEN @dmn<5120 THEN 'WARNING' ELSE 'HEALTHY' END,ISNULL(@dlt,'?')+':='+CAST(@dmn AS VARCHAR)+'MB',CASE WHEN @dmn<1024 THEN 'Under 1GB free on lowest drive. DB growth or log will fail. Extend NOW.' WHEN @dmn<5120 THEN 'Under 5GB free. Plan disk extension soon. Check Drive Space section.' ELSE 'Disk space adequate. Check Drives section for per-drive breakdown.' END);
INSERT INTO #R VALUES('Disk I/O','Log Usage',CASE WHEN @lgp>90 THEN 'CRITICAL' WHEN @lgp>75 THEN 'WARNING' ELSE 'HEALTHY' END,ISNULL(@lgd,'N/A')+' at '+CAST(@lgp AS VARCHAR)+'%',CASE WHEN @lgp>90 THEN 'Log file near full. Check for open transactions, missing log backups, or replication lag.' WHEN @lgp>75 THEN 'Log file filling. Verify log backups running. Check Open Transactions section.' ELSE 'Log usage normal. Regular log backups keeping it in check.' END);
INSERT INTO #R VALUES('** Sessions','** Connections',CASE WHEN @ts>1000 THEN 'CRITICAL' WHEN @ts>500 THEN 'WARNING' ELSE 'HEALTHY' END,CAST(@ts AS VARCHAR)+' ('+CAST(ISNULL(@rs,0) AS VARCHAR)+' running)',CASE WHEN @ts>1000 THEN 'Over 1000 connections. Possible connection leak. Check Connections by DB section.' WHEN @ts>500 THEN 'Elevated connections. Review per-database breakdown for unusual patterns.' ELSE 'Connection count normal. Check Connections section for per-DB distribution.' END);
INSERT INTO #R VALUES('** Sessions','** Long Queries',CASE WHEN @lq>5 THEN 'CRITICAL' WHEN @lq>0 THEN 'WARNING' ELSE 'HEALTHY' END,CAST(@lq AS VARCHAR)+' > 30 min',CASE WHEN @lq>5 THEN 'Multiple long-running queries. Check Active Sessions. Kill or optimize them.' WHEN @lq>0 THEN 'Some queries running >30min. Verify if expected (ETL/reports) or stuck.' ELSE 'No queries over 30 minutes. All sessions processing within normal time.' END);
INSERT INTO #R VALUES('** Sessions','** Open Txn',CASE WHEN @otx>0 AND @otxm>60 THEN 'CRITICAL' WHEN @otx>0 THEN 'WARNING' ELSE 'HEALTHY' END,CAST(@otx AS VARCHAR)+' open (longest:'+CAST(@otxm AS VARCHAR)+'m)',CASE WHEN @otx>0 AND @otxm>60 THEN 'Transaction open >1hr. Blocks log truncation and causes bloat. Investigate and close.' WHEN @otx>0 THEN 'Open transactions >5min. May block log truncation. Check Open Txn section.' ELSE 'No long-open transactions. Log truncation proceeding normally.' END);
INSERT INTO #R VALUES('Integrity','Suspect Pages',CASE WHEN @sus>0 THEN 'CRITICAL' ELSE 'HEALTHY' END,CAST(@sus AS VARCHAR)+' pages',CASE WHEN @sus>0 THEN 'DATA CORRUPTION detected. Run DBCC CHECKDB immediately. Plan restore if needed.' ELSE 'No suspect pages. Database integrity is healthy.' END);
INSERT INTO #R VALUES('Integrity','Offline DBs',CASE WHEN @odb>0 THEN 'CRITICAL' ELSE 'HEALTHY' END,CAST(@odb AS VARCHAR)+' offline',CASE WHEN @odb>0 THEN 'Database(s) offline. Check error log for cause. May need restore or EMERGENCY mode.' ELSE 'All databases online. No availability issues detected.' END);
INSERT INTO #R VALUES('Integrity','Auto-Shrink',CASE WHEN @asdb>0 THEN 'WARNING' ELSE 'HEALTHY' END,CAST(@asdb AS VARCHAR)+' DBs',CASE WHEN @asdb>0 THEN 'Auto-shrink causes fragmentation and CPU spikes. Disable with ALTER DATABASE SET AUTO_SHRINK OFF.' ELSE 'Auto-shrink disabled on all DBs. This is the recommended setting.' END);
INSERT INTO #R VALUES('Agent','Failed Jobs 24h',CASE WHEN @fj>5 THEN 'CRITICAL' WHEN @fj>0 THEN 'WARNING' ELSE 'HEALTHY' END,CAST(@fj AS VARCHAR)+' failures',CASE WHEN @fj>5 THEN 'Many job failures. Check Failed Jobs section for patterns and error messages.' WHEN @fj>0 THEN 'Some failures in last 24h. Review Failed Jobs section for details.' ELSE 'All jobs succeeded in last 24 hours. Check Failed Jobs section to confirm.' END);
INSERT INTO #R VALUES('Errors','Error Log 24h',CASE WHEN @errc>50 THEN 'CRITICAL' WHEN @errc>10 THEN 'WARNING' ELSE 'HEALTHY' END,CAST(@errc AS VARCHAR)+' entries',CASE WHEN @errc>50 THEN 'Heavy error activity. Check Error Log section for repeated patterns or severity.' WHEN @errc>10 THEN 'Some errors logged. Review Error Log section for recurring issues.' ELSE 'Few or no errors. Check Error Log section for any noteworthy entries.' END);

-- ============================================================
-- DETAIL TEMP TABLES
-- ============================================================

-- Active sessions
IF OBJECT_ID('tempdb..#AS1') IS NOT NULL DROP TABLE #AS1;
SELECT TOP 25 ROW_NUMBER() OVER(ORDER BY CASE s.status WHEN 'running' THEN 0 ELSE 1 END,r.cpu_time DESC) AS rn,
  s.session_id AS sid,ISNULL(DB_NAME(r.database_id),'') COLLATE DATABASE_DEFAULT AS db,
  s.status COLLATE DATABASE_DEFAULT AS st,s.login_name COLLATE DATABASE_DEFAULT AS lg,
  s.host_name COLLATE DATABASE_DEFAULT AS hn,ISNULL(r.command,'') COLLATE DATABASE_DEFAULT AS cmd,
  ISNULL(r.wait_type,'') COLLATE DATABASE_DEFAULT AS wt,ISNULL(r.cpu_time,0) AS cm,
  DATEDIFF(MINUTE,s.login_time,GETDATE()) AS lm,ISNULL(DATEDIFF(MINUTE,r.start_time,GETDATE()),0) AS rm
INTO #AS1 FROM sys.dm_exec_sessions s LEFT JOIN sys.dm_exec_requests r ON s.session_id=r.session_id WHERE s.is_user_process=1;

-- Active sessions with SQL text (Top 10)
IF OBJECT_ID('tempdb..#AS2') IS NOT NULL DROP TABLE #AS2;
SELECT TOP 10 ROW_NUMBER() OVER(ORDER BY r.cpu_time DESC) AS rn,
  r.session_id AS sid,ISNULL(DB_NAME(r.database_id),'') COLLATE DATABASE_DEFAULT AS db,
  s.status COLLATE DATABASE_DEFAULT AS st,s.login_name COLLATE DATABASE_DEFAULT AS lg,
  s.host_name COLLATE DATABASE_DEFAULT AS hn,ISNULL(r.command,'') COLLATE DATABASE_DEFAULT AS cmd,
  ISNULL(r.wait_type,'') COLLATE DATABASE_DEFAULT AS wt,r.cpu_time AS cm,
  ISNULL(DATEDIFF(MINUTE,r.start_time,GETDATE()),0) AS rm,
  REPLACE(REPLACE(REPLACE(REPLACE(LEFT(ISNULL(SUBSTRING(qt.text,r.statement_start_offset/2+1,
    CASE WHEN r.statement_end_offset=-1 THEN LEN(qt.text) ELSE(r.statement_end_offset-r.statement_start_offset)/2+1 END),''),4000),
    CHAR(13),N' '),CHAR(10),N' '),N'<',N'&lt;'),N'>',N'&gt;') COLLATE DATABASE_DEFAULT AS sqltxt,
  REPLACE(REPLACE(REPLACE(REPLACE(LEFT(ISNULL(qt.text,''),4000),
    CHAR(13),N' '),CHAR(10),N' '),N'<',N'&lt;'),N'>',N'&gt;') COLLATE DATABASE_DEFAULT AS fullsql
INTO #AS2 FROM sys.dm_exec_requests r
JOIN sys.dm_exec_sessions s ON r.session_id=s.session_id
CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) qt
WHERE s.is_user_process=1 AND r.session_id!=@@SPID;

-- Blocking tree
IF OBJECT_ID('tempdb..#BT') IS NOT NULL DROP TABLE #BT;
;WITH BT AS(
  SELECT r.session_id AS sid,r.blocking_session_id AS bsid,DB_NAME(r.database_id) AS db,s.login_name AS lg,
    r.wait_type AS wt,r.wait_time/1000 AS ws,0 AS lv,CAST(r.session_id AS VARCHAR(MAX)) AS ch
  FROM sys.dm_exec_requests r JOIN sys.dm_exec_sessions s ON r.session_id=s.session_id
  WHERE r.blocking_session_id=0 AND r.session_id IN(SELECT blocking_session_id FROM sys.dm_exec_requests WHERE blocking_session_id!=0)
  UNION ALL
  SELECT r.session_id,r.blocking_session_id,DB_NAME(r.database_id),s.login_name,
    r.wait_type,r.wait_time/1000,bt.lv+1,bt.ch+' > '+CAST(r.session_id AS VARCHAR(MAX))
  FROM sys.dm_exec_requests r JOIN sys.dm_exec_sessions s ON r.session_id=s.session_id JOIN BT bt ON r.blocking_session_id=bt.sid)
SELECT sid,bsid,db COLLATE DATABASE_DEFAULT AS db,lg COLLATE DATABASE_DEFAULT AS lg,ISNULL(wt,'') COLLATE DATABASE_DEFAULT AS wt,ws,lv,ch COLLATE DATABASE_DEFAULT AS ch
INTO #BT FROM BT;

-- Current waits
IF OBJECT_ID('tempdb..#CW') IS NOT NULL DROP TABLE #CW;
SELECT TOP 15 ROW_NUMBER() OVER(ORDER BY r.wait_time DESC) AS rn,r.session_id AS sid,
  DB_NAME(r.database_id) COLLATE DATABASE_DEFAULT AS db,s.login_name COLLATE DATABASE_DEFAULT AS lg,
  r.wait_type COLLATE DATABASE_DEFAULT AS wt,r.wait_time/1000 AS ws,r.command COLLATE DATABASE_DEFAULT AS cmd,r.blocking_session_id AS bsid
INTO #CW FROM sys.dm_exec_requests r JOIN sys.dm_exec_sessions s ON r.session_id=s.session_id
WHERE s.is_user_process=1 AND r.wait_type IS NOT NULL AND r.wait_type!='';

-- Resource semaphore
IF OBJECT_ID('tempdb..#RS') IS NOT NULL DROP TABLE #RS;
SELECT pool_id AS pid,total_memory_kb/1024 AS tmb,available_memory_kb/1024 AS amb,granted_memory_kb/1024 AS gmb,used_memory_kb/1024 AS umb,grantee_count AS gc,waiter_count AS wc
INTO #RS FROM sys.dm_exec_query_resource_semaphores;

-- TempDB
IF OBJECT_ID('tempdb..#TD') IS NOT NULL DROP TABLE #TD;
SELECT f.name COLLATE DATABASE_DEFAULT AS fn,CASE f.type WHEN 0 THEN 'DATA' WHEN 1 THEN 'LOG' END COLLATE DATABASE_DEFAULT AS ft,
  CAST(f.size AS BIGINT)*8/1024 AS tmb,CAST(FILEPROPERTY(f.name,'SpaceUsed') AS BIGINT)*8/1024 AS umb,
  CAST(ROUND(CAST(FILEPROPERTY(f.name,'SpaceUsed') AS BIGINT)*100.0/NULLIF(CAST(f.size AS BIGINT),0),1) AS DECIMAL(10,1)) AS up
INTO #TD FROM tempdb.sys.database_files f;

-- TempDB top consumers
IF OBJECT_ID('tempdb..#TDC') IS NOT NULL DROP TABLE #TDC;
SELECT TOP 10 ROW_NUMBER() OVER(ORDER BY(t.user_objects_alloc_page_count+t.internal_objects_alloc_page_count) DESC) AS rn,
  t.session_id AS sid,s.login_name COLLATE DATABASE_DEFAULT AS lg,s.host_name COLLATE DATABASE_DEFAULT AS hn,
  DB_NAME(s.database_id) COLLATE DATABASE_DEFAULT AS db,
  (t.user_objects_alloc_page_count+t.internal_objects_alloc_page_count)*8/1024 AS tmb
INTO #TDC FROM sys.dm_db_session_space_usage t JOIN sys.dm_exec_sessions s ON t.session_id=s.session_id
WHERE s.is_user_process=1 AND(t.user_objects_alloc_page_count+t.internal_objects_alloc_page_count)>0;

-- Open transactions
IF OBJECT_ID('tempdb..#OT') IS NOT NULL DROP TABLE #OT;
CREATE TABLE #OT(sid INT,lg VARCHAR(200) COLLATE DATABASE_DEFAULT,hn VARCHAR(200) COLLATE DATABASE_DEFAULT,db VARCHAR(200) COLLATE DATABASE_DEFAULT,mn INT);
BEGIN TRY INSERT INTO #OT SELECT st.session_id,s.login_name,s.host_name,DB_NAME(dt.database_id),DATEDIFF(MINUTE,tat.transaction_begin_time,GETDATE())
FROM sys.dm_tran_active_transactions tat JOIN sys.dm_tran_database_transactions dt ON tat.transaction_id=dt.transaction_id
JOIN sys.dm_tran_session_transactions st ON tat.transaction_id=st.transaction_id JOIN sys.dm_exec_sessions s ON st.session_id=s.session_id
WHERE DATEDIFF(MINUTE,tat.transaction_begin_time,GETDATE())>5 AND s.is_user_process=1;END TRY BEGIN CATCH END CATCH

-- Connections by DB
IF OBJECT_ID('tempdb..#CN') IS NOT NULL DROP TABLE #CN;
SELECT DB_NAME(s.database_id) COLLATE DATABASE_DEFAULT AS db,COUNT(s.session_id) AS cnt,
  SUM(CASE WHEN s.status='running' THEN 1 ELSE 0 END) AS rn1,SUM(CASE WHEN s.status='sleeping' THEN 1 ELSE 0 END) AS sl,COUNT(DISTINCT s.login_name) AS ul
INTO #CN FROM sys.dm_exec_sessions s WHERE s.is_user_process=1 GROUP BY DB_NAME(s.database_id);

-- NUMA
IF OBJECT_ID('tempdb..#NU') IS NOT NULL DROP TABLE #NU;
SELECT parent_node_id AS nd,COUNT(*) AS sc,SUM(runnable_tasks_count) AS rtk,SUM(active_workers_count) AS aw,SUM(pending_disk_io_count) AS pi
INTO #NU FROM sys.dm_os_schedulers WHERE scheduler_id<255 AND status='VISIBLE ONLINE' GROUP BY parent_node_id;

-- Currently running jobs
IF OBJECT_ID('tempdb..#RJ') IS NOT NULL DROP TABLE #RJ;
CREATE TABLE #RJ(rn INT IDENTITY,jn VARCHAR(300) COLLATE DATABASE_DEFAULT,sn VARCHAR(300) COLLATE DATABASE_DEFAULT,sd DATETIME,dur VARCHAR(50) COLLATE DATABASE_DEFAULT);
BEGIN TRY
INSERT INTO #RJ(jn,sn,sd,dur)
SELECT j.name,ISNULL(ja.last_executed_step_id,0),ja.start_execution_date,
  CAST(DATEDIFF(MINUTE,ja.start_execution_date,GETDATE())/60 AS VARCHAR)+'h '+CAST(DATEDIFF(MINUTE,ja.start_execution_date,GETDATE())%60 AS VARCHAR)+'m'
FROM msdb.dbo.sysjobs j JOIN msdb.dbo.sysjobactivity ja ON j.job_id=ja.job_id
JOIN(SELECT job_id,MAX(session_id) AS sid FROM msdb.dbo.sysjobactivity GROUP BY job_id) mx ON ja.job_id=mx.job_id AND ja.session_id=mx.sid
WHERE ja.start_execution_date IS NOT NULL AND ja.stop_execution_date IS NULL;
END TRY BEGIN CATCH END CATCH

-- Failed jobs (last 24h)
IF OBJECT_ID('tempdb..#FJ') IS NOT NULL DROP TABLE #FJ;
CREATE TABLE #FJ(rn INT IDENTITY,jn VARCHAR(300) COLLATE DATABASE_DEFAULT,stp VARCHAR(300) COLLATE DATABASE_DEFAULT,rd DATETIME,msg VARCHAR(2000) COLLATE DATABASE_DEFAULT);
BEGIN TRY
INSERT INTO #FJ(jn,stp,rd,msg)
SELECT TOP 25 j.name,h.step_name,msdb.dbo.agent_datetime(h.run_date,h.run_time),LEFT(h.message,500)
FROM msdb.dbo.sysjobs j JOIN msdb.dbo.sysjobhistory h ON j.job_id=h.job_id
WHERE h.run_status=0 AND h.run_date>=CAST(CONVERT(VARCHAR(8),DATEADD(DAY,-1,GETDATE()),112) AS INT)
ORDER BY h.run_date DESC,h.run_time DESC;
END TRY BEGIN CATCH END CATCH

-- Top waits (with guidance)
IF OBJECT_ID('tempdb..#W') IS NOT NULL DROP TABLE #W;
;WITH WS AS(SELECT wait_type,waiting_tasks_count,wait_time_ms,signal_wait_time_ms,100.0*wait_time_ms/NULLIF(SUM(wait_time_ms) OVER(),0) AS pct
  FROM sys.dm_os_wait_stats WHERE wait_type NOT IN('CLR_SEMAPHORE','LAZYWRITER_SLEEP','RESOURCE_QUEUE','SQLTRACE_BUFFER_FLUSH','SLEEP_TASK','SLEEP_SYSTEMTASK','WAITFOR','HADR_FILESTREAM_IOMGR_IOCOMPLETION','CHECKPOINT_QUEUE','REQUEST_FOR_DEADLOCK_SEARCH','XE_TIMER_EVENT','XE_DISPATCH_WAIT','FT_IFTS_SCHEDULER_IDLE_WAIT','LOGMGR_QUEUE','BROKER_TO_FLUSH','BROKER_TASK_STOP','BROKER_EVENTHANDLER','DIRTY_PAGE_POLL','DBMIRROR_EVENTS_QUEUE','SP_SERVER_DIAGNOSTICS_SLEEP','HADR_WORK_QUEUE','ONDEMAND_TASK_QUEUE','DISPATCHER_QUEUE_SEMAPHORE','XE_LIVE_TARGET_TVF','BROKER_RECEIVE_WAITFOR','QDS_PERSIST_TASK_MAIN_LOOP_SLEEP','QDS_ASYNC_QUEUE','QDS_CLEANUP_STALE_QUERIES_TASK_MAIN_LOOP_SLEEP','SQLTRACE_INCREMENTAL_FLUSH_SLEEP','WAIT_XTP_CKPT_CLOSE','XE_BUFFERMGR_ALLPROCESSED_EVENT','XE_FILE_TARGET_TVF','PREEMPTIVE_OS_GETPROCADDRESS','PREEMPTIVE_OS_AUTHORITATEZONE','PREEMPTIVE_OS_COMOPS','PREEMPTIVE_OS_CREATEFILE','PREEMPTIVE_OS_CRYPTOPS','PREEMPTIVE_OS_GENERICOPS','PREEMPTIVE_XE_CALLBACKEXECUTE','PREEMPTIVE_XE_DISPATCHER','PREEMPTIVE_XE_ENGINEINIT','PREEMPTIVE_XE_GETTARGETSTATE','PREEMPTIVE_XE_SESSIONCOMMIT','PREEMPTIVE_XE_TARGETFINALIZE','PREEMPTIVE_XE_TARGETINIT') AND waiting_tasks_count>0)
SELECT TOP 15 ROW_NUMBER() OVER(ORDER BY wait_time_ms DESC) AS rn,wait_type COLLATE DATABASE_DEFAULT AS wt,waiting_tasks_count AS cnt,
  wait_time_ms/1000 AS ws,(wait_time_ms-signal_wait_time_ms)/1000 AS rs,signal_wait_time_ms/1000 AS ss,CAST(ROUND(pct,2) AS DECIMAL(10,2)) AS pct,
  CASE wait_type
    WHEN 'CXPACKET' THEN 'Parallel query sync' WHEN 'CXCONSUMER' THEN 'Parallel consumer' WHEN 'SOS_SCHEDULER_YIELD' THEN 'CPU yielding'
    WHEN 'THREADPOOL' THEN 'Worker thread exhaustion' WHEN 'RESOURCE_SEMAPHORE' THEN 'Memory grant queue'
    WHEN 'PAGEIOLATCH_SH' THEN 'Data page read from disk' WHEN 'PAGEIOLATCH_EX' THEN 'Data page write to disk'
    WHEN 'WRITELOG' THEN 'Transaction log flush' WHEN 'ASYNC_NETWORK_IO' THEN 'Client result consumption'
    WHEN 'LCK_M_S' THEN 'Shared lock wait' WHEN 'LCK_M_X' THEN 'Exclusive lock wait' WHEN 'LCK_M_U' THEN 'Update lock wait'
    WHEN 'LCK_M_IX' THEN 'Intent exclusive lock' WHEN 'LCK_M_SCH_M' THEN 'Schema modification lock'
    WHEN 'PAGELATCH_EX' THEN 'In-memory page contention' WHEN 'PAGELATCH_SH' THEN 'In-memory page shared'
    WHEN 'IO_COMPLETION' THEN 'Non-data I/O completion' WHEN 'LATCH_EX' THEN 'Internal latch exclusive'
    WHEN 'OLEDB' THEN 'Linked server / OLEDB call' WHEN 'BACKUPIO' THEN 'Backup I/O operation'
    ELSE '' END COLLATE DATABASE_DEFAULT AS descr,
  CASE wait_type
    WHEN 'CXPACKET' THEN 'Queries going parallel with uneven work distribution' WHEN 'CXCONSUMER' THEN 'Consumer thread waiting in parallel plan (usually benign)'
    WHEN 'SOS_SCHEDULER_YIELD' THEN 'Queries exhausting CPU quantum - CPU overloaded' WHEN 'THREADPOOL' THEN 'All worker threads busy - new requests cannot execute'
    WHEN 'RESOURCE_SEMAPHORE' THEN 'Not enough memory for query memory grants - queries queued'
    WHEN 'PAGEIOLATCH_SH' THEN 'Reading data pages from disk - missing indexes or insufficient buffer pool'
    WHEN 'PAGEIOLATCH_EX' THEN 'Writing data pages - checkpoint or lazy writer pressure'
    WHEN 'WRITELOG' THEN 'Slow transaction log writes - log disk latency'
    WHEN 'ASYNC_NETWORK_IO' THEN 'Application not consuming result sets fast enough'
    WHEN 'LCK_M_S' THEN 'Blocked by exclusive lock holder' WHEN 'LCK_M_X' THEN 'Waiting for exclusive access - another session holds conflicting lock'
    WHEN 'LCK_M_U' THEN 'Update lock conflict with another session' WHEN 'LCK_M_SCH_M' THEN 'DDL blocked by open transaction on same object'
    WHEN 'PAGELATCH_EX' THEN 'TempDB allocation contention or PFS/GAM hot pages'
    WHEN 'LATCH_EX' THEN 'Internal SQL Server synchronization contention'
    ELSE '' END COLLATE DATABASE_DEFAULT AS reason,
  CASE wait_type
    WHEN 'CXPACKET' THEN 'Lower MAXDOP (4-8) or raise cost threshold for parallelism (25-50)'
    WHEN 'CXCONSUMER' THEN 'Usually benign - investigate only if very high'
    WHEN 'SOS_SCHEDULER_YIELD' THEN 'Optimize CPU-heavy queries or add CPU cores'
    WHEN 'THREADPOOL' THEN 'URGENT: Kill long queries, check max worker threads, reduce connections'
    WHEN 'RESOURCE_SEMAPHORE' THEN 'Reduce MAXDOP, increase server memory, or kill memory-heavy queries'
    WHEN 'PAGEIOLATCH_SH' THEN 'Add missing indexes, increase buffer pool (RAM), or move to faster storage'
    WHEN 'PAGEIOLATCH_EX' THEN 'Move data files to faster storage, reduce checkpoint pressure'
    WHEN 'WRITELOG' THEN 'Move log file to faster SSD, reduce transaction frequency'
    WHEN 'ASYNC_NETWORK_IO' THEN 'Fix application - close readers, reduce result set size, check network'
    WHEN 'LCK_M_S' THEN 'Optimize blocking queries, use NOLOCK where safe, kill head blocker'
    WHEN 'LCK_M_X' THEN 'Shorten transactions, optimize locking queries, check blocking tree'
    WHEN 'LCK_M_U' THEN 'Review update patterns, add proper indexes to reduce scan locks'
    WHEN 'LCK_M_SCH_M' THEN 'Close open transactions on the object, avoid DDL during peak'
    WHEN 'PAGELATCH_EX' THEN 'Add more TempDB data files (1 per CPU core up to 8), enable TF 1118'
    WHEN 'LATCH_EX' THEN 'Reduce contention patterns, optimize hot-path code'
    ELSE '' END COLLATE DATABASE_DEFAULT AS fix
INTO #W FROM WS;

-- Top CPU sessions
IF OBJECT_ID('tempdb..#TC') IS NOT NULL DROP TABLE #TC;
;WITH T AS(SELECT SUM(CAST(cpu_time AS BIGINT)) AS t FROM sys.dm_exec_sessions WHERE is_user_process=1 AND cpu_time>0)
SELECT TOP 10 ROW_NUMBER() OVER(ORDER BY s.cpu_time DESC) AS rn,s.session_id AS sid,s.login_name COLLATE DATABASE_DEFAULT AS lg,
  s.host_name COLLATE DATABASE_DEFAULT AS hn,ISNULL(DB_NAME(r.database_id),'') COLLATE DATABASE_DEFAULT AS db,
  s.cpu_time AS cm,CAST(ROUND(s.cpu_time*100.0/NULLIF(t.t,0),1) AS DECIMAL(10,1)) AS cp,s.status COLLATE DATABASE_DEFAULT AS st
INTO #TC FROM sys.dm_exec_sessions s CROSS JOIN T t LEFT JOIN sys.dm_exec_requests r ON s.session_id=r.session_id WHERE s.is_user_process=1 AND s.cpu_time>0;

-- Top 10 Users by CPU %
IF OBJECT_ID('tempdb..#UC') IS NOT NULL DROP TABLE #UC;
;WITH UC AS(SELECT s.login_name,COUNT(s.session_id) AS sess,SUM(CAST(s.cpu_time AS BIGINT)) AS tcpu,SUM(CAST(s.reads AS BIGINT)) AS tr,SUM(CAST(s.writes AS BIGINT)) AS tw,SUM(CAST(s.logical_reads AS BIGINT)) AS tlr
  FROM sys.dm_exec_sessions s WHERE s.is_user_process=1 AND s.cpu_time>0 GROUP BY s.login_name),
GT AS(SELECT SUM(tcpu) AS gt FROM UC)
SELECT TOP 10 ROW_NUMBER() OVER(ORDER BY uc.tcpu DESC) AS rn,uc.login_name COLLATE DATABASE_DEFAULT AS lg,uc.sess,uc.tcpu,
  CAST(ROUND(uc.tcpu*100.0/NULLIF(gt.gt,0),1) AS DECIMAL(10,1)) AS cp,uc.tr,uc.tw,uc.tlr
INTO #UC FROM UC uc CROSS JOIN GT gt;

-- Top Memory sessions
IF OBJECT_ID('tempdb..#TM') IS NOT NULL DROP TABLE #TM;
;WITH M AS(SELECT SUM(CAST(memory_usage AS BIGINT))*8 AS t FROM sys.dm_exec_sessions WHERE is_user_process=1 AND memory_usage>0),
S AS(SELECT s.session_id,s.login_name,s.host_name,s.database_id,CAST(s.memory_usage AS BIGINT)*8 AS mk8 FROM sys.dm_exec_sessions s WHERE s.is_user_process=1 AND s.memory_usage>0)
SELECT TOP 10 ROW_NUMBER() OVER(ORDER BY mk8 DESC) AS rn,s.session_id AS sid,s.login_name COLLATE DATABASE_DEFAULT AS lg,
  s.host_name COLLATE DATABASE_DEFAULT AS hn,ISNULL(DB_NAME(s.database_id),'') COLLATE DATABASE_DEFAULT AS db,
  mk8 AS mk,CAST(ROUND(mk8*100.0/NULLIF(m.t,0),1) AS DECIMAL(10,1)) AS mp
INTO #TM FROM S s CROSS JOIN M m;

-- Top 10 Users by Memory %
IF OBJECT_ID('tempdb..#UM') IS NOT NULL DROP TABLE #UM;
;WITH UM AS(SELECT s.login_name,COUNT(s.session_id) AS sess,SUM(CAST(s.memory_usage AS BIGINT))*8 AS tmem,
  ISNULL(SUM(mg.granted_memory_kb),0)/1024 AS gmb,ISNULL(SUM(mg.used_memory_kb),0)/1024 AS umb
  FROM sys.dm_exec_sessions s LEFT JOIN sys.dm_exec_query_memory_grants mg ON s.session_id=mg.session_id
  WHERE s.is_user_process=1 AND s.memory_usage>0 GROUP BY s.login_name),
GT AS(SELECT SUM(tmem) AS gt FROM UM)
SELECT TOP 10 ROW_NUMBER() OVER(ORDER BY um.tmem DESC) AS rn,um.login_name COLLATE DATABASE_DEFAULT AS lg,um.sess,um.tmem,
  CAST(ROUND(um.tmem*100.0/NULLIF(gt.gt,0),1) AS DECIMAL(10,1)) AS mp,um.gmb,um.umb
INTO #UM FROM UM um CROSS JOIN GT gt;

-- Memory Pressure Indicators
IF OBJECT_ID('tempdb..#MP') IS NOT NULL DROP TABLE #MP;
SELECT RTRIM(counter_name) COLLATE DATABASE_DEFAULT AS cn,cntr_value AS cv,
  ROW_NUMBER() OVER(PARTITION BY RTRIM(counter_name) ORDER BY object_name) AS rn
INTO #MP FROM sys.dm_os_performance_counters
WHERE(object_name LIKE '%Buffer Manager%' AND RTRIM(counter_name) IN('Page life expectancy','Lazy writes/sec','Free list stalls/sec','Buffer cache hit ratio','Buffer cache hit ratio base'))
  OR(object_name LIKE '%Memory Manager%' AND RTRIM(counter_name) IN('Memory Grants Pending','Memory Grants Outstanding','Total Server Memory (KB)','Target Server Memory (KB)'));

-- CPU Pressure Indicators
IF OBJECT_ID('tempdb..#CP') IS NOT NULL DROP TABLE #CP;
SELECT RTRIM(counter_name) COLLATE DATABASE_DEFAULT AS cn,cntr_value AS cv,
  ROW_NUMBER() OVER(PARTITION BY RTRIM(counter_name) ORDER BY object_name) AS rn
INTO #CP FROM sys.dm_os_performance_counters
WHERE object_name LIKE '%SQL Statistics%' AND RTRIM(counter_name) IN('SQL Compilations/sec','SQL Re-Compilations/sec','Batch Requests/sec','Forced Parameterizations/sec');

-- I/O Latency
IF OBJECT_ID('tempdb..#IO') IS NOT NULL DROP TABLE #IO;
SELECT TOP 10 ROW_NUMBER() OVER(ORDER BY CASE WHEN(vfs.num_of_reads+vfs.num_of_writes)>0 THEN vfs.io_stall/(vfs.num_of_reads+vfs.num_of_writes) ELSE 0 END DESC) AS rn,
  DB_NAME(vfs.database_id) COLLATE DATABASE_DEFAULT AS db,mf.name COLLATE DATABASE_DEFAULT AS fn,
  CASE mf.type WHEN 0 THEN 'DATA' WHEN 1 THEN 'LOG' END COLLATE DATABASE_DEFAULT AS ft,
  CASE WHEN vfs.num_of_reads>0 THEN vfs.io_stall_read_ms/vfs.num_of_reads ELSE 0 END AS rm,
  CASE WHEN vfs.num_of_writes>0 THEN vfs.io_stall_write_ms/vfs.num_of_writes ELSE 0 END AS wm,
  CASE WHEN(vfs.num_of_reads+vfs.num_of_writes)>0 THEN vfs.io_stall/(vfs.num_of_reads+vfs.num_of_writes) ELSE 0 END AS tm
INTO #IO FROM sys.dm_io_virtual_file_stats(NULL,NULL) vfs JOIN sys.master_files mf ON vfs.database_id=mf.database_id AND vfs.file_id=mf.file_id WHERE(vfs.num_of_reads+vfs.num_of_writes)>100;

-- Database sizes
IF OBJECT_ID('tempdb..#DB') IS NOT NULL DROP TABLE #DB;
SELECT ROW_NUMBER() OVER(ORDER BY SUM(CAST(mf.size AS BIGINT)) DESC) AS rn,d.name COLLATE DATABASE_DEFAULT AS nm,d.recovery_model_desc COLLATE DATABASE_DEFAULT AS rc,
  SUM(CASE WHEN mf.type=0 THEN CAST(mf.size AS BIGINT) ELSE 0 END)*8/1024 AS dm,SUM(CASE WHEN mf.type=1 THEN CAST(mf.size AS BIGINT) ELSE 0 END)*8/1024 AS lm,
  CAST(ROUND(SUM(CAST(mf.size AS BIGINT))*8.0/1024/1024,2) AS DECIMAL(18,2)) AS tg
INTO #DB FROM sys.databases d JOIN sys.master_files mf ON d.database_id=mf.database_id WHERE d.state=0 GROUP BY d.name,d.recovery_model_desc;

-- Drives
IF OBJECT_ID('tempdb..#D2') IS NOT NULL DROP TABLE #D2;
SELECT ROW_NUMBER() OVER(ORDER BY fm) AS rn,dr,fm,fm/1024 AS fg INTO #D2 FROM #drv;

-- Config
IF OBJECT_ID('tempdb..#CF') IS NOT NULL DROP TABLE #CF;
SELECT name COLLATE DATABASE_DEFAULT AS nm,CAST(value_in_use AS VARCHAR(50)) COLLATE DATABASE_DEFAULT AS vl
INTO #CF FROM sys.configurations WHERE name IN('max degree of parallelism','cost threshold for parallelism','optimize for ad hoc workloads','max server memory (MB)','min server memory (MB)','backup compression default');

-- TPS snapshot
IF OBJECT_ID('tempdb..#T1') IS NOT NULL DROP TABLE #T1;
IF OBJECT_ID('tempdb..#T2') IS NOT NULL DROP TABLE #T2;
SELECT RTRIM(instance_name) COLLATE DATABASE_DEFAULT AS dn,cntr_value AS tc INTO #T1 FROM sys.dm_os_performance_counters WHERE RTRIM(counter_name)='Transactions/sec' AND object_name LIKE '%Databases%';
DECLARE @bb1 BIGINT;SELECT @bb1=cntr_value FROM sys.dm_os_performance_counters WHERE RTRIM(counter_name)='Batch Requests/sec' AND object_name LIKE '%SQL Statistics%';
WAITFOR DELAY '00:00:01';
SELECT RTRIM(instance_name) COLLATE DATABASE_DEFAULT AS dn,cntr_value AS tc INTO #T2 FROM sys.dm_os_performance_counters WHERE RTRIM(counter_name)='Transactions/sec' AND object_name LIKE '%Databases%';
DECLARE @bb2 BIGINT;SELECT @bb2=cntr_value FROM sys.dm_os_performance_counters WHERE RTRIM(counter_name)='Batch Requests/sec' AND object_name LIKE '%SQL Statistics%';

-- TPS per DB
IF OBJECT_ID('tempdb..#TPD') IS NOT NULL DROP TABLE #TPD;
SELECT ROW_NUMBER() OVER(ORDER BY(t2.tc-t1.tc) DESC) AS rn,t2.dn,t2.tc-t1.tc AS tps
INTO #TPD FROM #T2 t2 JOIN #T1 t1 ON t2.dn=t1.dn WHERE t2.dn NOT IN('_Total','mssqlsystemresource') AND(t2.tc-t1.tc)>0;

DECLARE @curtps BIGINT;SELECT @curtps=t2.tc-t1.tc FROM #T2 t2 JOIN #T1 t1 ON t2.dn=t1.dn WHERE t2.dn='_Total';
SET @curtps=ISNULL(@curtps,0);
DECLARE @curbps BIGINT;SET @curbps=ISNULL(@bb2-@bb1,0);

-- Average TPS
DECLARE @avgtps DECIMAL(18,2),@avgbps DECIMAL(18,2),@upd2 INT;
SELECT @upd2=DATEDIFF(DAY,sqlserver_start_time,GETDATE()) FROM sys.dm_os_sys_info;
SELECT @avgtps=CAST(ROUND(t.tc*1.0/NULLIF(DATEDIFF(SECOND,si.sqlserver_start_time,GETDATE()),0),2) AS DECIMAL(18,2)),
  @avgbps=CAST(ROUND(b.bc*1.0/NULLIF(DATEDIFF(SECOND,si.sqlserver_start_time,GETDATE()),0),2) AS DECIMAL(18,2))
FROM sys.dm_os_sys_info si
CROSS JOIN(SELECT cntr_value AS tc FROM(SELECT cntr_value,ROW_NUMBER() OVER(ORDER BY object_name) AS rn FROM sys.dm_os_performance_counters WHERE RTRIM(counter_name)='Transactions/sec' AND RTRIM(instance_name)='_Total' AND object_name LIKE '%Databases%')x WHERE rn=1) t
CROSS JOIN(SELECT cntr_value AS bc FROM(SELECT cntr_value,ROW_NUMBER() OVER(ORDER BY object_name) AS rn FROM sys.dm_os_performance_counters WHERE RTRIM(counter_name)='Batch Requests/sec' AND object_name LIKE '%SQL Statistics%')x WHERE rn=1) b;
SET @avgtps=ISNULL(@avgtps,0);SET @avgbps=ISNULL(@avgbps,0);

DROP TABLE #T1;DROP TABLE #T2;

-- Suspect pages
IF OBJECT_ID('tempdb..#SP') IS NOT NULL DROP TABLE #SP;
SELECT DB_NAME(database_id) COLLATE DATABASE_DEFAULT AS db,file_id AS fid,page_id AS pid,
  CASE event_type WHEN 1 THEN '823 error' WHEN 2 THEN 'Bad checksum' WHEN 3 THEN 'Torn page' WHEN 4 THEN 'Restored' WHEN 5 THEN 'Repaired' ELSE 'Other' END COLLATE DATABASE_DEFAULT AS ev,
  error_count AS ec,last_update_date AS lu
INTO #SP FROM msdb.dbo.suspect_pages;

-- Error log (top 20)
IF OBJECT_ID('tempdb..#EL') IS NOT NULL DROP TABLE #EL;
CREATE TABLE #EL(rn INT IDENTITY,ld DATETIME,pi VARCHAR(100) COLLATE DATABASE_DEFAULT,lt VARCHAR(500) COLLATE DATABASE_DEFAULT);
BEGIN TRY
  DECLARE @eltmp TABLE(ld2 DATETIME,pi2 VARCHAR(100),lt2 NVARCHAR(MAX));
  DECLARE @els3 DATETIME;SET @els3=DATEADD(DAY,-1,GETDATE());
  INSERT INTO @eltmp EXEC sp_readerrorlog 0,1,N'Error',NULL,@els3;
  INSERT INTO #EL(ld,pi,lt) SELECT TOP 20 ld2,pi2,LEFT(CAST(lt2 AS VARCHAR(500)),500) FROM @eltmp ORDER BY ld2 DESC;
END TRY BEGIN CATCH
  INSERT INTO #EL(ld,pi,lt) VALUES(GETDATE(),'INFO','Error log unavailable');
END CATCH

-- Trace flags
IF OBJECT_ID('tempdb..#TF') IS NOT NULL DROP TABLE #TF;
CREATE TABLE #TF(tf INT,st1 INT,gl INT,se INT);
BEGIN TRY INSERT INTO #TF EXEC('DBCC TRACESTATUS(-1) WITH NO_INFOMSGS');END TRY BEGIN CATCH END CATCH

-- ============================================================
-- NEW METRICS COLLECTION
-- ============================================================

-- Missing Indexes
IF OBJECT_ID('tempdb..#MI') IS NOT NULL DROP TABLE #MI;
CREATE TABLE #MI(rn INT,db VARCHAR(200) COLLATE DATABASE_DEFAULT,tbl VARCHAR(300) COLLATE DATABASE_DEFAULT,
  eq_cols VARCHAR(2000) COLLATE DATABASE_DEFAULT,ineq_cols VARCHAR(2000) COLLATE DATABASE_DEFAULT,
  inc_cols VARCHAR(2000) COLLATE DATABASE_DEFAULT,seeks BIGINT,scans BIGINT,impact DECIMAL(10,1),score BIGINT);
BEGIN TRY
INSERT INTO #MI SELECT TOP 20
  ROW_NUMBER() OVER(ORDER BY CAST(gs.avg_total_user_cost*gs.avg_user_impact*(gs.user_seeks+gs.user_scans) AS BIGINT) DESC),
  DB_NAME(mid.database_id),OBJECT_NAME(mid.object_id,mid.database_id),
  ISNULL(LEFT(mid.equality_columns,500),''),ISNULL(LEFT(mid.inequality_columns,500),''),
  ISNULL(LEFT(mid.included_columns,500),''),
  gs.user_seeks,gs.user_scans,CAST(gs.avg_user_impact AS DECIMAL(10,1)),
  CAST(gs.avg_total_user_cost*gs.avg_user_impact*(gs.user_seeks+gs.user_scans) AS BIGINT)
FROM sys.dm_db_missing_index_details mid
JOIN sys.dm_db_missing_index_groups mig ON mid.index_handle=mig.index_handle
JOIN sys.dm_db_missing_index_group_stats gs ON mig.index_group_handle=gs.group_handle
WHERE mid.database_id>4;
END TRY BEGIN CATCH END CATCH

-- Memory Clerks
IF OBJECT_ID('tempdb..#MC') IS NOT NULL DROP TABLE #MC;
CREATE TABLE #MC(rn INT,tp VARCHAR(256) COLLATE DATABASE_DEFAULT,mb BIGINT);
BEGIN TRY
INSERT INTO #MC
SELECT TOP 15 ROW_NUMBER() OVER(ORDER BY SUM(pages_kb) DESC),
  type,SUM(pages_kb)/1024
FROM sys.dm_os_memory_clerks WHERE pages_kb>0 GROUP BY type;
END TRY BEGIN CATCH END CATCH

-- AG Health
IF OBJECT_ID('tempdb..#AG') IS NOT NULL DROP TABLE #AG;
CREATE TABLE #AG(rn INT IDENTITY,ag_name VARCHAR(200) COLLATE DATABASE_DEFAULT,role_desc VARCHAR(60) COLLATE DATABASE_DEFAULT,
  sync_health VARCHAR(60) COLLATE DATABASE_DEFAULT,db_name VARCHAR(200) COLLATE DATABASE_DEFAULT,
  db_sync VARCHAR(60) COLLATE DATABASE_DEFAULT,redo_q BIGINT,send_q BIGINT);
BEGIN TRY
INSERT INTO #AG(ag_name,role_desc,sync_health,db_name,db_sync,redo_q,send_q)
SELECT ag.name,ars.role_desc,ars.synchronization_health_desc,DB_NAME(drs.database_id),
  drs.synchronization_state_desc,ISNULL(drs.redo_queue_size,0),ISNULL(drs.log_send_queue_size,0)
FROM sys.dm_hadr_availability_replica_states ars
JOIN sys.availability_replicas ar ON ars.replica_id=ar.replica_id
JOIN sys.availability_groups ag ON ar.group_id=ag.group_id
JOIN sys.dm_hadr_database_replica_states drs ON ars.replica_id=drs.replica_id AND ar.group_id=drs.group_id;
END TRY BEGIN CATCH END CATCH

-- Unused Indexes (write penalty, zero reads since restart)
IF OBJECT_ID('tempdb..#UI') IS NOT NULL DROP TABLE #UI;
CREATE TABLE #UI(rn INT,db VARCHAR(200) COLLATE DATABASE_DEFAULT,tbl VARCHAR(300) COLLATE DATABASE_DEFAULT,
  user_seeks BIGINT,user_scans BIGINT,user_lookups BIGINT,user_updates BIGINT,index_id INT);
BEGIN TRY
INSERT INTO #UI SELECT TOP 20
  ROW_NUMBER() OVER(ORDER BY i.user_updates DESC),
  DB_NAME(i.database_id),OBJECT_NAME(i.object_id,i.database_id),
  i.user_seeks,i.user_scans,i.user_lookups,i.user_updates,i.index_id
FROM sys.dm_db_index_usage_stats i
WHERE i.database_id>4 AND i.index_id>1 AND i.user_updates>100
  AND (i.user_seeks+i.user_scans+i.user_lookups)=0;
END TRY BEGIN CATCH END CATCH

-- Lock Escalations by table
IF OBJECT_ID('tempdb..#LE') IS NOT NULL DROP TABLE #LE;
CREATE TABLE #LE(rn INT,db VARCHAR(200) COLLATE DATABASE_DEFAULT,tbl VARCHAR(300) COLLATE DATABASE_DEFAULT,
  escalations BIGINT,row_locks BIGINT,page_locks BIGINT);
BEGIN TRY
INSERT INTO #LE SELECT TOP 15
  ROW_NUMBER() OVER(ORDER BY SUM(ios.index_lock_promotion_count) DESC),
  DB_NAME(ios.database_id),OBJECT_NAME(ios.object_id,ios.database_id),
  SUM(ios.index_lock_promotion_count),SUM(ios.row_lock_count),SUM(ios.page_lock_count)
FROM sys.dm_db_index_operational_stats(NULL,NULL,NULL,NULL) ios
WHERE ios.database_id>4 AND ios.index_lock_promotion_count>0
GROUP BY ios.database_id,ios.object_id;
END TRY BEGIN CATCH END CATCH

-- Backup Status (last 30 days)
IF OBJECT_ID('tempdb..#BK') IS NOT NULL DROP TABLE #BK;
CREATE TABLE #BK(rn INT,db VARCHAR(200) COLLATE DATABASE_DEFAULT,rm VARCHAR(60) COLLATE DATABASE_DEFAULT,
  last_full DATETIME,last_diff DATETIME,last_log DATETIME,full_age_h INT);
BEGIN TRY
INSERT INTO #BK SELECT ROW_NUMBER() OVER(ORDER BY d.name),d.name,d.recovery_model_desc,
  MAX(CASE WHEN b.type='D' THEN b.backup_finish_date END),
  MAX(CASE WHEN b.type='I' THEN b.backup_finish_date END),
  MAX(CASE WHEN b.type='L' THEN b.backup_finish_date END),
  DATEDIFF(HOUR,MAX(CASE WHEN b.type='D' THEN b.backup_finish_date END),GETDATE())
FROM sys.databases d
LEFT JOIN msdb.dbo.backupset b ON b.database_name=d.name AND b.backup_finish_date>=DATEADD(DAY,-30,GETDATE())
WHERE d.database_id>4 AND d.state=0
GROUP BY d.name,d.recovery_model_desc;
END TRY BEGIN CATCH END CATCH

-- Top Queries by CPU (TOP 20 guard applied BEFORE CROSS APPLY to keep it fast)
IF OBJECT_ID('tempdb..#TQ') IS NOT NULL DROP TABLE #TQ;
CREATE TABLE #TQ(rn INT,cpu_ms BIGINT,execs BIGINT,avg_cpu_ms BIGINT,log_reads BIGINT,avg_reads BIGINT,avg_dur_ms BIGINT,sql_text NVARCHAR(2000) COLLATE DATABASE_DEFAULT);
BEGIN TRY
;WITH TopSQL AS(SELECT TOP 20 qs.total_worker_time,qs.execution_count,qs.total_logical_reads,
  qs.total_elapsed_time,qs.sql_handle,qs.statement_start_offset,qs.statement_end_offset
  FROM sys.dm_exec_query_stats qs ORDER BY qs.total_worker_time DESC)
INSERT INTO #TQ SELECT
  ROW_NUMBER() OVER(ORDER BY t.total_worker_time DESC),
  t.total_worker_time/1000,t.execution_count,
  t.total_worker_time/1000/NULLIF(t.execution_count,0),
  t.total_logical_reads,t.total_logical_reads/NULLIF(t.execution_count,0),
  t.total_elapsed_time/1000/NULLIF(t.execution_count,0),
  REPLACE(REPLACE(REPLACE(REPLACE(LEFT(ISNULL(SUBSTRING(qt.text,t.statement_start_offset/2+1,
    CASE WHEN t.statement_end_offset=-1 THEN LEN(qt.text)
         ELSE(t.statement_end_offset-t.statement_start_offset)/2+1 END),''),1500),
    CHAR(13),N' '),CHAR(10),N' '),N'<',N'&lt;'),N'>',N'&gt;')
FROM TopSQL t CROSS APPLY sys.dm_exec_sql_text(t.sql_handle) qt;
END TRY BEGIN CATCH END CATCH

-- Plan Cache Health (aggregates only - fast)
IF OBJECT_ID('tempdb..#PC') IS NOT NULL DROP TABLE #PC;
CREATE TABLE #PC(total_plans INT,single_use INT,single_use_pct DECIMAL(10,1),total_mb INT,waste_mb INT);
BEGIN TRY
INSERT INTO #PC
SELECT COUNT(*),
  SUM(CASE WHEN usecounts=1 THEN 1 ELSE 0 END),
  CAST(SUM(CASE WHEN usecounts=1 THEN 1 ELSE 0 END)*100.0/NULLIF(COUNT(*),0) AS DECIMAL(10,1)),
  SUM(size_in_bytes)/1024/1024,
  SUM(CASE WHEN usecounts=1 THEN size_in_bytes ELSE 0 END)/1024/1024
FROM sys.dm_exec_cached_plans WHERE objtype IN('Adhoc','Prepared');
END TRY BEGIN CATCH
  INSERT INTO #PC VALUES(0,0,CAST(0 AS DECIMAL(10,1)),0,0);
END CATCH

-- Add late summary checks
DECLARE @rjcnt INT;SELECT @rjcnt=ISNULL(COUNT(*),0) FROM #RJ;
INSERT INTO #R VALUES('Agent','** Running Jobs',CASE WHEN @rjcnt>10 THEN 'WARNING' ELSE 'HEALTHY' END,CAST(@rjcnt AS VARCHAR)+' jobs running now',CASE WHEN @rjcnt>10 THEN 'Over 10 jobs running concurrently. Check for overlapping schedules or stuck jobs.' ELSE 'Active SQL Agent jobs. Check Running Jobs section for names and durations.' END);
INSERT INTO #R VALUES('** TPS','** Current TPS','INFO',CAST(ISNULL(@curtps,0) AS VARCHAR)+' TPS | '+CAST(ISNULL(@curbps,0) AS VARCHAR)+' Batch/sec | Avg: '+CAST(ISNULL(@avgtps,0) AS VARCHAR)+' TPS','1-sec sample vs avg since restart. Large gap = spike or lull. See TPS section for per-DB.');

-- Backup summary
DECLARE @bk_warn INT,@bk_never INT;SET @bk_warn=0;SET @bk_never=0;
SELECT @bk_warn=ISNULL(SUM(CASE WHEN full_age_h>48 OR last_full IS NULL THEN 1 ELSE 0 END),0),
  @bk_never=ISNULL(SUM(CASE WHEN last_full IS NULL THEN 1 ELSE 0 END),0) FROM #BK;
INSERT INTO #R VALUES('Backup','Full Backup Status',CASE WHEN @bk_never>0 THEN 'CRITICAL' WHEN @bk_warn>0 THEN 'WARNING' ELSE 'HEALTHY' END,
  CAST(@bk_warn AS VARCHAR)+' DB(s) over 48h',CASE WHEN @bk_never>0 THEN CAST(@bk_never AS VARCHAR)+' DB(s) have NEVER been backed up. Immediate action required.' WHEN @bk_warn>0 THEN CAST(@bk_warn AS VARCHAR)+' DB(s) with no full backup in 48h. Check Backup Status section.' ELSE 'All databases have recent full backups.' END);

-- Plan Cache summary
DECLARE @pc_pct DECIMAL(10,1);SET @pc_pct=0;
SELECT @pc_pct=ISNULL(single_use_pct,0) FROM #PC;
INSERT INTO #R VALUES('Plan Cache','Single-Use Plans',CASE WHEN @pc_pct>40 THEN 'WARNING' ELSE 'HEALTHY' END,
  CAST(@pc_pct AS VARCHAR)+'% single-use',CASE WHEN @pc_pct>40 THEN 'Over 40% single-use plans. Enable "optimize for ad hoc workloads" to reduce plan cache bloat.' ELSE 'Plan cache reuse is healthy. Single-use plan ratio is acceptable.' END);

-- Missing Indexes summary
DECLARE @mi_cnt INT,@mi_top DECIMAL(10,1);SET @mi_cnt=0;SET @mi_top=0;
SELECT @mi_cnt=ISNULL(COUNT(*),0),@mi_top=ISNULL(MAX(impact),0) FROM #MI;
INSERT INTO #R VALUES('Indexes','Missing Indexes',CASE WHEN @mi_cnt>15 THEN 'WARNING' WHEN @mi_cnt>0 THEN 'INFO' ELSE 'HEALTHY' END,
  CAST(@mi_cnt AS VARCHAR)+' recommendations (top impact: '+CAST(@mi_top AS VARCHAR)+'%)',
  CASE WHEN @mi_cnt>0 THEN CAST(@mi_cnt AS VARCHAR)+' missing index recommendations. Top estimated impact: '+CAST(@mi_top AS VARCHAR)+'%. Review Missing Indexes section.' ELSE 'No missing index recommendations from the optimizer.' END);

-- AG Health summary
DECLARE @ag_total INT,@ag_bad INT;SET @ag_total=0;SET @ag_bad=0;
SELECT @ag_total=ISNULL(COUNT(DISTINCT ag_name),0),
  @ag_bad=ISNULL(SUM(CASE WHEN sync_health NOT LIKE '%HEALTHY%' THEN 1 ELSE 0 END),0) FROM #AG;
IF @ag_total>0
  INSERT INTO #R VALUES('Availability','AG Health',CASE WHEN @ag_bad>0 THEN 'CRITICAL' ELSE 'HEALTHY' END,
    CAST(@ag_total AS VARCHAR)+' AG(s) | '+CAST(@ag_bad AS VARCHAR)+' unhealthy',
    CASE WHEN @ag_bad>0 THEN CAST(@ag_bad AS VARCHAR)+' replica(s) not synchronized. Check AG Health section for redo/send queue.' ELSE 'All AG replicas synchronized and healthy.' END);

-- ============================================================
-- BUILD HTML
-- ============================================================
DECLARE @h NVARCHAR(MAX);SET @h=N'';
DECLARE @c1 INT,@w1 INT,@o1 INT;
SELECT @c1=ISNULL(SUM(CASE WHEN st='CRITICAL' THEN 1 ELSE 0 END),0),@w1=ISNULL(SUM(CASE WHEN st='WARNING' THEN 1 ELSE 0 END),0),
  @o1=ISNULL(SUM(CASE WHEN st='HEALTHY' THEN 1 ELSE 0 END),0) FROM #R WHERE st!='INFO';
DECLARE @vd VARCHAR(50),@vc VARCHAR(20);
SET @vd=CASE WHEN @c1>0 THEN 'IMMEDIATE ACTION REQUIRED' WHEN @w1>0 THEN 'REVIEW WARNINGS' ELSE 'ALL CHECKS PASSED' END;
SET @vc=CASE WHEN @c1>0 THEN '#cc0000' WHEN @w1>0 THEN '#cc6600' ELSE '#006600' END;

SET @h=N'<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>sqlhc - '+ISNULL(@srv,N'')+N'</title><style>'
+N'*{margin:0;padding:0;box-sizing:border-box}body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;background:#f3f2ef;color:#191919;line-height:1.5;font-size:13px}'
+N'.c{max-width:1400px;margin:0 auto;padding:20px}'
+N'.bnr{background:#fff;border:1px solid rgba(0,0,0,.08);border-radius:10px 10px 0 0;padding:16px 20px}'
+N'.bnr h1{font-size:20px;font-weight:700;color:#191919;display:flex;align-items:center;gap:10px}'
+N'.bnr h1::before{content:"BCBSAZ";background:#0a66c2;color:#fff;font-size:10px;font-weight:800;width:auto;padding:0 7px;height:30px;border-radius:5px;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;letter-spacing:.5px}'
+N'.bnr h3{font-size:12px;color:#666;margin-top:4px;font-weight:400;padding-left:40px}'
+N'.sb{background:#fff;border:1px solid rgba(0,0,0,.08);border-top:1px solid rgba(0,0,0,.06);padding:10px 20px;margin-bottom:16px;font-size:12px;color:#555;border-radius:0 0 10px 10px}'
+N'.vd{font-size:15px;font-weight:700;padding:12px 20px;text-align:center;margin:0 0 14px;color:#fff;border-radius:8px}'
+N'.cards{display:flex;gap:12px;margin:0 0 14px}'
+N'.card{flex:1;padding:18px 16px;text-align:center;background:#fff;border:1px solid rgba(0,0,0,.08);border-radius:10px}'
+N'.card .n{font-size:32px;font-weight:700;line-height:1}.card .l{font-size:11px;color:#666;text-transform:uppercase;letter-spacing:.5px;margin-top:6px}'
+N'.cr{color:#cc0000}.wr{color:#cc6600}.gd{color:#057642}'
+N'h2{font-size:14px;font-weight:700;color:#191919;margin:16px 0 0;padding:12px 20px;background:#fff;border:1px solid rgba(0,0,0,.08);border-radius:10px 10px 0 0;border-left:4px solid #0a66c2;display:flex;justify-content:space-between;align-items:center}'
+N'.n2{color:#555;font-size:11px;font-style:italic;padding:8px 16px;background:#fff;border-left:1px solid rgba(0,0,0,.08);border-right:1px solid rgba(0,0,0,.08);border-bottom:1px solid rgba(0,0,0,.06)}'
+N'table{width:100%;border-collapse:collapse;margin:0 0 4px;font-size:12px;background:#fff;border:1px solid rgba(0,0,0,.08);border-top:0}'
+N'th{background:#004182;color:#fff;padding:8px 10px;text-align:left;font-size:11px;white-space:nowrap;font-weight:600}'
+N'td{padding:7px 10px;border-bottom:1px solid rgba(0,0,0,.06);vertical-align:top}tr:nth-child(even){background:#f8f7f5}tr:hover td{background:#e8f2ff}'
+N'.b{padding:2px 8px;font-size:10px;font-weight:700;border-radius:12px;display:inline-block}'
+N'.bc{background:#cc0000;color:#fff}.bw{background:#e67700;color:#fff}.bg{background:#057642;color:#fff}.bi{background:#0a66c2;color:#fff}'
+N'.toc{background:#fff;border:1px solid rgba(0,0,0,.08);border-radius:10px;padding:14px 18px;margin:0 0 14px}'
+N'.toc a{color:#0a66c2;text-decoration:none;margin:2px 5px;font-size:12px;display:inline-block;font-weight:500}.toc a:hover{text-decoration:underline}'
+N'.how{background:#ebf5ff;border:1px solid #b3d4f5;border-radius:8px;padding:10px 16px;margin:0 0 14px;font-size:12px;color:#191919}'
+N'.btt{font-size:11px;font-weight:normal}.btt a{color:#0a66c2}'
+N'.snp{background:#fff;border:1px solid rgba(0,0,0,.08) !important;border-radius:10px;padding:12px 16px;margin:0 0 14px;width:auto;border-top:1px solid rgba(0,0,0,.08) !important}'
+N'.snp td,.snp th{border:0;padding:4px 14px 4px 0;background:transparent;font-size:12px;font-weight:600;color:#191919}'
+N'.snp td{font-weight:400;color:#555}'
+N'.ft{margin-top:20px;padding:14px 20px;background:#fff;border:1px solid rgba(0,0,0,.08);border-radius:10px;color:#666;font-size:11px;text-align:center}'
+N'</style></head><body><div class="c">';

SET @h=@h+N'<div class="bnr"><h1>WORKLOAD REPOSITORY REPORT</h1><h3>SQL Server Instance Health Check</h3></div>'
+N'<div class="sb"><b>'+ISNULL(@srv,N'')+N'</b> &bull; v'+ISNULL(@ver,N'')+N' &bull; '+ISNULL(@ed,N'')
+N' &bull; Up '+CAST(ISNULL(@up,0) AS NVARCHAR)+N'd &bull; '+CAST(ISNULL(@cpu,0) AS NVARCHAR)+N' CPUs &bull; '+CAST(ISNULL(@ram,0) AS NVARCHAR)+N'GB &bull; Snap: '+CONVERT(NVARCHAR,GETDATE(),120)+N'</div>'
+N'<div class="vd" style="background:'+@vc+N'">'+@vd+N'</div>'
+N'<div class="cards"><div class="card"><div class="n cr">'+CAST(@c1 AS NVARCHAR)+N'</div><div class="l">Critical</div></div>'
+N'<div class="card"><div class="n wr">'+CAST(@w1 AS NVARCHAR)+N'</div><div class="l">Warning</div></div>'
+N'<div class="card"><div class="n gd">'+CAST(@o1 AS NVARCHAR)+N'</div><div class="l">Healthy</div></div></div>';

SET @h=@h+N'<table class="snp"><tr><th>Snap:</th><td>'+CONVERT(NVARCHAR,GETDATE(),120)+N'</td><th>Start:</th><td>'+ISNULL(CONVERT(NVARCHAR,@sdt,120),N'')+N'</td><th>Sessions:</th><td>'+CAST(ISNULL(@ts,0) AS NVARCHAR)+N' ('+CAST(ISNULL(@rs,0) AS NVARCHAR)+N' active)</td><th>DB Total:</th><td>'+CAST(ISNULL(@dbgb,0) AS NVARCHAR)+N'GB</td></tr></table>';

SET @h=@h+N'<div class="how"><span class="b bc">CRITICAL</span> P1 now <span class="b bw">WARNING</span> Attention needed <span class="b bg">HEALTHY</span> OK <span class="b bi">INFO</span> FYI. <b>** = Current real-time snapshot.</b></div>';

SET @h=@h+N'<div class="toc"><b>Contents</b><br>'
+N'<b>Current/Real-time:</b> <a href="#ex">Summary</a> <a href="#s2">**Blocking</a> <a href="#s1">**Sessions</a> <a href="#s1b">**SQL Text</a> <a href="#s3">**Waits</a> <a href="#s4">**Memory Grants</a> <a href="#s5">**TempDB</a> <a href="#s5b">**TempDB Consumers</a> <a href="#s6">**Connections</a> <a href="#s7">**Open Txn</a> <a href="#s8">**Running Jobs</a> <a href="#s9">**NUMA</a> <a href="#tps">**TPS</a><br>'
+N'<b>Historical/Config:</b> <a href="#s10">Top Waits</a> <a href="#s11">Top CPU</a> <a href="#s11b">Users by CPU%</a> <a href="#s12">Top Memory</a> <a href="#s12b">Users by Mem%</a> <a href="#mpi">Mem Pressure</a> <a href="#cpi">CPU Pressure</a> <a href="#s13">I/O Latency</a> <a href="#s14">DB Sizes</a> <a href="#s15">Drives</a> <a href="#s16">Failed Jobs</a> <a href="#s17">Config</a> <a href="#sps">Suspect Pages</a> <a href="#erl">Error Log</a> <a href="#trf">Trace Flags</a><br>'
+N'<b>New Insights:</b> <a href="#tq">Top Queries</a> <a href="#mi">Missing Indexes</a> <a href="#bk">Backup Status</a> <a href="#pc">Plan Cache</a> <a href="#mc">Memory Clerks</a> <a href="#ag">AG Health</a> <a href="#ui">Unused Indexes</a> <a href="#le">Lock Escalations</a></div>';

-- ============================================================
-- HTML TABLES (cursor-based, collation-safe)
-- ============================================================
DECLARE @rw NVARCHAR(MAX);

-- ===================== EXECUTIVE SUMMARY =====================
SET @h=@h+N'<h2 id="ex">Executive Summary <span class="btt"><a href="#">Top</a></span></h2><div class="n2"><b>How to read:</b> All health checks sorted by severity. CRITICAL = act now, WARNING = investigate, HEALTHY = OK, INFO = baseline reference. The Action column explains what each check means and what to do regardless of status. Start with CRITICALs, then WARNINGs.</div><table><tr><th>Section</th><th>Check</th><th>Status</th><th>Details</th><th>Action / How to Read</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+ISNULL(sec COLLATE DATABASE_DEFAULT,N'')+N'</td><td>'+ISNULL(chk COLLATE DATABASE_DEFAULT,N'')+N'</td><td>'+CASE ISNULL(st COLLATE DATABASE_DEFAULT,'') WHEN 'CRITICAL' THEN N'<span class="b bc">CRITICAL</span>' WHEN 'WARNING' THEN N'<span class="b bw">WARNING</span>' WHEN 'HEALTHY' THEN N'<span class="b bg">HEALTHY</span>' ELSE N'<span class="b bi">INFO</span>' END+N'</td><td>'+ISNULL(det COLLATE DATABASE_DEFAULT,N'')+N'</td><td>'+ISNULL(act COLLATE DATABASE_DEFAULT,N'')+N'</td></tr>' FROM #R ORDER BY CASE ISNULL(st COLLATE DATABASE_DEFAULT,'') WHEN 'CRITICAL' THEN 1 WHEN 'WARNING' THEN 2 WHEN 'INFO' THEN 3 ELSE 4 END,id;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- ===================== CURRENT SECTIONS =====================

-- ** BLOCKING TREE (first - most critical to see immediately)
SET @h=@h+N'<h2 id="s2">** Blocking Tree <span class="btt"><a href="#">Top</a></span></h2><div class="n2"><b>How to read:</b> Level 0 = head blocker (the root cause session). Higher levels are victims waiting on the level above them. Chain column shows the full dependency path (e.g., 55 &gt; 72 &gt; 103 means SPID 55 blocks 72, which blocks 103). <b>Empty table = no blocking right now.</b> Action: Focus on Level 0 sessions first - killing or optimizing the head blocker resolves the entire chain below it.</div>';
SET @h=@h+N'<table><tr><th>SPID</th><th>Blocked By</th><th>Lvl</th><th>Chain</th><th>DB</th><th>Login</th><th>Wait</th><th>Sec</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(sid AS NVARCHAR)+N'</td><td>'+CAST(bsid AS NVARCHAR)+N'</td><td>'+CAST(lv AS NVARCHAR)+N'</td><td>'+ISNULL(ch,N'')+N'</td><td>'+ISNULL(db,N'')+N'</td><td>'+ISNULL(lg,N'')+N'</td><td>'+ISNULL(wt,N'')+N'</td><td>'+CAST(ISNULL(ws,0) AS NVARCHAR)+N'</td></tr>' FROM #BT ORDER BY ch,lv;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- ** ACTIVE SESSIONS
SET @h=@h+N'<h2 id="s1">** Active Sessions (Top 25) <span class="btt"><a href="#">Top</a></span></h2><div class="n2">Top 25 user sessions right now, sorted by status then CPU. <b>Key columns:</b> Status=running means actively executing; Wait=current wait type (blank=not waiting); CPU(ms)=cumulative CPU for this session; Run(m)=minutes the current request has been running (0=sleeping). <b>Look for:</b> Sessions with high Run(m) or unusual wait types. Running sessions with 0 CPU may be stuck on I/O or locks.</div>';
SET @h=@h+N'<table><tr><th>#</th><th>SPID</th><th>DB</th><th>Status</th><th>Login</th><th>Host</th><th>Cmd</th><th>Wait</th><th>CPU(ms)</th><th>Login(m)</th><th>Run(m)</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(rn AS NVARCHAR)+N'</td><td>'+CAST(sid AS NVARCHAR)+N'</td><td>'+ISNULL(db,N'')+N'</td><td>'+ISNULL(st,N'')+N'</td><td>'+ISNULL(lg,N'')+N'</td><td>'+ISNULL(hn,N'')+N'</td><td>'+ISNULL(cmd,N'')+N'</td><td>'+ISNULL(wt,N'')+N'</td><td>'+CAST(ISNULL(cm,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(lm,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(rm,0) AS NVARCHAR)+N'</td></tr>' FROM #AS1 ORDER BY rn;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- ** ACTIVE SESSIONS WITH SQL TEXT
SET @h=@h+N'<h2 id="s1b">** Active Sessions with SQL Text (Top 10) <span class="btt"><a href="#">Top</a></span></h2><div class="n2">Top 10 running sessions with the actual SQL statement being executed. <b>How to read:</b> Current Statement = the specific statement within the batch that is executing right now (extracted via statement_start_offset/statement_end_offset). Full Batch = the entire SQL batch submitted by the client. <b>Use this to:</b> Identify expensive queries to optimize or kill, find ad-hoc queries that need parameterization, and see exactly what a blocking or long-running SPID is doing.</div>';
SET @h=@h+N'<table><tr><th>#</th><th>SPID</th><th>DB</th><th>Status</th><th>Login</th><th>Host</th><th>Wait</th><th>CPU(ms)</th><th>Run(m)</th><th>Current Statement</th><th>Full Batch</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(rn AS NVARCHAR)+N'</td><td>'+CAST(sid AS NVARCHAR)+N'</td><td>'+ISNULL(db,N'')+N'</td><td>'+ISNULL(st,N'')+N'</td><td>'+ISNULL(lg,N'')+N'</td><td>'+ISNULL(hn,N'')+N'</td><td>'+ISNULL(wt,N'')+N'</td><td>'+CAST(ISNULL(cm,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(rm,0) AS NVARCHAR)+N'</td><td style="white-space:pre-wrap;max-width:400px;font-size:9px">'+ISNULL(sqltxt,N'')+N'</td><td style="white-space:pre-wrap;max-width:400px;font-size:9px">'+ISNULL(fullsql,N'')+N'</td></tr>' FROM #AS2 ORDER BY rn;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- ** CURRENT WAIT EVENTS
SET @h=@h+N'<h2 id="s3">** Current Wait Events <span class="btt"><a href="#">Top</a></span></h2><div class="n2">Top 15 sessions actively waiting right now, sorted by wait duration. <b>Key columns:</b> Wait=the resource type being waited for; Sec=seconds spent waiting; Blocked By=SPID holding the resource (blank=not blocked by another session, e.g., I/O or CPU wait). <b>Common patterns:</b> LCK_M_*=lock contention, PAGEIOLATCH_*=disk reads (missing indexes or cold cache), CXPACKET=parallelism, ASYNC_NETWORK_IO=slow client app.</div>';
SET @h=@h+N'<table><tr><th>#</th><th>SPID</th><th>DB</th><th>Login</th><th>Wait</th><th>Sec</th><th>Cmd</th><th>Blocked By</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(rn AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(sid,0) AS NVARCHAR)+N'</td><td>'+ISNULL(db,N'')+N'</td><td>'+ISNULL(lg,N'')+N'</td><td>'+ISNULL(wt,N'')+N'</td><td>'+CAST(ISNULL(ws,0) AS NVARCHAR)+N'</td><td>'+ISNULL(cmd,N'')+N'</td><td>'+CASE WHEN ISNULL(bsid,0)>0 THEN CAST(bsid AS NVARCHAR) ELSE N'' END+N'</td></tr>' FROM #CW ORDER BY rn;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- ** RESOURCE SEMAPHORE
SET @h=@h+N'<h2 id="s4">** Resource Semaphore (Memory Grants) <span class="btt"><a href="#">Top</a></span></h2><div class="n2">Memory grant queues per resource pool. <b>Key columns:</b> Total=max memory available for grants; Avail=currently free for new grants; Granted=memory assigned to running queries; Grantees=number of queries with a grant; <b>Waiters=queries queued waiting for memory (critical - should be 0).</b> If Waiters &gt; 0, queries are stuck in line. Action: reduce MAXDOP, kill large sort/hash queries, or add RAM.</div>';
SET @h=@h+N'<table><tr><th>Pool</th><th>Total(MB)</th><th>Avail(MB)</th><th>Granted(MB)</th><th>Used(MB)</th><th>Grantees</th><th>Waiters</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(pid AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(tmb,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(amb,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(gmb,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(umb,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(gc,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(wc,0) AS NVARCHAR)+N'</td></tr>' FROM #RS;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- ** TEMPDB USAGE
SET @h=@h+N'<h2 id="s5">** TempDB Usage <span class="btt"><a href="#">Top</a></span></h2><div class="n2">Each TempDB file with space usage. <b>Key metric:</b> Used% - under 75% is healthy. Multiple DATA files should be equally sized (SQL round-robins across them). If one file is much larger, check for uneven autogrowth. <b>Best practice:</b> 1 data file per CPU core (up to 8), all same initial size, same autogrowth. Log file should be on a separate drive from data files.</div>';
SET @h=@h+N'<table><tr><th>File</th><th>Type</th><th>Total(MB)</th><th>Used(MB)</th><th>Used%</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+ISNULL(fn,N'')+N'</td><td>'+ISNULL(ft,N'')+N'</td><td>'+CAST(ISNULL(tmb,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(umb,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(up,0) AS NVARCHAR)+N'%</td></tr>' FROM #TD;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- ** TEMPDB TOP CONSUMERS
SET @h=@h+N'<h2 id="s5b">** TempDB Top Consumers <span class="btt"><a href="#">Top</a></span></h2><div class="n2">Top 10 sessions consuming TempDB space. <b>How to read:</b> TempDB(MB) = total allocated pages (user objects + internal objects) per session. High values come from large sorts, hash joins, temp tables, table variables, or version store (RCSI/snapshot isolation). Source DB = the database context of the session. <b>Action:</b> If TempDB is filling up, these are the sessions to investigate or kill first.</div>';
SET @h=@h+N'<table><tr><th>#</th><th>SPID</th><th>Login</th><th>Host</th><th>Source DB</th><th>TempDB(MB)</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(rn AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(sid,0) AS NVARCHAR)+N'</td><td>'+ISNULL(lg,N'')+N'</td><td>'+ISNULL(hn,N'')+N'</td><td>'+ISNULL(db,N'')+N'</td><td>'+CAST(ISNULL(tmb,0) AS NVARCHAR)+N'</td></tr>' FROM #TDC ORDER BY rn;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- ** CONNECTIONS BY DATABASE
SET @h=@h+N'<h2 id="s6">** Connections by Database <span class="btt"><a href="#">Top</a></span></h2><div class="n2">Per-database connection summary. <b>Key columns:</b> Total=all sessions connected to this DB; Running=actively executing; Sleeping=idle but connected; Users=distinct logins. <b>How to read:</b> High Sleeping with low Running may indicate connection pool leaks. A healthy app has mostly sleeping connections with brief running bursts. If one DB has disproportionate connections, investigate that application.</div>';
SET @h=@h+N'<table><tr><th>Database</th><th>Total</th><th>Running</th><th>Sleeping</th><th>Users</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+ISNULL(db,N'')+N'</td><td>'+CAST(ISNULL(cnt,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(rn1,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(sl,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(ul,0) AS NVARCHAR)+N'</td></tr>' FROM #CN ORDER BY cnt DESC;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- ** OPEN TRANSACTIONS
SET @h=@h+N'<h2 id="s7">** Open Transactions (&gt;5 min) <span class="btt"><a href="#">Top</a></span></h2><div class="n2">Transactions open longer than 5 minutes. <b>Why this matters:</b> Open transactions prevent log truncation (log file grows unbounded), hold locks (causes blocking chains), and consume TempDB (version store). <b>How to read:</b> Open(min) = duration since BEGIN TRAN. Empty table = healthy, no long transactions. <b>Action:</b> Investigate the SPID - if orphaned, KILL it. If legitimate ETL, ensure it commits in batches.</div>';
SET @h=@h+N'<table><tr><th>SPID</th><th>Login</th><th>Host</th><th>DB</th><th>Open(min)</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(ISNULL(sid,0) AS NVARCHAR)+N'</td><td>'+ISNULL(lg,N'')+N'</td><td>'+ISNULL(hn,N'')+N'</td><td>'+ISNULL(db,N'')+N'</td><td>'+CAST(ISNULL(mn,0) AS NVARCHAR)+N'</td></tr>' FROM #OT ORDER BY mn DESC;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- ** RUNNING JOBS
SET @h=@h+N'<h2 id="s8">** Currently Running SQL Agent Jobs <span class="btt"><a href="#">Top</a></span></h2><div class="n2">SQL Agent jobs that are currently executing. <b>How to read:</b> Duration shows elapsed time. Long-running jobs may be stuck or processing large data. <b>Look for:</b> Jobs running much longer than usual, overlapping job schedules causing resource contention, or jobs running during peak hours. Empty table = no jobs running right now.</div>';
SET @h=@h+N'<table><tr><th>#</th><th>Job Name</th><th>Step</th><th>Start Time</th><th>Duration</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(rn AS NVARCHAR)+N'</td><td>'+ISNULL(jn,N'')+N'</td><td>'+ISNULL(sn,N'')+N'</td><td>'+ISNULL(CONVERT(NVARCHAR,sd,120),N'')+N'</td><td>'+ISNULL(dur,N'')+N'</td></tr>' FROM #RJ ORDER BY rn;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- ** NUMA
SET @h=@h+N'<h2 id="s9">** CPU per NUMA Node <span class="btt"><a href="#">Top</a></span></h2><div class="n2">Per-NUMA-node CPU and I/O metrics from OS schedulers. <b>Key columns:</b> Schedulers=logical CPUs on this node; Runnable=tasks ready to run but waiting for CPU (this is the CPU queue - <b>should be near 0</b>); Workers=active worker threads processing requests; Pending IO=I/O requests queued at OS level. <b>How to read:</b> Runnable &gt; 10 per node = CPU pressure on that node. Uneven Runnable across nodes may indicate NUMA imbalance. High Pending IO = storage bottleneck. If all nodes show high Runnable, the server needs more CPU cores or query optimization.</div>';
SET @h=@h+N'<table><tr><th>Node</th><th>Schedulers</th><th>Runnable</th><th>Workers</th><th>Pending IO</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(nd AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(sc,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(rtk,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(aw,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(pi,0) AS NVARCHAR)+N'</td></tr>' FROM #NU ORDER BY nd;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- ** TPS
SET @h=@h+N'<h2 id="tps">** TPS (Transactions/sec) <span class="btt"><a href="#">Top</a></span></h2><div class="n2">Throughput measured via a 1-second sample. <b>How to read the summary row:</b> Current TPS = transactions committed in the 1-sec sample; Batch/sec = client requests received (includes all statements, not just commits); Avg TPS = average since SQL Server restart (cumulative counter / uptime seconds). <b>Interpreting:</b> If Current TPS is much higher than Avg, you are in a peak period. If much lower, the server is idle or stalled. The per-database table below shows which databases are generating the most transactions right now - useful for identifying hot databases during peak load.</div>';
SET @h=@h+N'<table class="snp"><tr><th>Current TPS:</th><td>'+CAST(ISNULL(@curtps,0) AS NVARCHAR)+N'</td><th>Current Batch/sec:</th><td>'+CAST(ISNULL(@curbps,0) AS NVARCHAR)+N'</td><th>Avg TPS (since restart):</th><td>'+CAST(ISNULL(@avgtps,0) AS NVARCHAR)+N'</td><th>Avg Batch/sec:</th><td>'+CAST(ISNULL(@avgbps,0) AS NVARCHAR)+N'</td></tr></table>';
SET @h=@h+N'<div class="n2">Per-Database TPS (1-sec sample) - shows which databases are most active right now:</div><table><tr><th>#</th><th>Database</th><th>TPS</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(rn AS NVARCHAR)+N'</td><td>'+ISNULL(dn,N'')+N'</td><td>'+CAST(ISNULL(tps,0) AS NVARCHAR)+N'</td></tr>' FROM #TPD ORDER BY rn;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- ===================== HISTORICAL / CONFIG SECTIONS =====================

-- TOP WAIT STATISTICS
SET @h=@h+N'<h2 id="s10">Top Wait Statistics (Since Restart) <span class="btt"><a href="#">Top</a></span></h2><div class="n2">Cumulative waits since SQL Server restart with benign system waits filtered out. <b>Key columns:</b> Wait(s)=total seconds all tasks spent on this wait; Resource(s)=time waiting for the actual resource (disk, lock, memory); Signal(s)=time waiting for CPU after resource was ready; %=proportion of total wait time. <b>How to read:</b> Focus on the top 3-5 waits. High Resource time = storage/lock problem. High Signal time = CPU problem. The Description, Probable Cause, and Remediation columns explain each wait type and what to do about it.</div>';
SET @h=@h+N'<table><tr><th>#</th><th>Wait Type</th><th>Count</th><th>Wait(s)</th><th>Resource(s)</th><th>Signal(s)</th><th>%</th><th>Description</th><th>Probable Cause</th><th>Remediation</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(rn AS NVARCHAR)+N'</td><td>'+ISNULL(wt,N'')+N'</td><td>'+CAST(ISNULL(cnt,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(ws,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(rs,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(ss,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(pct,0) AS NVARCHAR)+N'%</td><td>'+ISNULL(descr,N'')+N'</td><td>'+ISNULL(reason,N'')+N'</td><td>'+ISNULL(fix,N'')+N'</td></tr>' FROM #W ORDER BY rn;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- TOP CPU SESSIONS
SET @h=@h+N'<h2 id="s11">Top CPU Sessions (Cumulative) <span class="btt"><a href="#">Top</a></span></h2><div class="n2">Top 10 individual sessions by cumulative CPU time since they connected. <b>Key columns:</b> CPU(ms)=total CPU milliseconds consumed by this session; CPU%=share of total user CPU across all sessions. <b>How to read:</b> High CPU on a sleeping session means it ran expensive queries earlier. High CPU on a running session means it is actively consuming CPU now. Cross-reference with Active Sessions to see if the session is still executing.</div>';
SET @h=@h+N'<table><tr><th>#</th><th>SPID</th><th>Login</th><th>Host</th><th>DB</th><th>CPU(ms)</th><th>CPU%</th><th>Status</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(rn AS NVARCHAR)+N'</td><td>'+CAST(sid AS NVARCHAR)+N'</td><td>'+ISNULL(lg,N'')+N'</td><td>'+ISNULL(hn,N'')+N'</td><td>'+ISNULL(db,N'')+N'</td><td>'+CAST(ISNULL(cm,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(cp,0) AS NVARCHAR)+N'%</td><td>'+ISNULL(st,N'')+N'</td></tr>' FROM #TC ORDER BY rn;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- TOP 10 USERS BY CPU %
SET @h=@h+N'<h2 id="s11b">Top 10 Users by CPU % <span class="btt"><a href="#">Top</a></span></h2><div class="n2">CPU usage aggregated by login name (all sessions per user combined). <b>Key columns:</b> Sessions=number of connections for this login; Total CPU(ms)=sum of CPU across all their sessions; CPU%=share of total user CPU; Reads/Writes=physical I/O; Logical Reads=pages read from buffer cache (high values = large scans). <b>How to read:</b> Identifies which service accounts or users are consuming the most CPU. Useful for chargeback, capacity planning, or finding runaway application accounts.</div>';
SET @h=@h+N'<table><tr><th>#</th><th>Login</th><th>Sessions</th><th>Total CPU(ms)</th><th>CPU%</th><th>Reads</th><th>Writes</th><th>Logical Reads</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(rn AS NVARCHAR)+N'</td><td>'+ISNULL(lg,N'')+N'</td><td>'+CAST(ISNULL(sess,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(tcpu,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(cp,0) AS NVARCHAR)+N'%</td><td>'+CAST(ISNULL(tr,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(tw,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(tlr,0) AS NVARCHAR)+N'</td></tr>' FROM #UC ORDER BY rn;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- TOP MEMORY SESSIONS
SET @h=@h+N'<h2 id="s12">Top Memory Sessions <span class="btt"><a href="#">Top</a></span></h2><div class="n2">Top 10 individual sessions by memory usage (buffer pool pages held). <b>Key columns:</b> Mem(KB)=session memory in KB (connection context, cursors, plan cache references); %=share of total user session memory. <b>Note:</b> This is session-level memory, not query memory grants. For active query memory grants, see the Resource Semaphore and Users by Mem% sections.</div>';
SET @h=@h+N'<table><tr><th>#</th><th>SPID</th><th>Login</th><th>Host</th><th>DB</th><th>Mem(KB)</th><th>%</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(rn AS NVARCHAR)+N'</td><td>'+CAST(sid AS NVARCHAR)+N'</td><td>'+ISNULL(lg,N'')+N'</td><td>'+ISNULL(hn,N'')+N'</td><td>'+ISNULL(db,N'')+N'</td><td>'+CAST(ISNULL(mk,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(mp,0) AS NVARCHAR)+N'%</td></tr>' FROM #TM ORDER BY rn;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- TOP 10 USERS BY MEMORY %
SET @h=@h+N'<h2 id="s12b">Top 10 Users by Memory % <span class="btt"><a href="#">Top</a></span></h2><div class="n2">Memory usage aggregated by login name. <b>Key columns:</b> Memory(KB)=sum of session memory across all connections for this login; Mem%=share of total; Granted(MB)=active query memory grants (for sorts, hashes, etc.); Used(MB)=how much of the grant is actually being used. <b>How to read:</b> High Granted with low Used = over-estimated memory grants (queries requesting more than they need). High Used = legitimately large operations.</div>';
SET @h=@h+N'<table><tr><th>#</th><th>Login</th><th>Sessions</th><th>Memory(KB)</th><th>Mem%</th><th>Granted(MB)</th><th>Used(MB)</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(rn AS NVARCHAR)+N'</td><td>'+ISNULL(lg,N'')+N'</td><td>'+CAST(ISNULL(sess,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(tmem,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(mp,0) AS NVARCHAR)+N'%</td><td>'+CAST(ISNULL(gmb,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(umb,0) AS NVARCHAR)+N'</td></tr>' FROM #UM ORDER BY rn;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- MEMORY PRESSURE INDICATORS
SET @h=@h+N'<h2 id="mpi">Memory Pressure Indicators <span class="btt"><a href="#">Top</a></span></h2><div class="n2">Key memory health counters from performance counters. <b>How to read:</b> Buffer Cache Hit Ratio should be &gt;99% (lower = too many disk reads); PLE should be &gt;300s (lower = pages evicted too fast); Memory Grants Pending should be 0 (any value = queries queued); Lazy Writes &gt;20/sec = buffer pool flushing aggressively; Free List Stalls &gt;0 = requests waiting for free pages. Total vs Target: if Total &lt; Target, SQL has not reached its memory goal due to external pressure.</div>';
SET @h=@h+N'<table><tr><th>Counter</th><th>Value</th><th>Status</th><th>Action</th></tr>';

DECLARE @bchr BIGINT,@bchrb BIGINT,@bchrp DECIMAL(10,2);
SELECT @bchr=ISNULL(cv,0) FROM #MP WHERE cn='Buffer cache hit ratio' AND rn=1;
SELECT @bchrb=ISNULL(cv,1) FROM #MP WHERE cn='Buffer cache hit ratio base' AND rn=1;
SET @bchrb=CASE WHEN ISNULL(@bchrb,0)=0 THEN 1 ELSE @bchrb END;
SET @bchrp=CAST(ROUND(@bchr*100.0/@bchrb,2) AS DECIMAL(10,2));
SET @h=@h+N'<tr><td>Buffer Cache Hit Ratio</td><td>'+CAST(ISNULL(@bchrp,0) AS NVARCHAR)+N'%</td><td>'
  +CASE WHEN @bchrp<95 THEN N'<span class="b bc">CRITICAL</span>' WHEN @bchrp<99 THEN N'<span class="b bw">WARNING</span>' ELSE N'<span class="b bg">OK</span>' END
  +N'</td><td>'+CASE WHEN @bchrp<99 THEN N'Increase RAM / check queries doing large scans' ELSE N'' END+N'</td></tr>';

DECLARE @mpple BIGINT;SELECT @mpple=ISNULL(cv,0) FROM #MP WHERE cn='Page life expectancy' AND rn=1;
SET @h=@h+N'<tr><td>Page Life Expectancy</td><td>'+CAST(ISNULL(@mpple,0) AS NVARCHAR)+N' sec</td><td>'
  +CASE WHEN @mpple<300 THEN N'<span class="b bc">CRITICAL</span>' WHEN @mpple<1000 THEN N'<span class="b bw">WARNING</span>' ELSE N'<span class="b bg">OK</span>' END
  +N'</td><td>'+CASE WHEN @mpple<300 THEN N'Severe memory pressure - increase RAM immediately' WHEN @mpple<1000 THEN N'Memory pressure building - consider more RAM' ELSE N'' END+N'</td></tr>';

DECLARE @mpgp BIGINT;SELECT @mpgp=ISNULL(cv,0) FROM #MP WHERE cn='Memory Grants Pending' AND rn=1;
SET @h=@h+N'<tr><td>Memory Grants Pending</td><td>'+CAST(ISNULL(@mpgp,0) AS NVARCHAR)+N'</td><td>'
  +CASE WHEN @mpgp>5 THEN N'<span class="b bc">CRITICAL</span>' WHEN @mpgp>0 THEN N'<span class="b bw">WARNING</span>' ELSE N'<span class="b bg">OK</span>' END
  +N'</td><td>'+CASE WHEN @mpgp>0 THEN N'Queries waiting for memory - reduce MAXDOP or increase RAM' ELSE N'' END+N'</td></tr>';

DECLARE @mplw BIGINT;SELECT @mplw=ISNULL(cv,0) FROM #MP WHERE cn='Lazy writes/sec' AND rn=1;
SET @h=@h+N'<tr><td>Lazy Writes/sec</td><td>'+CAST(ISNULL(@mplw,0) AS NVARCHAR)+N'</td><td>'
  +CASE WHEN @mplw>20 THEN N'<span class="b bw">WARNING</span>' ELSE N'<span class="b bg">OK</span>' END
  +N'</td><td>'+CASE WHEN @mplw>20 THEN N'Buffer pool under pressure - pages being flushed aggressively' ELSE N'' END+N'</td></tr>';

DECLARE @mpfl BIGINT;SELECT @mpfl=ISNULL(cv,0) FROM #MP WHERE cn='Free list stalls/sec' AND rn=1;
SET @h=@h+N'<tr><td>Free List Stalls/sec</td><td>'+CAST(ISNULL(@mpfl,0) AS NVARCHAR)+N'</td><td>'
  +CASE WHEN @mpfl>2 THEN N'<span class="b bc">CRITICAL</span>' WHEN @mpfl>0 THEN N'<span class="b bw">WARNING</span>' ELSE N'<span class="b bg">OK</span>' END
  +N'</td><td>'+CASE WHEN @mpfl>0 THEN N'Requests stalled waiting for free buffer pages' ELSE N'' END+N'</td></tr>';

DECLARE @mptm BIGINT,@mptg BIGINT;
SELECT @mptm=ISNULL(cv,0) FROM #MP WHERE cn='Total Server Memory (KB)' AND rn=1;
SELECT @mptg=ISNULL(cv,0) FROM #MP WHERE cn='Target Server Memory (KB)' AND rn=1;
SET @h=@h+N'<tr><td>Total Server Memory</td><td>'+CAST(ISNULL(@mptm/1024,0) AS NVARCHAR)+N' MB</td><td>'
  +CASE WHEN @mptm<@mptg THEN N'<span class="b bw">WARNING</span>' ELSE N'<span class="b bg">OK</span>' END
  +N'</td><td>'+CASE WHEN @mptm<@mptg THEN N'SQL not at target - external memory pressure' ELSE N'' END+N'</td></tr>';
SET @h=@h+N'<tr><td>Target Server Memory</td><td>'+CAST(ISNULL(@mptg/1024,0) AS NVARCHAR)+N' MB</td><td><span class="b bi">INFO</span></td><td></td></tr>';
SET @h=@h+N'</table>';

-- CPU PRESSURE INDICATORS
SET @h=@h+N'<h2 id="cpi">CPU Pressure Indicators <span class="btt"><a href="#">Top</a></span></h2><div class="n2">Cumulative CPU-related counters since restart. <b>How to read:</b> Batch Requests/sec = total client requests (baseline metric); SQL Compilations/sec = plan compilation events (high ratio to batches = plan cache misses, enable optimize for ad hoc workloads); SQL Re-Compilations/sec = plans being recompiled (high = schema changes, stats updates, or temp table issues); Forced Parameterizations/sec = queries auto-parameterized. <b>Key ratio:</b> Compilations/Batches &gt; 10% = WARNING. Recompilations/Batches &gt; 10% = WARNING.</div>';
SET @h=@h+N'<table><tr><th>Counter</th><th>Value</th><th>Status</th><th>Action</th></tr>';

DECLARE @cpbr BIGINT,@cpsc BIGINT,@cprc BIGINT,@cpfp BIGINT;
SELECT @cpbr=ISNULL(cv,0) FROM #CP WHERE cn='Batch Requests/sec' AND rn=1;
SELECT @cpsc=ISNULL(cv,0) FROM #CP WHERE cn='SQL Compilations/sec' AND rn=1;
SELECT @cprc=ISNULL(cv,0) FROM #CP WHERE cn='SQL Re-Compilations/sec' AND rn=1;
SELECT @cpfp=ISNULL(cv,0) FROM #CP WHERE cn='Forced Parameterizations/sec' AND rn=1;

SET @h=@h+N'<tr><td>Batch Requests/sec (cumulative)</td><td>'+CAST(ISNULL(@cpbr,0) AS NVARCHAR)+N'</td><td><span class="b bi">INFO</span></td><td>Baseline: current TPS = '+CAST(ISNULL(@curbps,0) AS NVARCHAR)+N'/sec</td></tr>';
SET @h=@h+N'<tr><td>SQL Compilations/sec (cumulative)</td><td>'+CAST(ISNULL(@cpsc,0) AS NVARCHAR)+N'</td><td>'
  +CASE WHEN @cpsc>0 AND @cpbr>0 AND CAST(@cpsc AS FLOAT)/CAST(@cpbr AS FLOAT)>0.1 THEN N'<span class="b bw">WARNING</span>' ELSE N'<span class="b bg">OK</span>' END
  +N'</td><td>'+CASE WHEN @cpsc>0 AND @cpbr>0 AND CAST(@cpsc AS FLOAT)/CAST(@cpbr AS FLOAT)>0.1 THEN N'High compilation ratio - enable optimize for ad hoc workloads' ELSE N'' END+N'</td></tr>';
SET @h=@h+N'<tr><td>SQL Re-Compilations/sec (cumulative)</td><td>'+CAST(ISNULL(@cprc,0) AS NVARCHAR)+N'</td><td>'
  +CASE WHEN @cprc>0 AND @cpbr>0 AND CAST(@cprc AS FLOAT)/CAST(@cpbr AS FLOAT)>0.1 THEN N'<span class="b bw">WARNING</span>' ELSE N'<span class="b bg">OK</span>' END
  +N'</td><td>'+CASE WHEN @cprc>0 AND @cpbr>0 AND CAST(@cprc AS FLOAT)/CAST(@cpbr AS FLOAT)>0.1 THEN N'High recompilation - check schema changes, stats updates, temp table usage' ELSE N'' END+N'</td></tr>';
SET @h=@h+N'<tr><td>Forced Parameterizations/sec (cumulative)</td><td>'+CAST(ISNULL(@cpfp,0) AS NVARCHAR)+N'</td><td><span class="b bi">INFO</span></td><td></td></tr>';
SET @h=@h+N'</table>';

-- I/O LATENCY
SET @h=@h+N'<h2 id="s13">I/O Latency by File <span class="btt"><a href="#">Top</a></span></h2><div class="n2">Top 10 database files by average I/O latency (cumulative since restart). <b>Key columns:</b> Read(ms)=average ms per read operation; Write(ms)=average ms per write; Total(ms)=combined average. <b>Healthy thresholds:</b> Data files &lt;30ms (ideally &lt;10ms); Log files &lt;5ms (ideally &lt;2ms). <b>How to read:</b> High read latency = slow storage or missing indexes causing full scans. High write latency = slow log disk or checkpoint pressure. Only files with &gt;100 I/O operations are shown to filter noise.</div>';
SET @h=@h+N'<table><tr><th>#</th><th>DB</th><th>File</th><th>Type</th><th>Read(ms)</th><th>Write(ms)</th><th>Total(ms)</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(rn AS NVARCHAR)+N'</td><td>'+ISNULL(db,N'')+N'</td><td>'+ISNULL(fn,N'')+N'</td><td>'+ISNULL(ft,N'')+N'</td><td>'+CAST(ISNULL(rm,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(wm,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(tm,0) AS NVARCHAR)+N'</td></tr>' FROM #IO ORDER BY rn;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- DATABASE SIZES
SET @h=@h+N'<h2 id="s14">Database Sizes <span class="btt"><a href="#">Top</a></span></h2><div class="n2">All online databases sorted by total size. <b>Key columns:</b> Recovery=FULL (needs log backups), SIMPLE (auto-truncates log), BULK_LOGGED (minimal logging for bulk ops); Data(MB)=data file allocation; Log(MB)=log file allocation; Total(GB)=combined. <b>How to read:</b> Large log files relative to data may indicate missing log backups (FULL recovery) or open transactions. Track Total(GB) over time for capacity planning.</div>';
SET @h=@h+N'<table><tr><th>#</th><th>Database</th><th>Recovery</th><th>Data(MB)</th><th>Log(MB)</th><th>Total(GB)</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(rn AS NVARCHAR)+N'</td><td>'+ISNULL(nm,N'')+N'</td><td>'+ISNULL(rc,N'')+N'</td><td>'+CAST(ISNULL(dm,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(lm,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(tg,0) AS NVARCHAR)+N'</td></tr>' FROM #DB ORDER BY rn;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- DRIVE FREE SPACE
SET @h=@h+N'<h2 id="s15">Drive Free Space <span class="btt"><a href="#">Top</a></span></h2><div class="n2">Free space on each drive visible to SQL Server (via xp_fixeddrives). <b>Thresholds:</b> Under 1GB = CRITICAL (database growth will fail); Under 5GB = WARNING (plan extension). <b>How to read:</b> Sorted by least free space first. Check which drives host data files, log files, TempDB, and backups. Ensure backup drives have enough room for the next full backup cycle.</div>';
SET @h=@h+N'<table><tr><th>#</th><th>Drive</th><th>Free(MB)</th><th>Free(GB)</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(rn AS NVARCHAR)+N'</td><td>'+ISNULL(dr,N'')+N':</td><td>'+CAST(ISNULL(fm,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(fg,0) AS NVARCHAR)+N'</td></tr>' FROM #D2 ORDER BY rn;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- FAILED JOBS
SET @h=@h+N'<h2 id="s16">Failed SQL Agent Jobs (Last 24h) <span class="btt"><a href="#">Top</a></span></h2><div class="n2">Top 25 job failures in the last 24 hours. <b>How to read:</b> Look for repeating job names (same job failing on every schedule = systematic issue). Read the Error Message for the root cause. Common causes: permission errors, missing objects, timeouts, disk full. <b>Empty table = no failures, which is healthy.</b> Action: fix the root cause and re-run, or disable jobs that reference removed objects.</div>';
SET @h=@h+N'<table><tr><th>#</th><th>Job Name</th><th>Step</th><th>Run Time</th><th>Error Message</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(rn AS NVARCHAR)+N'</td><td>'+ISNULL(jn,N'')+N'</td><td>'+ISNULL(stp,N'')+N'</td><td>'+ISNULL(CONVERT(NVARCHAR,rd,120),N'')+N'</td><td style="white-space:normal;max-width:500px">'+ISNULL(msg,N'')+N'</td></tr>' FROM #FJ ORDER BY rn;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- KEY CONFIGURATION
SET @h=@h+N'<h2 id="s17">Key Configuration <span class="btt"><a href="#">Top</a></span></h2><div class="n2">Critical sp_configure settings. <b>Best practices:</b> max degree of parallelism = 4-8 (not 0); cost threshold for parallelism = 25-50 (not default 5); optimize for ad hoc workloads = 1 (reduces plan cache bloat); max server memory = ~80% of total RAM (not 2147483647); backup compression default = 1 (saves disk and speeds up backups). min server memory can usually be 0 unless you need guaranteed memory floor.</div>';
SET @h=@h+N'<table><tr><th>Setting</th><th>Value</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+ISNULL(nm,N'')+N'</td><td>'+ISNULL(vl,N'')+N'</td></tr>' FROM #CF;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- SUSPECT PAGES
SET @h=@h+N'<h2 id="sps">Suspect Pages <span class="btt"><a href="#">Top</a></span></h2><div class="n2">Pages flagged as corrupt in msdb.dbo.suspect_pages. <b>Event types:</b> 823=OS read error, Bad checksum=data integrity failure, Torn page=incomplete write. <b>Empty table = healthy, no corruption detected.</b> If any rows appear, this is a CRITICAL issue: run DBCC CHECKDB on the affected database immediately, check backup validity, and plan a restore if needed. Even 1 suspect page indicates potential data loss.</div>';
SET @h=@h+N'<table><tr><th>Database</th><th>File ID</th><th>Page ID</th><th>Event</th><th>Error Count</th><th>Last Updated</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+ISNULL(db,N'')+N'</td><td>'+CAST(ISNULL(fid,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(pid,0) AS NVARCHAR)+N'</td><td>'+ISNULL(ev,N'')+N'</td><td>'+CAST(ISNULL(ec,0) AS NVARCHAR)+N'</td><td>'+ISNULL(CONVERT(NVARCHAR,lu,120),N'')+N'</td></tr>' FROM #SP;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- ERROR LOG
SET @h=@h+N'<h2 id="erl">Error Log (Last 24h) <span class="btt"><a href="#">Top</a></span></h2><div class="n2">Top 20 error entries from sp_readerrorlog filtered for the keyword "Error" in the last 24 hours. <b>How to read:</b> Look for patterns - the same error repeating indicates a systematic issue. Check severity: login failures may be brute-force attempts, I/O errors indicate disk problems, memory errors indicate pressure. <b>Empty or "unavailable":</b> Error log may be too large or permissions insufficient - run sp_readerrorlog manually to verify.</div>';
SET @h=@h+N'<table><tr><th>#</th><th>Date</th><th>Source</th><th>Message</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(rn AS NVARCHAR)+N'</td><td>'+ISNULL(CONVERT(NVARCHAR,ld,120),N'')+N'</td><td>'+ISNULL(pi,N'')+N'</td><td style="white-space:normal;max-width:600px">'+ISNULL(lt,N'')+N'</td></tr>' FROM #EL ORDER BY rn;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- TRACE FLAGS
SET @h=@h+N'<h2 id="trf">Trace Flags <span class="btt"><a href="#">Top</a></span></h2><div class="n2">Active trace flags set via DBCC TRACEON or startup parameters. <b>Key columns:</b> Global=applies to all sessions; Session=applies only to current session. <b>Common recommended flags:</b> 1222=deadlock graphs in error log; 3226=suppress backup success messages; 7412=lightweight profiling. <b>Empty table = no trace flags enabled.</b> Note: SQL 2016+ has many trace flag behaviors built into the engine via database-scoped configurations.</div>';
SET @h=@h+N'<table><tr><th>Trace Flag</th><th>Status</th><th>Global</th><th>Session</th><th>Description</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(ISNULL(tf,0) AS NVARCHAR)+N'</td><td>'+CASE WHEN st1=1 THEN N'ON' ELSE N'OFF' END+N'</td><td>'+CASE WHEN gl=1 THEN N'Yes' ELSE N'No' END+N'</td><td>'+CASE WHEN se=1 THEN N'Yes' ELSE N'No' END+N'</td><td>'
  +CASE tf
    WHEN 1117 THEN N'Uniform extent allocation for TempDB'
    WHEN 1118 THEN N'Remove mixed extent allocation (TempDB contention fix)'
    WHEN 1204 THEN N'Deadlock information in error log'
    WHEN 1222 THEN N'Detailed deadlock graph in error log'
    WHEN 1224 THEN N'Disable lock escalation based on lock count'
    WHEN 2371 THEN N'Dynamic auto-update statistics threshold'
    WHEN 3023 THEN N'Enable CHECKSUM for BACKUP by default'
    WHEN 3226 THEN N'Suppress successful backup messages in error log'
    WHEN 3449 THEN N'Enable uniform dirty page flushing'
    WHEN 3895 THEN N'DROP_DML_SOR disables strict sort order optimization'
    WHEN 4199 THEN N'Enable query optimizer fixes'
    WHEN 6532 THEN N'Enable spatial data type performance improvements'
    WHEN 7412 THEN N'Enable lightweight query profiling'
    WHEN 8048 THEN N'Convert NUMA-partitioned memory to CPU-partitioned'
    WHEN 9481 THEN N'Force legacy cardinality estimator'
    WHEN 2453 THEN N'Table variable deferred compilation'
    ELSE N'' END
  +N'</td></tr>' FROM #TF;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- ===================== NEW INSIGHT SECTIONS =====================

-- TOP QUERIES BY CPU
SET @h=@h+N'<h2 id="tq">Top Queries by CPU (Since Restart) <span class="btt"><a href="#">Top</a></span></h2>';
SET @h=@h+N'<div class="n2">Top 20 queries by cumulative CPU time. <b>Key columns:</b> Total CPU(ms)=all executions combined; Avg CPU(ms)=per execution cost; Avg Reads=logical reads per run (high = missing index or large scan); Avg Dur(ms)=elapsed time per run. <b>Tip:</b> Optimize high Avg CPU or Avg Reads first — they yield the most gain per query fixed. High Execs with moderate CPU can also add up to significant total load.</div>';
SET @h=@h+N'<table><tr><th>#</th><th>Total CPU(ms)</th><th>Execs</th><th>Avg CPU(ms)</th><th>Total Reads</th><th>Avg Reads</th><th>Avg Dur(ms)</th><th>SQL Text</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(rn AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(cpu_ms,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(execs,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(avg_cpu_ms,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(log_reads,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(avg_reads,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(avg_dur_ms,0) AS NVARCHAR)+N'</td><td style="white-space:pre-wrap;max-width:500px;font-size:10px;font-family:Courier New,monospace">'+ISNULL(sql_text,N'')+N'</td></tr>' FROM #TQ ORDER BY rn;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- MISSING INDEXES
SET @h=@h+N'<h2 id="mi">Missing Index Recommendations <span class="btt"><a href="#">Top</a></span></h2>';
SET @h=@h+N'<div class="n2">Top 20 missing indexes ranked by optimizer impact score (cost × impact% × usage). <b>Key columns:</b> Impact%=estimated query improvement if this index existed; Score=priority rank. <b>Caution:</b> Do not blindly create all — review, combine overlapping recommendations, and test in non-prod. High Score + high Impact% = best candidates. Empty table = optimizer has no recommendations (good).</div>';
SET @h=@h+N'<table><tr><th>#</th><th>DB</th><th>Table</th><th>Equality Cols</th><th>Inequality Cols</th><th>Include Cols</th><th>Seeks</th><th>Scans</th><th>Impact%</th><th>Score</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(rn AS NVARCHAR)+N'</td><td>'+ISNULL(db,N'')+N'</td><td>'+ISNULL(tbl,N'')+N'</td><td style="font-size:10px;font-family:Courier New,monospace">'+ISNULL(eq_cols,N'')+N'</td><td style="font-size:10px;font-family:Courier New,monospace">'+ISNULL(ineq_cols,N'')+N'</td><td style="font-size:10px;font-family:Courier New,monospace">'+ISNULL(inc_cols,N'')+N'</td><td>'+CAST(ISNULL(seeks,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(scans,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(impact,0) AS NVARCHAR)+N'%</td><td>'+CAST(ISNULL(score,0) AS NVARCHAR)+N'</td></tr>' FROM #MI ORDER BY rn;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- BACKUP STATUS
SET @h=@h+N'<h2 id="bk">Backup Status per Database <span class="btt"><a href="#">Top</a></span></h2>';
SET @h=@h+N'<div class="n2">Last backup dates per database (scans last 30 days). <b>Key column:</b> Full Age(h)=hours since last full backup — NULL means never backed up. <b>Best practice:</b> FULL recovery model databases need log backups every 15–60 min. SIMPLE recovery only needs full/diff. <b>Critical:</b> Any NULL in Last Full = no disaster recovery for that database.</div>';
SET @h=@h+N'<table><tr><th>#</th><th>Database</th><th>Recovery</th><th>Last Full</th><th>Last Diff</th><th>Last Log</th><th>Full Age(h)</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(rn AS NVARCHAR)+N'</td><td>'+ISNULL(db,N'')+N'</td><td>'+ISNULL(rm,N'')+N'</td><td>'+ISNULL(CONVERT(NVARCHAR,last_full,120),N'<b style="color:#cc0000">NEVER</b>')+N'</td><td>'+ISNULL(CONVERT(NVARCHAR,last_diff,120),N'&mdash;')+N'</td><td>'+ISNULL(CONVERT(NVARCHAR,last_log,120),N'&mdash;')+N'</td><td>'+CASE WHEN last_full IS NULL THEN N'<span class="b bc">NEVER</span>' WHEN ISNULL(full_age_h,0)>48 THEN N'<span class="b bw">'+CAST(full_age_h AS NVARCHAR)+N'h</span>' ELSE CAST(ISNULL(full_age_h,0) AS NVARCHAR)+N'h' END+N'</td></tr>' FROM #BK ORDER BY ISNULL(full_age_h,99999) DESC;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- PLAN CACHE HEALTH
DECLARE @pc_total INT,@pc_single INT,@pc_spct DECIMAL(10,1),@pc_mb INT,@pc_waste INT;
SET @pc_total=0;SET @pc_single=0;SET @pc_spct=0;SET @pc_mb=0;SET @pc_waste=0;
SELECT @pc_total=ISNULL(total_plans,0),@pc_single=ISNULL(single_use,0),@pc_spct=ISNULL(single_use_pct,0),
  @pc_mb=ISNULL(total_mb,0),@pc_waste=ISNULL(waste_mb,0) FROM #PC;
SET @h=@h+N'<h2 id="pc">Plan Cache Health <span class="btt"><a href="#">Top</a></span></h2>';
SET @h=@h+N'<div class="n2">Aggregate plan cache stats for ad-hoc and prepared plans. <b>Single-Use Plans</b>=compiled once and never reused — each wastes memory and a compilation event. <b>Fix:</b> If single-use % exceeds 40%, run: <code>EXEC sp_configure ''optimize for ad hoc workloads'',1;RECONFIGURE;</code> — stores only a plan stub on first run, full plan on second. Saves memory without hurting performance.</div>';
SET @h=@h+N'<table class="snp"><tr><th>Total Plans:</th><td>'+CAST(@pc_total AS NVARCHAR)+N'</td><th>Single-Use:</th><td>'+CAST(@pc_single AS NVARCHAR)+N'</td><th>Single-Use %:</th><td>'+CAST(@pc_spct AS NVARCHAR)+N'%</td><th>Cache Size (MB):</th><td>'+CAST(@pc_mb AS NVARCHAR)+N'</td><th>Wasted (MB):</th><td>'+CAST(@pc_waste AS NVARCHAR)+N'</td></tr></table>';

-- MEMORY CLERKS
SET @h=@h+N'<h2 id="mc">Memory Clerks Breakdown <span class="btt"><a href="#">Top</a></span></h2>';
SET @h=@h+N'<div class="n2">Top 15 SQL Server memory consumers by type. <b>Key clerks:</b> MEMORYCLERK_SQLBUFFERPOOL=buffer pool (data+index pages, should dominate); CACHESTORE_SQLCP=SQL plan cache; CACHESTORE_OBJCP=stored proc plan cache; MEMORYCLERK_SQLQUERYWORKSPACE=active query sorts/hashes; MEMORYCLERK_SQLCLR=CLR runtime. <b>How to read:</b> If buffer pool is not the largest, investigate what is consuming memory unexpectedly.</div>';
SET @h=@h+N'<table><tr><th>#</th><th>Memory Clerk Type</th><th>Used (MB)</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(rn AS NVARCHAR)+N'</td><td>'+ISNULL(tp,N'')+N'</td><td>'+CAST(ISNULL(mb,0) AS NVARCHAR)+N'</td></tr>' FROM #MC ORDER BY rn;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- AG HEALTH
SET @h=@h+N'<h2 id="ag">Availability Group Health <span class="btt"><a href="#">Top</a></span></h2>';
SET @h=@h+N'<div class="n2">AlwaysOn AG replica and database synchronization state. <b>Key columns:</b> Redo Queue(KB)=log on secondary waiting to be applied (0=fully caught up); Send Queue(KB)=log on primary not yet sent to secondary. <b>Empty table = no AG on this instance.</b> Action: growing Redo Queue = secondary falling behind; growing Send Queue = network bottleneck to secondary.</div>';
SET @h=@h+N'<table><tr><th>#</th><th>AG Name</th><th>Role</th><th>Sync Health</th><th>Database</th><th>DB Sync State</th><th>Redo Queue(KB)</th><th>Send Queue(KB)</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(rn AS NVARCHAR)+N'</td><td>'+ISNULL(ag_name,N'')+N'</td><td>'+ISNULL(role_desc,N'')+N'</td><td>'+ISNULL(sync_health,N'')+N'</td><td>'+ISNULL(db_name,N'')+N'</td><td>'+ISNULL(db_sync,N'')+N'</td><td>'+CAST(ISNULL(redo_q,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(send_q,0) AS NVARCHAR)+N'</td></tr>' FROM #AG ORDER BY rn;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- UNUSED INDEXES
SET @h=@h+N'<h2 id="ui">Unused Indexes (Write Overhead) <span class="btt"><a href="#">Top</a></span></h2>';
SET @h=@h+N'<div class="n2">Top 20 indexes with zero reads but active write overhead since last SQL Server restart. Every INSERT/UPDATE/DELETE must maintain these indexes unnecessarily. <b>Caution:</b> Stats reset on restart — verify the index is unused across all schedule periods (weekly reports, month-end). In AG environments, reads may occur on secondaries. Never drop without validating in all contexts.</div>';
SET @h=@h+N'<table><tr><th>#</th><th>DB</th><th>Table</th><th>Index ID</th><th>Seeks</th><th>Scans</th><th>Lookups</th><th>Updates</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(rn AS NVARCHAR)+N'</td><td>'+ISNULL(db,N'')+N'</td><td>'+ISNULL(tbl,N'')+N'</td><td>'+CAST(ISNULL(index_id,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(user_seeks,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(user_scans,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(user_lookups,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(user_updates,0) AS NVARCHAR)+N'</td></tr>' FROM #UI ORDER BY rn;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- LOCK ESCALATIONS
SET @h=@h+N'<h2 id="le">Lock Escalations by Table <span class="btt"><a href="#">Top</a></span></h2>';
SET @h=@h+N'<div class="n2">Tables with the most lock escalations since restart. <b>What happens:</b> When a single statement acquires ~5,000 row/page locks, SQL Server escalates to a full table lock — blocking all other readers and writers. <b>Remediation:</b> Set LOCK_ESCALATION=DISABLE on the table, reduce batch sizes, add covering indexes to lock fewer rows, or enable READ_COMMITTED_SNAPSHOT isolation. Empty table = no escalations detected.</div>';
SET @h=@h+N'<table><tr><th>#</th><th>DB</th><th>Table</th><th>Escalations</th><th>Row Locks</th><th>Page Locks</th></tr>';
DECLARE cx CURSOR FAST_FORWARD FOR SELECT N'<tr><td>'+CAST(rn AS NVARCHAR)+N'</td><td>'+ISNULL(db,N'')+N'</td><td>'+ISNULL(tbl,N'')+N'</td><td>'+CAST(ISNULL(escalations,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(row_locks,0) AS NVARCHAR)+N'</td><td>'+CAST(ISNULL(page_locks,0) AS NVARCHAR)+N'</td></tr>' FROM #LE ORDER BY rn;
OPEN cx;FETCH NEXT FROM cx INTO @rw;WHILE @@FETCH_STATUS=0 BEGIN SET @h=@h+ISNULL(@rw,N'');FETCH NEXT FROM cx INTO @rw;END;CLOSE cx;DEALLOCATE cx;
SET @h=@h+N'</table>';

-- FOOTER
SET @h=@h+N'<div class="ft">End of Report &bull; SQL Server Workload Repository v3.2 &bull; '+CONVERT(NVARCHAR,GETDATE(),120)+N' &bull; '+ISNULL(@srv,N'')+N'<br>Read-only. No locks. No schema changes.</div></div></body></html>';

-- ============================================================
-- OUTPUT (tag-safe chunking - never splits HTML tags)
-- ============================================================
DECLARE @pos INT,@len INT,@chunk INT,@end INT;
SET @pos=1;SET @len=ISNULL(LEN(@h),0);SET @chunk=4000;
WHILE @pos<=@len
BEGIN
    SET @end=@pos+@chunk-1;
    IF @end>=@len SET @end=@len;
    ELSE BEGIN
        WHILE @end>@pos AND SUBSTRING(@h,@end,1)!=N'>' SET @end=@end-1;
        IF @end=@pos SET @end=@pos+@chunk-1;
    END
    PRINT SUBSTRING(@h,@pos,@end-@pos+1);
    SET @pos=@end+1;
END
-- When running in SSMS, uncomment the line below to see completion message:
-- SELECT 'HTML generated: '+CAST(@len AS VARCHAR)+' characters. Check MESSAGES TAB for output.' AS instructions;
PRINT '<!-- HTML generated: '+CAST(@len AS VARCHAR)+' characters -->';

-- CLEANUP
IF OBJECT_ID('tempdb..#R') IS NOT NULL DROP TABLE #R;IF OBJECT_ID('tempdb..#W') IS NOT NULL DROP TABLE #W;
IF OBJECT_ID('tempdb..#CW') IS NOT NULL DROP TABLE #CW;IF OBJECT_ID('tempdb..#TC') IS NOT NULL DROP TABLE #TC;
IF OBJECT_ID('tempdb..#TM') IS NOT NULL DROP TABLE #TM;IF OBJECT_ID('tempdb..#IO') IS NOT NULL DROP TABLE #IO;
IF OBJECT_ID('tempdb..#DB') IS NOT NULL DROP TABLE #DB;IF OBJECT_ID('tempdb..#drv') IS NOT NULL DROP TABLE #drv;
IF OBJECT_ID('tempdb..#D2') IS NOT NULL DROP TABLE #D2;IF OBJECT_ID('tempdb..#ls') IS NOT NULL DROP TABLE #ls;
IF OBJECT_ID('tempdb..#AS1') IS NOT NULL DROP TABLE #AS1;IF OBJECT_ID('tempdb..#AS2') IS NOT NULL DROP TABLE #AS2;IF OBJECT_ID('tempdb..#BT') IS NOT NULL DROP TABLE #BT;
IF OBJECT_ID('tempdb..#RS') IS NOT NULL DROP TABLE #RS;IF OBJECT_ID('tempdb..#TD') IS NOT NULL DROP TABLE #TD;
IF OBJECT_ID('tempdb..#OT') IS NOT NULL DROP TABLE #OT;IF OBJECT_ID('tempdb..#CN') IS NOT NULL DROP TABLE #CN;
IF OBJECT_ID('tempdb..#CF') IS NOT NULL DROP TABLE #CF;IF OBJECT_ID('tempdb..#NU') IS NOT NULL DROP TABLE #NU;
IF OBJECT_ID('tempdb..#RJ') IS NOT NULL DROP TABLE #RJ;IF OBJECT_ID('tempdb..#FJ') IS NOT NULL DROP TABLE #FJ;
IF OBJECT_ID('tempdb..#UC') IS NOT NULL DROP TABLE #UC;IF OBJECT_ID('tempdb..#UM') IS NOT NULL DROP TABLE #UM;
IF OBJECT_ID('tempdb..#MP') IS NOT NULL DROP TABLE #MP;IF OBJECT_ID('tempdb..#CP') IS NOT NULL DROP TABLE #CP;
IF OBJECT_ID('tempdb..#TPD') IS NOT NULL DROP TABLE #TPD;IF OBJECT_ID('tempdb..#TDC') IS NOT NULL DROP TABLE #TDC;
IF OBJECT_ID('tempdb..#SP') IS NOT NULL DROP TABLE #SP;IF OBJECT_ID('tempdb..#EL') IS NOT NULL DROP TABLE #EL;
IF OBJECT_ID('tempdb..#TF') IS NOT NULL DROP TABLE #TF;
GO