# ================================================================
# sqlhc Email Report
# Save as: C:\DBA\sqlhc_email.ps1
#
# Usage:
#   .\sqlhc_email.ps1 -Server MP-MBC-D01
#   .\sqlhc_email.ps1 -Server MP-MBC-D01 -To "team@company.com"
#   .\sqlhc_email.ps1 -Server MP-MBC-D01,MP-HRP-D03,MP-HRP-D06
#
# Schedule in Task Scheduler for daily morning reports
# ================================================================

param(
    [Parameter(Mandatory=$true)]
    [string[]]$Server,

    [string]$To = "rama.nuthalapati@azblue.com",         # change to your team DL
    [string]$Cc = "",                              # optional CC
    [string]$From = "AWR-Report@azblue.com",       # change to valid sender
    [string]$SmtpServer = "appmail.azblue.com",       # change to your SMTP relay
    [int]$SmtpPort = 25,                           # 25=relay, 587=auth
    [switch]$UseSsl,
    [switch]$SmtpAuth,                             # if SMTP needs credentials
    [string]$ScriptPath = (Join-Path $PSScriptRoot "sqlhc.sql"),
    [string]$OutputDir  = (Join-Path $PSScriptRoot "sqlhc")
)


if (!(Test-Path $OutputDir)) { New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null }

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$reports = @()
$summaryLines = @()

foreach ($srv in $Server) {
    $srv = $srv.Trim()
    $outFile = "$OutputDir\sqlhc_${srv}_${timestamp}.html"

    Write-Host "[$srv] Generating sqlhc report..." -ForegroundColor Yellow
    
    try {
        & sqlcmd -S $srv -E -i $ScriptPath -o $outFile -h -1 -W 2>&1 | Out-Null
        
        if ((Test-Path $outFile) -and (Get-Item $outFile).Length -gt 500) {
            # Re-encode to UTF-8 (sqlcmd outputs Windows-1252 but HTML declares UTF-8)
            $raw = [System.IO.File]::ReadAllText($outFile, [System.Text.Encoding]::Default)
            [System.IO.File]::WriteAllText($outFile, $raw, [System.Text.Encoding]::UTF8)
            $sizeKB = [math]::Round((Get-Item $outFile).Length / 1024)
            Write-Host "[$srv] Done ($sizeKB KB)" -ForegroundColor Green
            $reports += @{ Server=$srv; File=$outFile; Status="OK"; Size=$sizeKB }
            $summaryLines += "<tr><td style='padding:6px 12px;border:1px solid #ddd'>$srv</td><td style='padding:6px 12px;border:1px solid #ddd;color:green'>&#10004; Success ($sizeKB KB)</td></tr>"
        } else {
            Write-Host "[$srv] FAILED - connection or permission error" -ForegroundColor Red
            $reports += @{ Server=$srv; File=$null; Status="FAILED"; Size=0 }
            $summaryLines += "<tr><td style='padding:6px 12px;border:1px solid #ddd'>$srv</td><td style='padding:6px 12px;border:1px solid #ddd;color:red'>&#10008; Failed</td></tr>"
        }
    } catch {
        Write-Host "[$srv] ERROR: $($_.Exception.Message)" -ForegroundColor Red
        $reports += @{ Server=$srv; File=$null; Status="ERROR"; Size=0 }
        $summaryLines += "<tr><td style='padding:6px 12px;border:1px solid #ddd'>$srv</td><td style='padding:6px 12px;border:1px solid #ddd;color:red'>&#10008; $($_.Exception.Message)</td></tr>"
    }
}

# Build email
$okCount = ($reports | Where-Object { $_.Status -eq "OK" }).Count
$failCount = $reports.Count - $okCount
$statusColor = if ($failCount -gt 0) { "#cc6600" } else { "#006600" }
$statusText = if ($failCount -gt 0) { "$okCount OK / $failCount FAILED" } else { "All $okCount Collected" }

$emailBody = @"
<!DOCTYPE html>
<html>
<head><style>
body { font-family: 'Segoe UI', Arial, sans-serif; padding: 20px; color: #333; }
.banner { background: #003366; color: #fff; padding: 14px 20px; border-bottom: 3px solid #cc6600; }
.banner h1 { margin: 0; font-size: 18px; }
.banner p { margin: 4px 0 0; color: #99ccff; font-size: 12px; }
.status { padding: 10px 20px; font-size: 14px; font-weight: bold; color: #fff; background: $statusColor; margin: 10px 0; }
table { border-collapse: collapse; margin: 10px 0; }
th { background: #003366; color: #fff; padding: 8px 12px; text-align: left; font-size: 12px; }
.note { margin-top: 16px; padding: 12px; background: #f9f9f9; border: 1px solid #ddd; font-size: 11px; color: #666; }
</style></head>
<body>
<div class="banner">
  <h1>&#9881; SQL Server sqlhc</h1>
  <p>Workload Repository Report &bull; $(Get-Date -Format 'yyyy-MM-dd HH:mm') &bull; $($Server.Count) server(s)</p>
</div>
<div class="status">$statusText</div>
<table>
  <tr><th>Server</th><th>Status</th></tr>
  $($summaryLines -join "`n")
</table>
<div class="note">
  <b>Full HTML reports attached.</b> Save the .html attachment and open in Chrome/Edge for the interactive sqlhc report with all 28 sections.<br><br>
  Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') &bull; Script: $ScriptPath
</div>
</body>
</html>
"@

# Build message
$msg = New-Object System.Net.Mail.MailMessage
$msg.From = $From
foreach ($addr in $To.Split(',;')) { $msg.To.Add($addr.Trim()) }
if ($Cc) { foreach ($addr in $Cc.Split(',;')) { $msg.CC.Add($addr.Trim()) } }
$msg.Subject = "sqlhc Health Check - $statusText - $(Get-Date -Format 'yyyy-MM-dd HH:mm')"
$msg.Body = $emailBody
$msg.IsBodyHtml = $true

# Attach successful reports with correct MIME type
foreach ($r in $reports | Where-Object { $_.Status -eq "OK" }) {
    $att = New-Object System.Net.Mail.Attachment($r.File, [System.Net.Mime.MediaTypeNames+Text]::Html)
    $att.ContentDisposition.FileName = "sqlhc_$($r.Server)_$timestamp.html"
    $att.TransferEncoding = [System.Net.Mime.TransferEncoding]::Base64
    $msg.Attachments.Add($att)
}

# Send
Write-Host ""
Write-Host "Sending email to $To ..." -ForegroundColor Yellow

try {
    $smtp = New-Object System.Net.Mail.SmtpClient($SmtpServer, $SmtpPort)
    $smtp.EnableSsl = [bool]$UseSsl
    
    if ($SmtpAuth) {
        $cred = Get-Credential -Message "SMTP credentials for $SmtpServer"
        $smtp.Credentials = $cred
    } else {
        $smtp.UseDefaultCredentials = $true
    }
    
    $smtp.Send($msg)
    Write-Host "Email sent successfully!" -ForegroundColor Green
} catch {
    Write-Host "Email failed: $($_.Exception.Message)" -ForegroundColor Red
} finally {
    $msg.Dispose()
}