@echo off
:: ================================================================
:: sqlhc Web Launcher
:: Double-click to run. First time asks for password, then saved.
:: ================================================================
set PS1PATH=%~dp0sqlhc_web.ps1

set /p RUNUSER=Enter username to run as (e.g. CORP\jsmith) [default: %USERDOMAIN%\%USERNAME%]:
if "%RUNUSER%"=="" set RUNUSER=%USERDOMAIN%\%USERNAME%

echo.
echo Launching sqlhc Web Server as %RUNUSER% ...
echo Open http://localhost:8080 in your browser.
echo.

runas /savecred /user:%RUNUSER% "powershell -ExecutionPolicy Bypass -NoExit -File \"%PS1PATH%\""