@echo off
if "%~1"=="" (echo Usage: sqlhc_run.bat ServerName & exit /b 1)
set SRV=%~1
set DT=%date:~-4%%date:~4,2%%date:~7,2%_%time:~0,2%%time:~3,2%%time:~6,2%
set DT=%DT: =0%
set SQLHCDIR=%~dp0sqlhc
set OUT=%SQLHCDIR%\sqlhc_%SRV%_%DT%.html
if not exist "%SQLHCDIR%" mkdir "%SQLHCDIR%"
sqlcmd -S %SRV% -E -i "%~dp0sqlhc.sql" -o "%OUT%" -h -1 -W
echo Done: %OUT%