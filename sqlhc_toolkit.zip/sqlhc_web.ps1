# ================================================================
# sqlhc Web Launcher - Self-contained PowerShell HTTP Server
# Save as: C:\DBA\sqlhc_web.ps1
# Run as:  powershell -ExecutionPolicy Bypass -File C:\DBA\sqlhc_web.ps1
# Open:    http://localhost:8080
# Stop:    Ctrl+C in the PowerShell window
# ================================================================
# REQUIRES: Run as Administrator (for HTTP listener)
#           C:\DBA\sqlhc.sql must exist
# ================================================================

$Port = 8080
$ScriptPath = Join-Path $PSScriptRoot "sqlhc.sql"
$OutputDir  = Join-Path $PSScriptRoot "sqlhc"

if (!(Test-Path $OutputDir)) { New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null }

# HTML form page
$FormPage = @"
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SQL Server sqlhc</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;background:#f3f2ef;color:#191919;min-height:100vh;}

/* Nav */
.nav{background:#fff;border-bottom:1px solid rgba(0,0,0,0.08);position:sticky;top:0;z-index:100;height:52px;display:flex;align-items:center;padding:0 24px;gap:12px;box-shadow:0 0 0 1px rgba(0,0,0,0.06);}
.nav-icon{background:#0a66c2;color:#fff;font-weight:800;font-size:11px;width:auto;padding:0 8px;height:34px;border-radius:6px;display:flex;align-items:center;justify-content:center;flex-shrink:0;letter-spacing:.5px;}
.nav-title{font-size:14px;font-weight:600;color:#191919;}.nav-title span{color:#0a66c2;}

/* Page grid */
.page{max-width:1080px;margin:24px auto;padding:0 16px;display:grid;grid-template-columns:220px 1fr 300px;gap:20px;align-items:start;}

/* Left profile card */
.lcard{background:#fff;border:1px solid rgba(0,0,0,0.08);border-radius:10px;overflow:hidden;}
.lcard-banner{background:linear-gradient(135deg,#004182,#0a66c2);height:54px;}
.lcard-body{padding:0 16px 16px;text-align:center;}
.lcard-avatar{width:58px;height:58px;border-radius:50%;background:#0a66c2;border:3px solid #fff;margin:-29px auto 10px;display:flex;align-items:center;justify-content:center;font-size:26px;}
.lcard-name{font-size:15px;font-weight:700;color:#191919;margin-bottom:2px;}
.lcard-sub{font-size:12px;color:#666;margin-bottom:12px;}
.lcard-divider{border:none;border-top:1px solid rgba(0,0,0,0.08);margin:10px 0;}
.lcard-row{display:flex;justify-content:space-between;padding:3px 0;font-size:12px;}
.lcard-row span:first-child{color:#666;}
.lcard-row span:last-child{color:#0a66c2;font-weight:600;}
.lcard-link{display:flex;align-items:center;gap:6px;padding:6px 0;font-size:13px;color:#0a66c2;text-decoration:none;font-weight:500;}
.lcard-link:hover{text-decoration:underline;}

/* Center form card */
.fcard{background:#fff;border:1px solid rgba(0,0,0,0.08);border-radius:10px;padding:24px;}
.fcard-head{display:flex;align-items:center;gap:12px;padding-bottom:16px;margin-bottom:20px;border-bottom:1px solid rgba(0,0,0,0.08);}
.fcard-icon{width:50px;height:50px;border-radius:50%;background:#0a66c2;display:flex;align-items:center;justify-content:center;font-size:22px;flex-shrink:0;}
.fcard-title{font-size:18px;font-weight:700;color:#191919;}
.fcard-sub{font-size:13px;color:#666;margin-top:2px;}
label{display:block;font-size:13px;font-weight:600;color:#191919;margin-bottom:6px;}
input[type=text]{width:100%;padding:12px 14px;font-size:15px;font-family:'Courier New',monospace;background:#fff;border:1.5px solid rgba(0,0,0,0.3);border-radius:6px;color:#191919;outline:none;transition:border-color 0.15s,box-shadow 0.15s;}
input[type=text]:focus{border-color:#0a66c2;border-width:2px;box-shadow:0 0 0 1px #0a66c2;}
input[type=text]::placeholder{color:#999;font-family:-apple-system,sans-serif;font-size:14px;}
.hint{font-size:11px;color:#666;margin-top:4px;}
.btn{display:block;width:100%;padding:13px;font-size:15px;font-weight:600;color:#fff;background:#0a66c2;border:none;border-radius:24px;cursor:pointer;margin-top:20px;transition:background 0.15s;}
.btn:hover{background:#004182;}
.btn:disabled{background:rgba(0,0,0,0.08);color:rgba(0,0,0,0.38);cursor:wait;}
.spinner{display:none;margin-top:14px;padding:11px 14px;background:#ebf5ff;border-radius:6px;font-size:13px;color:#0a66c2;text-align:center;}
.spinner.show{display:block;}
.dot{animation:blink 1.4s infinite;}.dot:nth-child(2){animation-delay:.2s;}.dot:nth-child(3){animation-delay:.4s;}
@keyframes blink{0%,80%,100%{opacity:0;}40%{opacity:1;}}
.infobox{margin-top:18px;padding:13px 15px;background:#f3f2ef;border-radius:8px;font-size:12px;color:#666;line-height:1.75;}
.infobox b{color:#191919;}

/* Right sidebar */
.rside{display:flex;flex-direction:column;gap:16px;}
.rcard{background:#fff;border:1px solid rgba(0,0,0,0.08);border-radius:10px;padding:16px;}
.rcard h3{font-size:14px;font-weight:700;color:#191919;margin-bottom:12px;}
.ritem{padding:8px 0;border-bottom:1px solid rgba(0,0,0,0.06);}
.ritem:last-child{border-bottom:none;}
.ritem a{font-size:12px;color:#0a66c2;text-decoration:none;font-family:'Courier New',monospace;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.ritem a:hover{text-decoration:underline;}
.rmeta{font-size:11px;color:#666;margin-top:2px;}
.rview{display:block;text-align:center;margin-top:12px;padding:8px;font-size:13px;font-weight:600;color:#666;text-decoration:none;border:1.5px solid rgba(0,0,0,0.2);border-radius:24px;}
.rview:hover{background:rgba(0,0,0,0.04);color:#191919;border-color:rgba(0,0,0,0.4);}

@media(max-width:860px){.page{grid-template-columns:1fr;}.lcard,.rside{display:none;}}
</style>
</head>
<body>

<nav class="nav">
  <div class="nav-icon">BCBSAZ</div>
  <div class="nav-title"><span>sqlhc</span> Health Dashboard</div>
</nav>

<div class="page">

  <aside>
    <div class="lcard">
      <div class="lcard-banner"></div>
      <div class="lcard-body">
        <div class="lcard-avatar">&#9881;</div>
        <div class="lcard-name">SQL Server sqlhc</div>
        <div class="lcard-sub">Workload Repository v3.2</div>
        <hr class="lcard-divider">
        <div class="lcard-row"><span>Auth</span><span>Windows (-E)</span></div>
        <div class="lcard-row"><span>Mode</span><span>Read-only</span></div>
        <div class="lcard-row"><span>Sections</span><span>27+</span></div>
        <hr class="lcard-divider">
        <a class="lcard-link" href="/history">&#128196;&nbsp; All Reports</a>
      </div>
    </div>
  </aside>

  <main>
    <div class="fcard">
      <div class="fcard-head">
        <div class="fcard-icon">&#128204;</div>
        <div>
          <div class="fcard-title">Generate Health Report</div>
          <div class="fcard-sub">Read-only &bull; No locks &bull; No changes</div>
        </div>
      </div>
      <form id="f" method="GET" action="/run" onsubmit="return go()">
        <label for="srv">SQL Server Instance</label>
        <input type="text" id="srv" name="server" placeholder="e.g. MP-MBC-D01 or SERVER\INSTANCE" required autofocus />
        <div class="hint">Enter hostname, named instance (HOST\INSTANCE), or IP address</div>
        <button type="submit" class="btn" id="btn">Generate sqlhc Report</button>
      </form>
      <div class="spinner" id="spin">
        Running health check<span class="dot">.</span><span class="dot">.</span><span class="dot">.</span>&nbsp; This takes ~10 seconds
      </div>
      <div class="infobox">
        <b>How it works:</b> Runs the sqlhc script via sqlcmd using your Windows credentials (-E). The report opens directly in this browser window.<br>
        <b>Script:</b> $ScriptPath &nbsp;&bull;&nbsp; <b>Output:</b> $OutputDir\
      </div>
    </div>
  </main>

  <aside class="rside">
    RECENT_PLACEHOLDER
  </aside>

</div>

<script>
function go() {
  document.getElementById('btn').disabled = true;
  document.getElementById('btn').textContent = 'Running...';
  document.getElementById('spin').className = 'spinner show';
  return true;
}
</script>
</body>
</html>
"@

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  sqlhc Web Launcher - v3.2" -ForegroundColor Cyan
Write-Host "  http://localhost:$Port" -ForegroundColor Yellow
Write-Host "  Ctrl+C to stop" -ForegroundColor Gray
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Create HTTP listener
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://+:$Port/")
try {
    $listener.Start()
} catch {
    Write-Host "ERROR: Run as Administrator or use: netsh http add urlacl url=http://+:$Port/ user=$env:USERDOMAIN\$env:USERNAME" -ForegroundColor Red
    exit 1
}

Write-Host "Listening on http://localhost:$Port ..." -ForegroundColor Green
Write-Host "Press Ctrl+C or close this window to stop." -ForegroundColor Gray

[Console]::TreatControlCAsInput = $false

try {
    while ($listener.IsListening) {
        # Use async so Ctrl+C is not swallowed
        $task = $listener.GetContextAsync()
        while (-not $task.AsyncWaitHandle.WaitOne(500)) {
            # Check every 500ms — allows Ctrl+C to interrupt
        }
        $context = $task.GetAwaiter().GetResult()
        $request = $context.Request
        $response = $context.Response
        $url = $request.Url.LocalPath
        $query = $request.QueryString

        if ($url -eq "/run" -and $query["server"]) {
            # Run sqlhc report
            $server = $query["server"] -replace '[^a-zA-Z0-9\-_\\.]', ''
            $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
            $outFile = "$OutputDir\sqlhc_${server}_${timestamp}.html"

            Write-Host "$(Get-Date -Format 'HH:mm:ss') Running sqlhc on $server ..." -ForegroundColor Yellow

            try {
                $result = & sqlcmd -S $server -E -i $ScriptPath -o $outFile -h -1 -W 2>&1
                
                if (Test-Path $outFile) {
                    $size = (Get-Item $outFile).Length
                    if ($size -gt 500) {
                        # Success - serve the HTML file directly
                        Write-Host "$(Get-Date -Format 'HH:mm:ss') Done: $outFile ($([math]::Round($size/1024))KB)" -ForegroundColor Green
                        $html = [System.IO.File]::ReadAllBytes($outFile)
                        $response.ContentType = "text/html; charset=UTF-8"
                        $response.ContentLength64 = $html.Length
                        $response.OutputStream.Write($html, 0, $html.Length)
                    } else {
                        # File too small - likely error
                        $errContent = Get-Content $outFile -Raw
                        $errHtml = "<html><head><meta charset='UTF-8'><style>*{margin:0;padding:0;box-sizing:border-box;}body{font-family:-apple-system,'Segoe UI',Arial,sans-serif;background:#f3f2ef;min-height:100vh;}.nav{background:#fff;border-bottom:1px solid rgba(0,0,0,0.08);height:52px;display:flex;align-items:center;padding:0 24px;gap:12px;}.nav-icon{background:#0a66c2;color:#fff;font-weight:800;font-size:11px;width:auto;padding:0 8px;height:34px;border-radius:6px;display:flex;align-items:center;justify-content:center;letter-spacing:.5px;}.nav-title{font-size:14px;font-weight:600;}.nav-title span{color:#0a66c2;}.wrap{max-width:680px;margin:28px auto;padding:0 16px;}.card{background:#fff;border:1px solid rgba(0,0,0,0.08);border-radius:10px;padding:28px;}.err-icon{font-size:36px;margin-bottom:12px;}h2{font-size:18px;font-weight:700;color:#cc1016;margin-bottom:12px;}pre{font-size:12px;color:#333;background:#f3f2ef;padding:14px;border-radius:6px;white-space:pre-wrap;word-break:break-all;margin-bottom:16px;}a{display:inline-block;color:#0a66c2;text-decoration:none;font-weight:600;border:1.5px solid #0a66c2;padding:7px 16px;border-radius:24px;font-size:13px;}a:hover{background:#ebf5ff;}</style></head><body><nav class='nav'><div class='nav-icon'>BCBSAZ</div><div class='nav-title'><span>sqlhc</span> Health Dashboard</div></nav><div class='wrap'><div class='card'><div class='err-icon'>&#9888;&#65039;</div><h2>Connection Failed</h2><pre>$errContent</pre><a href='/'>&#8592; Back to Generator</a></div></div></body></html>"
                        $buffer = [System.Text.Encoding]::UTF8.GetBytes($errHtml)
                        $response.ContentType = "text/html"
                        $response.ContentLength64 = $buffer.Length
                        $response.OutputStream.Write($buffer, 0, $buffer.Length)
                        Write-Host "$(Get-Date -Format 'HH:mm:ss') FAILED: $server - check credentials/connectivity" -ForegroundColor Red
                    }
                } else {
                    throw "sqlcmd did not produce output file"
                }
            } catch {
                $errMsg = $_.Exception.Message
                $errHtml = "<html><head><meta charset='UTF-8'><style>*{margin:0;padding:0;box-sizing:border-box;}body{font-family:-apple-system,'Segoe UI',Arial,sans-serif;background:#f3f2ef;min-height:100vh;}.nav{background:#fff;border-bottom:1px solid rgba(0,0,0,0.08);height:52px;display:flex;align-items:center;padding:0 24px;gap:12px;}.nav-icon{background:#0a66c2;color:#fff;font-weight:800;font-size:11px;width:auto;padding:0 8px;height:34px;border-radius:6px;display:flex;align-items:center;justify-content:center;letter-spacing:.5px;}.nav-title{font-size:14px;font-weight:600;}.nav-title span{color:#0a66c2;}.wrap{max-width:680px;margin:28px auto;padding:0 16px;}.card{background:#fff;border:1px solid rgba(0,0,0,0.08);border-radius:10px;padding:28px;}.err-icon{font-size:36px;margin-bottom:12px;}h2{font-size:18px;font-weight:700;color:#cc1016;margin-bottom:12px;}pre{font-size:12px;color:#333;background:#f3f2ef;padding:14px;border-radius:6px;white-space:pre-wrap;word-break:break-all;margin-bottom:16px;}a{display:inline-block;color:#0a66c2;text-decoration:none;font-weight:600;border:1.5px solid #0a66c2;padding:7px 16px;border-radius:24px;font-size:13px;}a:hover{background:#ebf5ff;}</style></head><body><nav class='nav'><div class='nav-icon'>BCBSAZ</div><div class='nav-title'><span>sqlhc</span> Health Dashboard</div></nav><div class='wrap'><div class='card'><div class='err-icon'>&#9888;&#65039;</div><h2>Error</h2><pre>$errMsg</pre><a href='/'>&#8592; Back to Generator</a></div></div></body></html>"
                $buffer = [System.Text.Encoding]::UTF8.GetBytes($errHtml)
                $response.ContentType = "text/html"
                $response.ContentLength64 = $buffer.Length
                $response.OutputStream.Write($buffer, 0, $buffer.Length)
                Write-Host "$(Get-Date -Format 'HH:mm:ss') ERROR: $errMsg" -ForegroundColor Red
            }

        } elseif ($url -eq "/history") {
            # List all saved reports
            $files = Get-ChildItem "$OutputDir\sqlhc_*.html" -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 50
            $listHtml = "<html><head><meta charset='UTF-8'><style>*{margin:0;padding:0;box-sizing:border-box;}body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif;background:#f3f2ef;color:#191919;min-height:100vh;}.nav{background:#fff;border-bottom:1px solid rgba(0,0,0,0.08);height:52px;display:flex;align-items:center;padding:0 24px;gap:12px;}.nav-icon{background:#0a66c2;color:#fff;font-weight:800;font-size:11px;width:auto;padding:0 8px;height:34px;border-radius:6px;display:flex;align-items:center;justify-content:center;letter-spacing:.5px;}.nav-title{font-size:14px;font-weight:600;}.nav-title span{color:#0a66c2;}.wrap{max-width:700px;margin:28px auto;padding:0 16px;}.card{background:#fff;border:1px solid rgba(0,0,0,0.08);border-radius:10px;padding:24px;}.card-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;padding-bottom:14px;border-bottom:1px solid rgba(0,0,0,0.08);}h1{font-size:18px;font-weight:700;color:#191919;}a.back{font-size:13px;color:#0a66c2;text-decoration:none;font-weight:600;border:1.5px solid #0a66c2;padding:6px 14px;border-radius:24px;}a.back:hover{background:#ebf5ff;}.item{padding:10px 0;border-bottom:1px solid rgba(0,0,0,0.06);display:flex;align-items:baseline;justify-content:space-between;gap:12px;}.item:last-child{border-bottom:none;}.item a{font-size:13px;color:#0a66c2;text-decoration:none;font-family:'Courier New',monospace;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:480px;}.item a:hover{text-decoration:underline;}.meta{font-size:11px;color:#666;white-space:nowrap;}.empty{padding:24px 0;color:#666;font-size:14px;}</style></head><body>"
            $listHtml += "<nav class='nav'><div class='nav-icon'>BCBSAZ</div><div class='nav-title'><span>sqlhc</span> Health Dashboard</div></nav>"
            $listHtml += "<div class='wrap'><div class='card'><div class='card-head'><h1>&#128196; sqlhc Report History</h1><a class='back' href='/'>&larr; Back</a></div>"
            foreach ($f in $files) {
                $sz = [math]::Round($f.Length/1024)
                $listHtml += "<div class='item'><a href='/file?name=$($f.Name)' title='$($f.Name)'>$($f.Name)</a><span class='meta'>$sz KB &bull; $($f.LastWriteTime.ToString('yyyy-MM-dd HH:mm'))</span></div>"
            }
            if ($files.Count -eq 0) { $listHtml += "<div class='empty'>No reports generated yet.</div>" }
            $listHtml += "</div></div></body></html>"
            $buffer = [System.Text.Encoding]::UTF8.GetBytes($listHtml)
            $response.ContentType = "text/html; charset=UTF-8"
            $response.ContentLength64 = $buffer.Length
            $response.OutputStream.Write($buffer, 0, $buffer.Length)

        } elseif ($url -eq "/file" -and $query["name"]) {
            # Serve a saved report file
            $safeName = $query["name"] -replace '[^a-zA-Z0-9\-_\.]', ''
            $filePath = Join-Path $OutputDir $safeName
            if ((Test-Path $filePath) -and $safeName.EndsWith(".html")) {
                $html = [System.IO.File]::ReadAllBytes($filePath)
                $response.ContentType = "text/html; charset=UTF-8"
                $response.ContentLength64 = $html.Length
                $response.OutputStream.Write($html, 0, $html.Length)
            } else {
                $response.StatusCode = 404
                $buffer = [System.Text.Encoding]::UTF8.GetBytes("File not found")
                $response.ContentLength64 = $buffer.Length
                $response.OutputStream.Write($buffer, 0, $buffer.Length)
            }

        } else {
            # Home page with form
            $recentHtml = ""
            $recentFiles = Get-ChildItem "$OutputDir\sqlhc_*.html" -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 5
            if ($recentFiles.Count -gt 0) {
                $recentHtml = "<div class='rcard'><h3>&#128197; Recent Reports</h3>"
                foreach ($f in $recentFiles) {
                    $sz = [math]::Round($f.Length/1024)
                    $recentHtml += "<div class='ritem'><a href='/file?name=$($f.Name)' title='$($f.BaseName)'>$($f.BaseName)</a><div class='rmeta'>$sz KB &bull; $($f.LastWriteTime.ToString('yyyy-MM-dd HH:mm'))</div></div>"
                }
                $recentHtml += "<a href='/history' class='rview'>View all reports &rarr;</a></div>"
            }
            $page = $FormPage -replace "RECENT_PLACEHOLDER", $recentHtml
            $buffer = [System.Text.Encoding]::UTF8.GetBytes($page)
            $response.ContentType = "text/html; charset=UTF-8"
            $response.ContentLength64 = $buffer.Length
            $response.OutputStream.Write($buffer, 0, $buffer.Length)
        }

        $response.Close()
    }
} finally {
    $listener.Stop()
    Write-Host "Server stopped." -ForegroundColor Yellow
}